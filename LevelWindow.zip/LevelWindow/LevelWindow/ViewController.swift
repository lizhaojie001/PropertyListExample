//
//  ViewController.swift
//  LevelWindow
//
//  Created by xdf_yanqing on 2019/3/27.
//  Copyright © 2019 xdf_yanqing. All rights reserved.
//

import Cocoa


class View: NSView {
    convenience init() {
        self.init()
        self.wantsLayer = true
        self.layer?.backgroundColor = NSColor.clear.cgColor
    }
}

class ViewController: NSViewController {

    override func loadView() {
        self.view = View.init(frame: NSRect(origin: CGPoint.zero, size: CGSize(width: 200, height: 300)))
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
       let button = NSButton.init(frame: NSRect(origin: CGPoint.init(x: 20, y: 20), size: CGSize(width: 40, height: 40)))
        button.target = self
        button.action = #selector(addWindow)
        self.view.addSubview(button)
    }
    
   @objc func addWindow()  {
        let first = First()
        self.view.window?.addChildWindow(first, ordered: NSWindow.OrderingMode.above)
        first.makeKey()
        let second = Secound()
        self.view.window?.addChildWindow(second, ordered: NSWindow.OrderingMode.above)
        second.makeKey()
    }
}
