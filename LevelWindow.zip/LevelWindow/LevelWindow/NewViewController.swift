
//
//  NewViewController.swift
//  LevelWindow
//
//  Created by xdf_yanqing on 2019/3/27.
//  Copyright © 2019 xdf_yanqing. All rights reserved.
//

import Cocoa

class NewViewController: NSViewController {

    override func loadView() {
        self.view = NSView.init(frame: NSRect(origin: CGPoint.zero, size: CGSize(width: 100 , height: 100)))

    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
