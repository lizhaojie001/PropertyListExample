//
//  FloatSceneDelegate.swift
//  PlayerViewLayer
//
//  Created by macbook pro on 2021/4/9.
//

import UIKit

class FloatSceneDelegate: UIResponder , UIWindowSceneDelegate {
    var window: UIWindow?
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        
        guard let WindowScene = (scene as? UIWindowScene) else { return }
        
//        let floatWindow = UIWindow(windowScene: WindowScene)
//        let floatController = AVFloatViewController()
//        floatWindow.rootViewController = floatController
//        floatWindow.windowLevel = UIWindow.Level(rawValue: 0.2)
//        floatWindow.isHidden = false
//        self.window = floatWindow
        
    }
}
