//
//  AVFloatViewController.swift
//  PlayerViewLayer
//
//  Created by macbook pro on 2021/4/9.
//

import UIKit

class AVFloatViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .red
        // Do any additional setup after loading the view.
    }
    
    override func loadView() {
        self.view = UIView(frame: CGRect(origin: CGPoint.zero, size: CGSize(width: 200, height: 200)))
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
