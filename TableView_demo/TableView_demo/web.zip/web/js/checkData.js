/**
 * Created by Administrator on 2016/8/17.
 * module info:
 *        生产者消费者模式
 *        函数节流,用于管理从客户端接收到的数据，存入缓冲池，每50ms拿一次数据
 */
define(function (require, exports, module) {
    var seaConf=require('boardConf').conf,
        seaLogic=require('logicUnpack');
    var handleCheck={//used to achieve check
        'route':function(obj){//路由 中转
            //distribute obj to different module according type
            // console.log('------------------route-----------------')
            // console.log(obj)
            // console.log('------------------route-----------------')
            seaLogic.dataGet(obj.type,obj.jsonStr);
        },
        'checkInfo': function (Arr,process,context) {
            //函数节流
            setTimeout(function () {
                var tem=Arr.shift();
                if(tem){
                    process.call(context,tem);
                }
                if(Arr.length>0){
                    setTimeout(arguments.callee,50);
                }
            },50)
        }
    };

    exports.getCheckData=function (type,jsonStr) {
        //做一次封装
        var obj={
            'type':type,
            'jsonStr':jsonStr
        }
        if(type==='course'){
            //记录拿到课程数据的本地时间，保证低误差
            seaConf.course.localTime=new Date().getTime();
        }
        //如果缓冲池中有数据直接丢入
        if(seaConf.serverIOArr.length>0){
            seaConf.serverIOArr.push(obj);
        }else{//如果缓冲池中没有数据，丢入数据并且激活消费者函数
            seaConf.serverIOArr.push(obj);
            handleCheck.checkInfo(seaConf.serverIOArr,handleCheck.route);
        }
    };

    exports.getCheckDataEncode = function(type, json){
        //做一次封装
        var obj={
            'type':type,
            'jsonStr':json
        }
        if(type==='course'){
            //记录拿到课程数据的本地时间，保证低误差
            seaConf.course.localTime=new Date().getTime();
        }
        //改为直接消费
        handleCheck.route(obj);
    }
});
