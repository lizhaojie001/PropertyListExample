/**
 * Created by Administrator on 2016/8/16.
 * module info:
 *        管理程序的事件绑定函数和分类调用
 */
define(function (require, exports, module) {
    var seaConf = require('boardConf').conf,
        seaDataSend = require('enDataSend'),
        seaTools = require('moduleTools');
    var seaBoard = require('whiteBoard');
    var seaLang = require('lang').lang;
    var eventBind = {
        'Arr_scroll': [],//used to achieve teacher's scrollData tip 用于存储滚动提示信息的内容，实现滚动提示信息
        'mouse': {//used to remember last mouse move,see every mouse move is effective or not  用于存储上一个鼠标的位置，判断当前的鼠标是否存在有效的移动
            'lastX': 0,
            'lastY': 0
        },
        'topScroll': 0,//used to remember last scroll top,see every scroll is effective or not 用于记录上一个滚动条的信息，判断滚动条是否有有效的滚动
        'colorArr': ['#F4C56A', '#F46BC7', '#DD247C', '#F56B6B', '#C9F76C', '#68E369', '#18C099', '#40A5F0', '#6BC6F4', '#6969F2', '#D000E8', '#8B572A'], // 颜色工具栏按钮
        'bind': function () {// unified management for bind 用于绑定事件
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            //修改检测机制判断ppt index.html的加载
            var iframe = document.getElementById('showDomain');
            if (iframe.attachEvent) {
                iframe.attachEvent("onload", function () {
                    eventBind.loadedEvent();
                });
            } else {
                iframe.onload = function () {
                    eventBind.loadedEvent();
                };
            }
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            //resize 缩放窗口
            window.addEventListener('resize', function () {
                console.log('[%s] -----------> listen resize event', window.getTimeNow());
                //避免抖动，只处理最后一次的缩放
                // eventBind.throttleStep(eventBind.resizeEvent);
                eventBind.resizeEvent();
            })
            //if(this module is alive) do sth
            if (seaConf.event.scrollData) {//当滚动提示信息事件被激活
                //tip scroll
                console.log('[%s] -----------> listen scroll data event', window.getTimeNow());
                this.scrollDataEvent();
            }
            if (seaConf.event.fixedData) {//当固定提示信息事件被激活
                //tip fixed
                console.log('[%s] -----------> listen fixed data event', window.getTimeNow());
                this.fixedDataEvent();
            }
            if (seaConf.moduleSet.page) {//当翻页事件被激活
                //page changed
                console.log('[%s] -----------> listen page handle event', window.getTimeNow());
                this.pageChangeEvent();
            }
            if (seaConf.moduleSet.tools) {//当工具条事件被激活 工具条显示时
                //tool is clicked
                console.log('[%s] -----------> listen tools handle event', window.getTimeNow());
                this.toolChangeEvent();
            }
            if (seaConf.moduleSet.update) {//当更新事件被激活 支持更新提示功能
                //update tip (never tip is chosed or not )
                console.log('[%s] -----------> listen update event (unknow type from svc)', window.getTimeNow());
                $('#update_cue').bind('click', function (e) {
                    if (e.target.id == 'cue_close') {//当关闭按钮被点击
                        $('#update_cue').css('visibility', 'hidden');
                    } else if (e.target.id == 'cue_stop') {//当不再提示按钮被点击
                        seaConf.update.tip_update = false;//更新数据池
                        $('#update_cue').css('visibility', 'hidden');
                    } else if (e.target.id == 'cue_update') {//当立即升级按钮被点击
                        $('#update_cue').css('visibility', 'hidden');
                    }
                });
            }
            if (seaConf.event.mouse || seaConf.event.barScroll || seaConf.event.timeTip) {//当鼠标监听或者滚动条监听被激活
                //mouse event and barScroll event
                setInterval(function () {
                    if (seaConf.event.mouse) {//鼠标监听
                        //mouse event is alive
                        eventBind.mouseEvent();
                    }
                    if (seaConf.event.barScroll) {//滚动条监听
                        //barScroll event is alive
                        eventBind.barScrollEvent();
                    }
                    if (seaConf.event.timeTip) {//时间提示事件
                        eventBind.timeTipEvent();
                    }
                    //哨兵小于阈值且哨兵递增到最大值  隐藏对面的鼠标
                    if (seaConf.board.mouse.mouseSign < seaConf.board.mouse.mouseMax &&
                        (++seaConf.board.mouse.mouseSign) >= seaConf.board.mouse.mouseMax) {
                        $("#mouseTea").hide();
                    }
                }, 1000);
                if (seaConf.event.mouse) {
                    console.log('[%s] -----------> listen mouse event', window.getTimeNow());
                }
                if (seaConf.event.barScroll) {
                    console.log('[%s] -----------> listen scroll event', window.getTimeNow());
                }
                if (seaConf.event.timeTip) {//时间提示事件
                    console.log('[ %s ]-----------> listen tools handle event', window.getTimeNow());
                }
            }
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            if (seaConf.moduleSet.ccLayer) {
                this.ccLayer();
            }
            //点击右键弹出菜单，隐藏白板
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            //after bind init board css first
            eventBind.throttleStep(eventBind.resizeEvent);
        },
        loadedEvent: function () {
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            var back = true;//用于检测是否有向互动教材成功传递初始化信息 不成功的情况：页面加载失败
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            if (seaConf.host.textType === 'h5Course') {
                //init obj iFrame  向互动教材传递初始化信息
                window.iFrameParIO.parentCon = $(window.parent.document).contents().find("#showDomain")[0].contentWindow;
                back = window.iFrameParIO.H5Course.init();
                window.iFrameParIO.dataDrawI(0, 0, 0, 0);
            }
            if (back) {//成功向互动教材页面传递了信息
                //更新本地信息
                //首先检测当前服务端页码是否和当前的教材类型的页码相同  不相同则强制同步   share
                if (seaConf.user.type === 'tea' && seaConf.classInfo.serverInfo.curPage !== seaConf[seaConf.host.textType].curPage) {
                    seaTools.agentTools('gopage', {targetPage: seaConf[seaConf.host.textType].curPage});
                    return;
                }
                seaConf.classInfo.textInfo.curPage = seaConf.classInfo.serverInfo.curPage;
                var tem_e = {
                    'cur': seaConf.classInfo.textInfo.curPage - 1,//客户端和服务器从0开始
                    'count': seaConf.classInfo.textInfo.countPage
                };
                //更新客户端的页码信息
                seaDataSend.sendCommData('teenpage', JSON.stringify(tem_e));
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                window.iFrameParIO.setPageO(seaConf.classInfo.serverInfo.curPage);
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------

            }
        },
        'fixedDataEvent': function () {
            //let outer remember user's chose
            $('#data_close').bind('click', function (e) {//当固定提示信息被关闭时通知客户端记录，重进教室之后不再显示
                var obj = {
                    'type': 'fixdata',
                    'status': 'close'
                };
                seaDataSend.sendCommData('tipdata', JSON.stringify(obj));
                $('.fixdata_tea').css('display', 'none');
                e.preventDefault();
                e.stopPropagation();
            });
        },
        'scrollDataEvent': function () {
            $('.scroll_tea').css('display', 'block');
            //提示内容进栈
            if (seaConf.user.type == 'teen') {//青少
                this.Arr_scroll.push('Speak slowly.');
                this.Arr_scroll.push('Ask students to repeat new words and sentences 2 times.');
                this.Arr_scroll.push('Use more TPR and gestures.');
                this.Arr_scroll.push('Motivate the student to speak complete sentences.');
                this.Arr_scroll.push('Keep instructions simple and short.');
            } else {//成人教室
                this.Arr_scroll.push('Speak slowly to low-leveled students.');
                this.Arr_scroll.push('Motivate students to speak complete sentences.');
                this.Arr_scroll.push('Ask students to repeat new words and sentences 2 times.');
                this.Arr_scroll.push('Correct only those mistakes that lead to misunderstanding.');
                this.Arr_scroll.push('Don’t stay at warm-up too long, and there must be a wrap-up');
            }

            $('.scroll_tea').text(eventBind.Arr_scroll.shift());//先显示第一条记录
            //这里处理的很差，之后干掉，归到一个时间轴上
            setTimeout(function () {
                setInterval(function () {
                    if (eventBind.Arr_scroll.length == 0) {
                        if (seaConf.user.type == 'teen') {//青少
                            eventBind.Arr_scroll.push('Speak slowly.');
                            eventBind.Arr_scroll.push('Ask students to repeat new words and sentences 2 times.');
                            eventBind.Arr_scroll.push('Use more TPR and gestures.');
                            eventBind.Arr_scroll.push('Motivate the student to speak complete sentences.');
                            eventBind.Arr_scroll.push('Keep instructions simple and short.');
                        } else {
                            eventBind.Arr_scroll.push('Speak slowly to low-leveled students.');
                            eventBind.Arr_scroll.push('Motivate students to speak complete sentences.');
                            eventBind.Arr_scroll.push('Ask students to repeat new words and sentences 2 times.');
                            eventBind.Arr_scroll.push('Correct only those mistakes that lead to misunderstanding.');
                            eventBind.Arr_scroll.push('Don’t stay at warm-up too long, and there must be a wrap-up');
                        }
                        $('.scroll_tea').text(eventBind.Arr_scroll.shift());
                    } else {
                        $('.scroll_tea').text(eventBind.Arr_scroll.shift());
                    }
                }, 5000)
            }, 5000);
        },
        'mouseEvent': function () {
            //update mouse with teacher's board
            var MPoint = seaConf.board.mouse; //取最新的鼠标位置
            var classInfo = seaConf.classInfo; //取教室信息
            var offsetP = eventBind.getOffset(document.getElementById('paintBoard'));
            if (eventBind.mouse.lastX != MPoint.curX || eventBind.mouse.lastY != MPoint.curY) {//有效的移动
                var obj = {
                    'canvasWidth': classInfo.drawInfo.width,
                    'canvasHeight': classInfo.drawInfo.height,
                    'mouseX': MPoint.curX - offsetP.left,
                    'mouseY': MPoint.curY - offsetP.top,
                    'CurrentPage': classInfo.textInfo.curPage
                }
                seaDataSend.sendCommData('mouse', JSON.stringify(obj));//发送鼠标信息到服务器
                //更新当前鼠标的信息，便于下次的鼠标有效移动的比较
                eventBind.mouse.lastX = MPoint.curX;
                eventBind.mouse.lastY = MPoint.curY;
            }
        },
        'pageChangeEvent': function () {//h5自己的翻页
            $('#toolbar_id').find('.toolbarRight, .toolbarRight_m').bind('click', function (e) {
                e = e || window.event || arguments.callee.caller.arguments[0];
                var name = e.target.id;
                var obj = null;
                switch (name) {
                    case 'previousPage'://上一页
                        if (seaConf.classInfo.textInfo.curPage - 1 > 0) {
                            obj = {
                                targetPage: seaConf.classInfo.textInfo.curPage - 1
                            }
                        }
                        break;
                    case 'nextPage'://下一页
                        if (seaConf.classInfo.textInfo.curPage + 1 <= seaConf.classInfo.textInfo.countPage) {
                            obj = {
                                targetPage: seaConf.classInfo.textInfo.curPage + 1
                            }
                        }
                        break;
                    case 'update_tea'://同步页码
                        obj = {
                            targetPage: seaConf.classInfo.serverInfo.curPage
                        }
                        break;
                    default:
                        break;
                }
                if (obj) {//判断如果是有效的点击 抛给代理
                    seaTools.agentTools('gopage', obj);
                }
            });
            document.getElementById('pageNumber').addEventListener('click', function () {
                this.select();
            });

            document.getElementById('pageNumber').addEventListener('change', function () {//选中直接输入页码的跳转
                //tool_e.tool_skip(this.value);
                //屏蔽不合理的页码输入
                if (this.value <= seaConf.classInfo.textInfo.countPage && this.value > 0) {
                    var obj = {
                        targetPage: this.value
                    };
                    seaTools.agentTools('gopage', obj);
                } else {
                    this.value = seaConf.classInfo.textInfo.curPage;
                }
                if($('#pageNumber').val().length == 3) {
                    $('.item_num').css('max-width', '32px');
                }else if($('#pageNumber').val().length == 4) {
                    $('.item_num').css('max-width', '48px');
                }else {
                    $('.item_num').css('max-width', '21px');
                }
            });
            //老师端教案点击事件（因为之前处理过逻辑，所以如果显示了教案提示，那一定是老师端的）
            $('#toolbar_id').on('click', '.lessonPlan', function () {
                if (seaConf.host.textType === 'pdf') {
                    var notesList = seaConf.pdf.lessonPlan.notes
                    // 判断对应页数室友有tip没有就隐藏按钮12
                    $.each(notesList, function (i, item) {
                        if (item.page == seaConf.classInfo.serverInfo.curPage) {
                            var note = {
                                page: item.page,
                                text: item.note
                            };
                            // 计算处理对应页码的notes发给客户端
                            seaDataSend.sendCommData('showNotes', JSON.stringify(note));
                        }
                    })
                }
            });

        },
        'toolChangeEvent': function () {//h5自己的工具条点击事件
            var selectedClassName = seaConf.course.isMultiVC ? 'selectedBut_m' : 'selectedBut';
            $('.outerCenter').bind('click', function (e) {
                // alert('之前')
                // console.log(seaConf.user.teaLogin,seaConf.course.canDraw, seaConf.board.pauseDraw)
                //老师未进房间，禁止使用画板工具     teaLogin为false或pauseDraw为true 都return掉
                if (!seaConf.user.teaLogin || !(seaConf.course.canDraw && !seaConf.board.pauseDraw)) return;
                // alert('后来')
                e = e || window.event || arguments.callee.caller.arguments[0];
                var name = e.target.id !== '' ? e.target.id : e.target.className;
                var obj = null;
                //handle different chose
                switch (name) {
                    case 'hand_color'://颜色
                        e.stopPropagation(); // 阻止点击工具栏冒泡
                        obj = {
                            type: 'color'
                        };
                        $('.color_box').show().css('display', 'flex');
                        $.each(eventBind.colorArr, function (i, item) {
                            $('#hand_color i').eq(i).css({backgroundColor: item, border: '2px solid #fff'});
                        })
                        break;
                    case 'selectColor'://颜色
                        e.stopPropagation(); // 阻止点击工具栏冒泡
                        obj = {
                            type: 'color'
                        };
                        $('.color_box').show().css('display', 'flex');
                        $.each(eventBind.colorArr, function (i, item) {
                            $('#hand_color i').eq(i).css({backgroundColor: item, border: '2px solid #fff'});
                        })
                        break;
                    case 'hand_pen'://铅笔
                        obj = {
                            type: 'pen'
                        };
                        //实现三态
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#tools_handle').find('#hand_pen').addClass(selectedClassName);
                        break;
                    case 'hand_signpen'://荧光笔
                        obj = {
                            type: 'signpen'
                        };
                        //实现三态
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#tools_handle').find('#hand_signpen').addClass(selectedClassName);
                        break;
                    case 'hand_rec'://矩形
                        obj = {
                            type: 'rec'
                        };
                        //实现三态
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#tools_handle').find('#hand_rec').addClass(selectedClassName);
                        break;
                    case 'hand_text'://文本
                        e.stopPropagation(); // 阻止点击工具栏冒泡
                        obj = {
                            type: 'text',
                            size: 'small'
                        };
                        $('#chose_font').show();//显示选择文本的大小
                        $('#chose_font').focus();
                        //实现三态
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#tools_handle').find('#hand_text').addClass(selectedClassName);
                        //字体大小

                        var sizeFont
                        if ($('#chose_font').hasClass('chose_font_small')) {
                            sizeFont = seaConf.board.font.small;
                        } else if ($('#chose_font').hasClass('chose_font_big')) {
                            sizeFont = seaConf.board.font.big;
                        } else {
                            sizeFont = seaConf.board.font.small;
                        }

                        var objConf = {
                            font: {
                                fontSize: sizeFont
                            }
                        };
                        //更新字体大小
                        seaBoard.setBoardConf(objConf);
                        break;
                    // case 'hand_text selectedBut'://默认的文本大小
                    //     e.stopPropagation(); // 阻止点击工具栏冒泡
                    //     obj = {
                    //         type: 'text',
                    //         size: 'small'
                    //     };
                    //     $('#tools_handle span').removeClass(selectedClassName);
                    //     $('#chose_font').show();
                    //     $('#chose_font').focus();
                    //     var sizeFont=seaConf.board.font.small;
                    //     var objConf={
                    //         font:{
                    //             fontSize:sizeFont
                    //         }
                    //     };
                    //     //更新字体大小
                    //     seaBoard.setBoardConf(objConf);
                    //     break;
                    case 'hand_rub'://橡皮
                        obj = {
                            type: 'rub'
                        };
                        //实现三态
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#tools_handle').find('#hand_rub').addClass(selectedClassName);
                        break;
                    case 'hand_newrub'://新版的橡皮
                        obj = {
                            type: 'newrub'
                        };
                        //实现三态
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#tools_handle').find('#hand_newrub').addClass(selectedClassName);
                        break;
                    case 'hand_draft'://拖拽
                        obj = {
                            type: 'draft'
                        };
                        //实现三态
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#tools_handle').find('#hand_draft').addClass(selectedClassName);
                        break;
                    case 'hand_back'://回退
                        obj = {
                            type: 'back'
                        };
                        break;
                    case 'hand_clear'://清空
                        obj = {
                            type: 'clear'
                        };
                        break;
                    case 'hand_magic'://魔法表情
                        obj = {
                            left: $('#tools_handle').find('#hand_magic').offset().left + '',
                            top: $('#tools_handle').find('#hand_magic').offset().top + '',
                            ori: 0 + ''
                        };
                        seaDataSend.sendCommData('magic', JSON.stringify(obj));
                        obj = null;
                        break;
                    case 'font_small'://选择小的文字
                        e.stopPropagation(); // 阻止点击工具栏冒泡
                        obj = {
                            type: 'text',
                            size: 'small'
                        };
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#chose_font').find('.font_big').removeClass('selectedFont');
                        $('#chose_font').find('.font_small').addClass('selectedFont');
                        $('#chose_font').removeClass('chose_font_big').addClass('chose_font_small');
                        $('#tools_handle').find('#hand_text').addClass(selectedClassName);
                        var sizeFont = seaConf.board.font.small;
                        var objConf = {
                            font: {
                                fontSize: sizeFont
                            }
                        };
                        //更新字体大小
                        seaBoard.setBoardConf(objConf);
                        break;
                    case 'font_big'://选择大的文字
                        e.stopPropagation(); // 阻止点击工具栏冒泡
                        obj = {
                            type: 'text',
                            size: 'big'
                        };
                        $('#tools_handle span').removeClass(selectedClassName);
                        $('#chose_font').find('.font_small').removeClass('selectedFont');
                        $('#chose_font').find('.font_big').addClass('selectedFont');
                        $('#chose_font').removeClass('chose_font_small').addClass('chose_font_big');
                        $('#tools_handle').find('#hand_text').addClass(selectedClassName);
                        var sizeFont = seaConf.board.font.big;
                        var objConf = {
                            font: {
                                fontSize: sizeFont
                            }
                        };
                        //更新字体大小
                        seaBoard.setBoardConf(objConf);
                        break;
                    default:
                        break;
                }
                if (obj) {
                    seaTools.agentTools('tools', obj);
                    seaDataSend.sendCommData('handleTools', JSON.stringify(obj));
                }
            })

            //  点击颜色按钮进行选择
            $('.color_box').on('click', 'i', function (e) {
                e.stopPropagation();
                var index = $(this).index();
                $('.color_box i').css('border', '2px solid rgba(255,255,255,1)');
                $(this).css('border', '2px solid rgba(235,230,255,1)');
                if (seaConf.user.type == 'tea') {
                    seaConf.board.tea.pencil.color = eventBind.colorArr[index]
                    seaConf.board.tea.sign_pencil.color = eventBind.colorArr[index]
                    $('.selectColor').css({
                        background: eventBind.colorArr[index],
                        zIndex: 999,
                        border: '2px solid #fff'
                    })
                    var obj = {
                        pencil: {
                            color: seaConf.board.tea.pencil.color
                        },
                        sign_pencil: {
                            color: seaConf.board.tea.pencil.color
                        }
                    }
                    // 更新画笔颜色的配置
                    seaBoard.setBoardConf(obj);
                }
                if (seaConf.user.type == 'stu') {
                    seaConf.board.stu.pencil.color = eventBind.colorArr[index]
                    seaConf.board.stu.sign_pencil.color = eventBind.colorArr[index]
                    var obj = {
                        pencil: {
                            color: seaConf.board.stu.pencil.color
                        },
                        sign_pencil: {
                            color: seaConf.board.stu.pencil.color
                        }
                    }
                    // 更新画笔颜色的配置
                    seaBoard.setBoardConf(obj);
                }
                // 同步当前使用哪种工具
                var currentTool = {
                    type: seaConf.board.curToolType
                };
                seaDataSend.sendCommData('setPenColor', JSON.stringify({color: eventBind.colorArr[index]})); // 发送给服务端
                seaTools.agentTools('tools', currentTool);
            })

            // 气泡阻止冒泡
            $('.tabMenu-item').click(function (e) {
                e.stopPropagation();
            })

            //用于当点击白板时，隐藏颜色选择栏
            $('body').click(function () {
                // 同步当前使用哪种工具
                var currentTool = {
                    type: seaConf.board.curToolType
                };
                seaTools.agentTools('tools', currentTool);
                $('.color_box').hide();
                $('.pop').hide();
                $('.triangle').removeClass('open');
            });

            // 点击tab显示对应三角和气泡
            $('.tabMenu-item').on('click', function (e) {
                if ($(e.currentTarget).find('.music-pop')[0] && !$(e.currentTarget).find('.music-pop-item').length) {
                    $.showTip(seaLang[seaConf.host.language].msg.noAudio);
                    return
                }
                if ($(e.currentTarget).find('.video-pop')[0] && !$(e.currentTarget).find('.video-pop-item').length) {
                    $.showTip(seaLang[seaConf.host.language].msg.noVideo);
                    return
                }
                $('.triangle').removeClass('open');
                $(this).find('.triangle').addClass('open');
                $('.pop').hide();
                $(this).find('.pop').show();
            })

            // 点击音频交互
            $('.music-pop').on('click', '.m-state', function () {
                if ($(this).hasClass('pause')) {
                    // 发送暂停协议（无失败可能）
                    var obj = {
                        type: 'stop',
                        url: $(this).closest('.music-pop-item').attr('url')
                    }
                    seaDataSend.sendCommData('audio', JSON.stringify(obj));
                    $(this).removeClass('pause');
                    seaConf.board.audioPlayState = false;
                    $('.rotate-con').removeClass('alias').animate({top: '0'}, 300, function(){
                        $(this).hide();
                    })
                } else {
                    // 发送播放协议（如果失败，会有协议传过来）
                    var obj = {
                        type: 'play',
                        url: $(this).closest('.music-pop-item').attr('url')
                    }
                    seaDataSend.sendCommData('audio', JSON.stringify(obj));
                    $(this).addClass('pause');
                    $('.rotate-con').show().animate({top: '10%'}, 300, function(){
                        $(this).addClass('alias');
                    })
                    seaConf.board.audioPlayState = true;
                }
                $(this).closest('.music-pop-item').siblings().find('.m-state').removeClass('pause');
                $('.pop').hide();
            })

            // 点击视频交互
            $('.video-pop').on('click', 'p', function () {
                if (seaConf.board.audioPlayState) {
                    $.showTip(seaLang[seaConf.host.language].msg.tabVideoMsg);
                    return
                }
                // 发送视频播放协议（由于播放视频会覆盖窗口，每次点击发送给客户端协议就好，其余的交客户端处理）
                var obj = {
                    type: 'play',
                    url: $(this).attr('url')
                }
                seaDataSend.sendCommData('video', JSON.stringify(obj));
                $('.pop').hide();
            })

            //用于当点击白板时，文字大小选择的隐藏
            $('#chose_font').blur(function () {
                $('#chose_font').hide();
            });
            //如果是h5的工具条那么初始化画板一次   有风险
            // if (seaConf.moduleSet.tools) {
            //     var tem = {
            //         type: 'pen'
            //     };
            //     // seaTools.agentTools('tools', tem);
            // }
            //工具条画笔被选中
            // $('#tools_handle').find('#hand_pen').addClass(selectedClassName);
        },
        'barScrollEvent': function () {
            var topScroll = $('#scrollbar1').find('.thumb')[0].offsetTop,//取滚动条的滚动块上边缘距离滚动条顶层的距离
                heightBar = $('#scrollbar1').find('.thumb')[0].offsetHeight,//取滚动块的高度
                heightScroll = $('#scrollbar1').find('.track')[0].offsetHeight;//取滚动条的总高度

            var s2 = (seaConf.classInfo.textInfo.height - heightScroll) / (heightScroll - heightBar);//（教材总高度-滚动条的总高度）/（滚动条总高度-滚动块的高度）即高出的部分和可滚动距离的比值
            if (heightBar != 0) {//存在滚动条
                if (eventBind.topScroll != topScroll) {//有效的滚动
                    var obj = {
                        'totalHeight': seaConf.classInfo.textInfo.height,
                        'scrollTop': parseInt(topScroll * s2),//映射到教材上的top
                        'CurrentPage': seaConf.classInfo.textInfo.curPage - 1
                    };
                    seaDataSend.sendCommData('scroll', JSON.stringify(obj));
                }
            }
            //更新本次的滚动距离
            eventBind.topScroll = topScroll;
        },
        'resizeEvent': function () {
            seaConf.classInfo.drawInfo.teaScrollDisable = false
            // console.log('resizeEvent')
            //avoid shake , up to now this function don't show positive effect,because client don't support free resize
            var wid = $('#mainContainer').width(),//取容器的宽
                hei = $('#mainContainer').height();//取容器的高
            if (seaConf.moduleSet.contain) {//if contain module is alive 如果容器模块存在
                if (seaConf.moduleSet.page && !seaConf.course.isMultiVC) {//if page contain is alive 如果页码模块存在 且不是多视频教室
                    $('#workSpace').height(hei - $('#toolbar_id').height()); //去除页码模块的高度
                } else {//page module is dead
                    $('#workSpace').height(hei);
                }
            }

            if (seaConf.user.type !== 'tea') {  // 学生时获取不到宽度 强制居中设置
                $('.outerCenter').css({
                    left: '50%',
                    transform: 'translateX(-50%)'
                });
            } else {
                $('.outerCenter').css('left', function () {
                    return ($('#mainContainer').width() / 2 - $('.outerCenter').width() / 2) + 'px';
                });
            }

            //显示工具条
            if (seaConf.moduleSet.tools) {
                $('.outerCenter').show();
            }
            //调用一次
            window.iFrameParIO.resizeEventO();//调用一次，初始化一次教材
            window.iFrameParIO.dataDrawI($('#workContainer').width(), $('#workContainer').width() * seaConf.classInfo.textInfo.rate, 0, 0)
        },
        'timeTipEvent': function () {
            //事件函数
            var curLocalTime = new Date().getTime(),
                startLocalTime = seaConf.course.localTime,
                startedTime = seaConf.course.startedTime;
            var nowTime = Math.max(curLocalTime - startLocalTime + startedTime, 0) / 1000;//转为s
            var mine = Math.round(nowTime / 60 - 0.5),
                sec = Math.round(nowTime % 60 - 0.5);
            mine = mine < 10 ? 0 + '' + mine : mine + '';
            sec = sec < 10 ? 0 + '' + sec : sec + '';
            $('.timeTipCon').find('.timeInfo').html('<span>' + mine + ':' + sec + '</span>');
        },
        //用于实现jquery的offset函数
        'getOffset': function (Node, offset) {
            if (!offset) {
                offset = {};
                offset.top = 0;
                offset.left = 0;
            }
            if (Node == document.body) {//if current node is body，end
                return offset;
            }
            offset.top += Node.offsetTop;
            offset.left += Node.offsetLeft;
            return eventBind.getOffset(Node.parentNode, offset);//up and account
        },
        'throttleStep': function (method, context) {
            //避免重复操作 防抖处理
            clearTimeout(method.tid);
            method.tid = setTimeout(function () {
                method.call(context);
            }, 50);
        },
        //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
        'ccLayer': function () {//cc  第三方人  蒙层 规避所有的点击操作 避免进入教室的行为影响上课
            $('#layerCon').bind('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
            });
        },
        //创建弹出菜单
        'createBoardMenu': function () {
            document.getElementById("workContainer").oncontextmenu = function (e) {
                if (seaConf.host.textType === 'h5Course') {
                    var pointX = e.pageX,
                        pointY = e.pageY;

                    //弹出框的宽度,高度，阴影宽度
                    var divW = 200,
                        divH = 60,
                        shadowW = 5;

                    //外层的宽度，高度
                    var ContaiW = $(this).width(),
                        ContaiH = $(this).height();

                    //弹出层的左边距,上边距
                    var leftx = pointX,
                        topx = pointY;

                    //避免弹出层超出右边界
                    if (pointX + divW > ContaiW) {

                        leftx = leftx - (pointX + divW - ContaiW) - $(".scrollbar").width();
                    }
                    //避免弹出层超出下边界
                    if (pointY + divH > ContaiH) {

                        topx = topx - (pointY + divH - ContaiH) - shadowW;
                    }

                    $("#popMenuBox").css({"left": leftx + "px", "top": topx + "px"})
                        .show();
                }
            };

            //点击隐藏执行事件
            $("#popMenuBox").on("click", "li", function () {
                $("#popMenuBox").hide();
                $('#paintBoard').hide();
            })

            $("#workContainer").click(function (e) {
                if ($("#popMenuBox").is(":visible")) {
                    $("#popMenuBox").hide();
                    e.stopPropagation();
                }
            })

            window.addEventListener('blur', function (e) {
                if ($("#popMenuBox").is(":visible")) {
                    $("#popMenuBox").hide();
                }
            })
        },
        //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
    };
    exports.eventStart = function () {
        eventBind.bind();//调用开始绑定的函数
    }
});
