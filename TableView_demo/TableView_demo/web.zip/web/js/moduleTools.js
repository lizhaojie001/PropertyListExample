/**
 * Created by Administrator on 2016/8/18.
 * module info:
 *        细节逻辑模块
 *        按照类型分发服务器的白板数据
 *        翻页逻辑
 *        滚动条
 *        鼠标教鞭
 */
define(function (require, exports, module) {
    var seaConf=require('boardConf').conf,
        seaLang = require('lang').lang,
        seaBoard=require('whiteBoard'),
        seaTools=require('moduleTools'),
        seaDataSend=require('enDataSend');
    function setPageProhibit(page, total){
        if(page==1){
            $("#toolbar_id .item_pre").addClass("forbid");
            $("#toolbar_id .item_next").removeClass("forbid");
            return;
        }
        if(page==total){
            $("#toolbar_id .item_pre").removeClass("forbid");
            $("#toolbar_id .item_next").addClass("forbid");
            return;
        }
        $("#toolbar_id .item_pre").removeClass("forbid");
        $("#toolbar_id .item_next").removeClass("forbid");
    }
    
    
    var Tools={
        operAgent:function(type,obj){
            if(type=='pageclick'){//随堂测验
                type='gopage';
            }
            switch (type){
                case 'paint'://处理来自服务端的paint数据
                    if (seaConf.host.textType==='pdf' && seaConf.classInfo.textInfo.curPage-1 == obj.curPage) {
                        seaBoard.showCefPaint(obj);
                    }
                    break;
                case 'mouse'://mouse event 处理来自服务端的鼠标数据
                    if(seaConf.classInfo.textInfo.curPage==seaConf.classInfo.serverInfo.curPage){
                        if(!(seaConf.user.type=='tea'&&seaConf.course.courseType=='1vN')){
                            $('#mouseTea').show();
                            //更新当前哨兵，用于是否显示隐藏对面的鼠标
                            seaConf.board.mouse.mouseSign=0;
                            //做坐标点的适配
                            var s=seaConf.classInfo.drawInfo.width/obj.canvasWidth;
                            $('#mouseTea').animate({
                                'left': obj.mouseX*s,
                                'top' : obj.mouseY*s
                            },'fast');
                        }
                    }
                    break;
                case 'lessonTips':
                    if(seaConf.host.textType==='pdf' && seaConf.user.type == 'tea'){
                        $('.lessonPlan').hide();  // 必须初始化先hide
                        if (!seaConf.pdf.lessonPlan.notes) {
                            return
                        }
                        var notesList = seaConf.pdf.lessonPlan.notes
                        // 判断对应页数室有tip没有就隐藏按钮12
                        $.each(notesList, function(i,item){
                            if(item.page == obj.CurrentPage) {
                                var note = {
                                    page: item.page,
                                    text: item.note
                                };
                                $('.lessonPlan').show();
                                // seaDataSend.sendCommData('showNotes',JSON.stringify(note)); //初始化和翻页不发协议
                            }
                        })
                    }
                    break;
                case 'setNotes':
                    if(seaConf.host.textType==='pdf' && seaConf.user.type == 'tea'){
                        seaConf.pdf.lessonPlan = obj;
                        var pageObj = {
                            CurrentPage: seaConf.classInfo.serverInfo.curPage,
                            TotalPage: seaConf.classInfo.serverInfo.countPage
                        }
                        seaTools.agentTools('lessonTips', pageObj);
                    }
                    break;
                case 'scroll'://scroll event 用于处理来自服务端的滚动条数据
                    seaConf.classInfo.drawInfo.teaScrollDisable = true
                    var topScroll=$('#scrollbar1').find('.thumb')[0].offsetTop,//取滚动条的滚动块上边缘距离滚动条顶层的距离
                        heightBar=$('#scrollbar1').find('.thumb').height(),//取滚动块的高度
                        heightScroll=$('#scrollbar1').find('.track')[0].offsetHeight;//取滚动条的总高度
                    var textHeight=seaConf.classInfo.textInfo.height;//获取教材的高度
                    //条件： 存在滚动条&&和老师在同一页&&身份不是老师
                    if(heightScroll!=0&&seaConf.classInfo.textInfo.curPage==seaConf.classInfo.serverInfo.curPage){
                        var s0=textHeight/obj.totalHeight;//取当前的教材高度和对面教材高度的比例
                        var newTop=obj.scrollTop*s0;//取得对面top映射到当前教材的top
                        var s1=(heightScroll-heightBar)/(textHeight-heightScroll);//（教材总高度-滚动条的总高度）/（滚动条总高度-滚动块的高度）即高出的部分和可滚动距离的比值
                        if(newTop>(textHeight-$('#overview').height())){//如果超出了当前的可滚动距离，将课件滚动到最底部
                            newTop=textHeight-$('#overview').height();
                        }
                        //滚动条滚动
                        $('#scrollbar1').find('.thumb').animate({'top':newTop*s1},'fast');
                        //课件区域滚动
                        $('#overview').animate({'top':newTop*-1},'fast');
                    }
                    break;
                case 'page'://page event   handle svc page event 处理来自服务器的翻页
                    //当前课件是pdf或者是新协议传过来的
                    // alert('收client  '+JSON.stringify(obj))
                    // 发送给客户端的页码是目标页码减1 发给什么返回给我们什么
                    if(seaConf.host.textType==='pdf'||(obj.type&&obj.type==='pageNew')){
                        seaConf.classInfo.serverInfo.curPage=parseInt(obj.CurrentPage)+1;//更新数据池中服务器的页码信息
                        if(seaConf.classInfo.textInfo.curPage!=seaConf.classInfo.serverInfo.curPage){//if cur page ! = server page,go it 判断如果当前本地的页码和服务器的页码不同
                            seaConf.classInfo.textInfo.curPage=seaConf.classInfo.serverInfo.curPage;//强制同步本地页码和服务器页码
                            //update page
                            window.iFrameParIO.setPageO(seaConf.classInfo.textInfo.curPage);//调用翻页
                        }else{
                        }
                        
                        //for no page module
                        if(seaConf.moduleSet.page){//如果存在page模块，则更新页码显示 隐藏同步按钮
                            $('#pageNumber').val(seaConf.classInfo.serverInfo.curPage);
                            if($('#pageNumber').val().length == 3) {
                                $('.item_num').css('max-width', '32px');
                            }else if($('#pageNumber').val().length == 4) {
                                $('.item_num').css('max-width', '48px');
                            }else {
                                $('.item_num').css('max-width', '21px');
                            }
                            setPageProhibit(seaConf.classInfo.serverInfo.curPage, seaConf.classInfo.serverInfo.countPage);
                            $('.item_update').hide();
                        }
                        //always send to client
                        //总是通知客户端当前页码
                        var tem_e={
                            'cur':seaConf.classInfo.textInfo.curPage-1,
                            'count':seaConf.classInfo.textInfo.countPage
                        };
                        seaDataSend.sendCommData('teenpage',JSON.stringify(tem_e));
                        //如果存在白板模块且当前用户有绘制的能力
                        if(seaConf.moduleSet.board&&seaConf.board.isShowTool){  // 此处修改了canDraw为pauseDraw因为canDraw默认总为true
                            //如果老师已经在线并且当前页码和服务器相同
                            if(seaConf.user.teaLogin&&seaConf.classInfo.serverInfo.curPage==seaConf.classInfo.textInfo.curPage){
                                //移除白板的暂停绘制
                                console.log('[%s] -----------> update board to pause draw(false) when page and page number is same',window.getTimeNow());
                                // alert('5'+seaConf.board.pauseDraw)
                                seaConf.board.pauseDraw=false;
                                exports.updateBoardConf({'pauseDraw':false});//update Board conf
                            }
                        }
                        //将本地数据重新绘制一遍
                        seaBoard.rePaint();
                        //重新激活当前的画笔
                        exports.agentTools('tools',{'type':seaConf.board.curToolType});
                        // hack
                        if(seaConf.user.type == 'tea'){
                            var pageObj = {
                                CurrentPage: seaConf.classInfo.serverInfo.curPage,
                                TotalPage: seaConf.classInfo.serverInfo.countPage
                            }
                            seaTools.agentTools('lessonTips', pageObj);
                        }
                    }else{
                        //如果是pdf，更新pdf的页码，防止老师回来回到第一页
                        //更新pdf的页码信息
                        seaConf.pdf.curPage=parseInt(obj.CurrentPage)+1;
                    }
                    seaBoard.clearPaint();  // 清空本地的绘制信息
                    seaBoard.handle_clear();  // 清空轨迹数组
                    break;
                
                //------------------------------------------for h5Course demo--------------------------------
                case 'pageNew'://page event   handle svc page event 处理来自服务器的翻页    新协议的page内容处理
                    console.log('[%s] -----------> pageNew handle,handle info :%s',window.getTimeNow(),JSON.stringify(obj));
                    //更新当前教材类型的页码信息
                    seaConf[obj.Type].curPage=parseInt(obj.CurrentPage)+1;
                    seaConf[obj.Type].countPage=parseInt(obj.TotalPage);
                    if(obj.Type==seaConf.host.textType){
                        //判断如果类型相同 则此信息对本地页码有效 强制同步
                        var temObj={
                            CurrentPage:seaConf[obj.Type].curPage-1,
                            TotalPage:seaConf[obj.Type].countPage,
                            type:'pageNew'
                        }
                        Tools.operAgent('page',temObj);
                    }
                    break;
                //------------------------------------------for h5Course demo--------------------------------
                case 'updateStuPage':
                    var numCur=parseInt(obj.targetPage);//取目标页码
                    var temObj={
                        'TotalPage':seaConf.classInfo.textInfo.countPage,
                        'CurrentPage':numCur-1
                    }
                    //保证只发送一种协议
                    if(seaConf.host.textType==='pdf'){
                        console.log('[%s] -----------> %s send page data to server,type : updateStuPage(%s %s)',window.getTimeNow(),seaConf.user.type,temObj.CurrentPage,temObj.TotalPage);
                        seaDataSend.sendCommData('page',JSON.stringify(temObj));
                    }else if(seaConf.host.textType==='h5Course'){
                        //支持新协议
                        //------------------------------------------for h5Course demo--------------------------------
                        //这个新的协议
                        temObj.Type=seaConf.host.textType;
                        console.log('[%s] -----------> %s send pageNew data to server,type : updateStuPage(%s %s %s)',window.getTimeNow(),seaConf.user.type,temObj.CurrentPage,temObj.TotalPage,temObj.Type);
                        seaDataSend.sendCommData('pageNew',JSON.stringify(temObj));
                        //------------------------------------------for h5Course demo--------------------------------
                    }
                    break;
                //------------------------------------------for h5Course demo--------------------------------
                case 'gopage'://young classroom page event  处理来自客户端或本身的翻页
                    var numCur=parseInt(obj.targetPage);//取目标页码
                    var lastNum = seaConf.classInfo.textInfo.curPage-1;
                    window.iFrameParIO.setPageO(numCur);//调用翻页
                    seaConf.classInfo.textInfo.curPage=numCur;//更新本地数据
                    
                    if(seaConf.user.type=='tea'){
                        //------------------------------------------for h5Course demo--------------------------------
                        if((seaConf.host.textType==='h5Course'&&seaConf.h5Course.startClass)||seaConf.host.textType==='pdf'){
                            //更新服务器页码数据
                            seaConf.classInfo.serverInfo.curPage=numCur;
                            
                            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                            //更新当前教材类型的页码信息
                            seaConf[seaConf.host.textType].curPage=seaConf.classInfo.serverInfo.curPage;
                            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                            
                            //先清空一次  目的是清空服务器的数据，防止下发其他页码的数据
                            // exports.agentTools('tools',{'type':'clear'});
                            //通知服务器页码变更
                            var temObj={
                                'TotalPage':seaConf.classInfo.textInfo.countPage,
                                'CurrentPage':seaConf.classInfo.textInfo.curPage-1
                            }
                            //保证只发送一种协议
                            if(seaConf.host.textType==='pdf'){
                                console.log('[%s] -----------> %s send page data to server,type : updateStuPage(%s %s)',window.getTimeNow(),seaConf.user.type,temObj.CurrentPage,temObj.TotalPage);
                                // alert('发给client    '+JSON.stringify(temObj))
                                seaDataSend.sendCommData('page',JSON.stringify(temObj));
                                // 判断页码对应教案提示显隐
                                var pageObj = {
                                    'CurrentPage':seaConf.classInfo.textInfo.curPage,
                                    'TotalPage':seaConf.classInfo.textInfo.countPage
                                }
                                seaTools.agentTools('lessonTips', pageObj);
                                // seaBoard.clearPaint();
                            }else if(seaConf.host.textType==='h5Course'){
                                //支持新协议
                                //------------------------------------------for h5Course demo--------------------------------
                                //这个新的协议
                                temObj.Type=seaConf.host.textType;
                                console.log('[%s] -----------> %s send pageNew data to server,type : updateStuPage(%s %s %s)',window.getTimeNow(),seaConf.user.type,temObj.CurrentPage,temObj.TotalPage,temObj.Type);
                                seaDataSend.sendCommData('pageNew',JSON.stringify(temObj));
                                //------------------------------------------for h5Course demo--------------------------------
                            }
                        }
                        //-------------------------------------------------------------------------------------------
                        //通知客户端页码变更
                        var tem_e={
                            'cur':seaConf.classInfo.textInfo.curPage-1,
                            'count':seaConf.classInfo.textInfo.countPage
                        };
                        console.log('[%s] -----------> %s send teenpage data to server,type : gopage',window.getTimeNow(),seaConf.user.type);
                        seaDataSend.sendCommData('teenpage',JSON.stringify(tem_e));
                    }else{//非老师身份
                        //判断是否在同一页
                        if(seaConf.classInfo.textInfo.curPage!=seaConf.classInfo.serverInfo.curPage){
                            if(seaConf.moduleSet.page){
                                $('.item_update').show();//如果存在页码模块则显示同步按钮
                            }
                            if(seaConf.user.teaLogin){
                                //暂停绘制
                                seaConf.board.pauseDraw=true;
                                console.log('[%s] -----------> update board to pause draw(true) when gopage',window.getTimeNow());
                                exports.updateBoardConf({'pauseDraw':true});//update Board conf
                                //更改鼠标样式
                                if(seaConf.host.classType=='teen'){
                                    $('#canvas_bak').css('cursor',seaConf.cursor.teen.forbidden);
                                    $('#showDomain').css('cursor',seaConf.cursor.teen.forbidden);
                                }else{
                                    $('#canvas_bak').css('cursor',seaConf.cursor.normal.forbidden);
                                    $('#showDomain').css('cursor',seaConf.cursor.normal.forbidden);
                                }
                            }
                            // //清空本地的绘制信息
                            // seaBoard.clearPaint();
                        }else{
                            if(seaConf.moduleSet.page){
                                $('.item_update').hide();
                            }
                            if(seaConf.user.teaLogin && seaConf.board.isShowTool){
                                // alert('8'+seaConf.board.pauseDraw)
                                //关闭暂停绘制
                                console.log('[%s] -----------> update board to pause draw(false) when gopage and page number is same and teacher is in class',window.getTimeNow());
                                seaConf.board.pauseDraw=false;
                                exports.updateBoardConf({'pauseDraw':false});//update Board conf
                                //重新激活当前画笔
                                exports.agentTools('tools',{'type':seaConf.board.curToolType});
                            }
                            //重绘本地绘制信息
                            // seaBoard.rePaint();
                        }
                    }
                    if(seaConf.moduleSet.page){
                        //存在页码模块  更新页码内容
                        $('#pageNumber').val(seaConf.classInfo.textInfo.curPage);
                        if($('#pageNumber').val().length == 3) {
                            $('.item_num').css('max-width', '32px');
                        }else if($('#pageNumber').val().length == 4) {
                            $('.item_num').css('max-width', '48px');
                        }else {
                            $('.item_num').css('max-width', '21px');
                        }
                        setPageProhibit(seaConf.classInfo.textInfo.curPage, seaConf.classInfo.textInfo.countPage);
                    }
                    //翻页数据上报
                    /*
                        action 参数
                        1 上一页
                        2 下一页
                        3 同步定位
                    */
                    seaBoard.clearPaint();  // 清空本地的绘制信息
                    seaBoard.handle_clear();  // 清空轨迹数组
                    seaDataSend.sendCommData('pageNotify',JSON.stringify({
                        'cur':lastNum,
                        'target':seaConf.classInfo.textInfo.curPage-1,
                        'action':seaConf.classInfo.textInfo.curPage-1>lastNum?2:1,
                    }));
                    break;
                case 'tools'://tools event
                    // console.log('-------------------tools--------------------')
                    // console.log(obj)
                    // // alert('tools-tealogin'+seaConf.user.teaLogin)
                    // console.log('-------------------tools--------------------')
                    // alert('tools-pauseDraw'+seaConf.board.pauseDraw)
                    console.log('[%s] -----------> tools handle,handle info :%s',window.getTimeNow(),JSON.stringify(obj));
                    //----------------------容错处理--------------------------
                    // if(seaConf.board.pauseDraw&&seaConf.user.type==='tea'){
                    //     seaConf.board.pauseDraw=false;
                    // }
                    //----------------------容错处理--------------------------
                    if(seaConf.board.pauseDraw){//now can not draw  这里可能是多余的处理，但是是无害处理，能屏蔽很多意外
                        // alert('变化前')
                        //更新鼠标样式
                        // if(seaConf.host.classType=='teen'){
                        //     alert('teen')
                        //     $('.outerCenter').hide();
                        //     $('#canvas_bak').css('cursor',seaConf.cursor.teen.forbidden);
                        // }else{
                        //     alert('teen-else')
                        //     $('#canvas_bak').css('cursor',seaConf.cursor.normal.forbidden);
                        // }
                        // $('.outerCenter').hide();
                        $('#canvas_bak').css('cursor',seaConf.cursor.teen.forbidden);
                        //通知白板 暂停绘制
                        console.log('[%s] -----------> update board to pause draw(true) when tools',window.getTimeNow());
                        seaBoard.setBoardConf({'pauseDraw':true});
                    }else{
                        // $('.outerCenter').show();
                        //通知白板 可以绘制
                        console.log('[%s] -----------> update board to pause draw(false) when tools and conf data pauseDraw is false',window.getTimeNow());
                        seaBoard.setBoardConf({'pauseDraw':false});
                    }
                    //将绘制命令托管到另外的处理函数
                    Tools.operDraw(obj);
                    break;
                case 'addTool'://add magic from c++  改为魔法表情的显示由客户端通知
                    if(seaConf.moduleSet.tools){
                        if(obj.magic){
                            $('.outerCenter').show();
                            //显示魔法表情图标
                            $('#tools_handle').find('#hand_magic').show();
                            var wid=$('#tools_handle').width();
                            //修改托盘宽度
                            $('#tools_handle').css('width',wid+22+'px');
                        }
                    }
                    break;
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                case 'showTool':
                    console.log('--------------------showTool-----------------')
                    $('#tools_handle span').each(function(i){
                        $(this).attr('title', $(this).attr('stitle'));
                    })
                    seaConf.board.pauseDraw = false;
                    seaConf.board.isShowTool = true;
                    $('.outerCenter').css('opacity', '1');
                    // $('.outerCenter').show();
                    $('#canvas_bak').css('cursor',seaConf.cursor.teen.pen);
                    seaTools.updateBoardConf({'pauseDraw':false});//通知白板，打开绘制支持
                    if (seaConf.user.type == 'stu') {
                        $.showTip(seaLang[seaConf.host.language].msg.canUsePaint);
                    }
                    
                    // 同步当前使用哪种工具
                    var currentTool = {
                        type: seaConf.board.curToolType
                    };

                    seaTools.agentTools('tools', currentTool);
                    break;
                case 'hideTool':
                    seaConf.board.pauseDraw = true;
                    seaConf.board.isShowTool = false;
                    $('.outerCenter').css('opacity', '.2');
                    if($('#color_box')[0] && seaConf.user.type == 'stu'){
                        $('#color_box').hide();
                    }
                    // $('.outerCenter').hide();
                    //如果是英文的系统则修改提示信息
                    $('#tools_handle span').attr("title", seaLang[seaConf.host.language].msg.msg2);
                    $('#canvas_bak').css('cursor',seaConf.cursor.teen.forbidden);
                    seaTools.updateBoardConf({'pauseDraw':true});//通知白板，关闭绘制支持
                    // 同步当前使用哪种工具
                    var currentTool = {
                        type: seaConf.board.curToolType
                    };
                    seaTools.agentTools('tools', currentTool);
                    break;
                case 'setPenColor':
                    if(seaConf.user.type=='tea') {
                        // $('.selectColor').css({background: obj.color, zIndex: 999, border: '2px solid #fff'})
                        seaConf.board.tea.pencil.color = obj.color;
                        seaConf.board.tea.sign_pencil.color = obj.color;
                        var obj = {
                            pencil: {
                                color: seaConf.board.tea.pencil.color
                            },
                            sign_pencil: {
                                color: seaConf.board.tea.pencil.color
                            }
                        }
                        // 更新画笔颜色的配置
                        seaBoard.setBoardConf(obj);
                    }
                    if(seaConf.user.type=='stu') {
                        seaConf.board.stu.pencil.color = obj.color;
                        seaConf.board.stu.sign_pencil.color = obj.color;
                        var obj = {
                            pencil: {
                                color: seaConf.board.stu.pencil.color
                            },
                            sign_pencil: {
                                color: seaConf.board.stu.pencil.color
                            }
                        }
                        // 更新画笔颜色的配置
                        seaBoard.setBoardConf(obj);
                    }
                    break;
                case 'audio': // 音频播放失败
                    if (obj.type == 'failed') {
                        $.showTip(seaLang[seaConf.host.language].msg.playErrorMsg);
                        $('.music-pop .m-state').removeClass('pause');
                        seaConf.board.audioPlayState = false;
                        $('.rotate-con').removeClass('alias').animate({top: '0'}, 500, function(){
                            $(this).hide();
                        })
                    }
                    break;
                case 'startPractice':
                    seaDataSend.sendCommData('startPractice',JSON.stringify(obj));
                    break;
                case 'startClass':
                    seaDataSend.sendCommData('startClass',JSON.stringify(obj));
                    break;
                case 'backFirst':
                    var temObj={
                        targetPage:1
                    }
                    Tools.operAgent('gopage',temObj);
                    break;
                case 'canvas':
                    if(obj.type === "open"){
                        $("#paintBoard").show();
                        seaBoard.rePaint();
                    } else {
                        $("#paintBoard").hide();
                    }
                    break;
                case 'otherEnter':
                    var temObj={
                        type:'otherEnter',
                        identify:obj.type
                    };
                    window.iFrameParIO.H5Course.notify(temObj);//通知互动js
                    break;
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                default :
                    console.error('[%s] -----------> unKnow agent type : %s',window.getTimeNow(),type);
                    break;
            }
            
        },
        operDraw: function (obj) {
            if(seaConf.course.canDraw&&!seaConf.board.pauseDraw){//如果当前用户有绘制的能力并且没有被暂停绘制
                var teen=(seaConf.host.classType=='teen')?true:false,
                    cursorTeen=seaConf.cursor.teen,//青少的鼠标样式信息
                    cursorNor=seaConf.cursor.normal;//成人的鼠标样式信息
                switch (obj.type){
                    case 'pen':
                        if(teen){
                            $('#canvas_bak').css('cursor',cursorTeen.pen);
                        }else{
                            $('#canvas_bak').css('cursor',cursorNor.pen);
                        }
                        seaConf.board.curToolType=obj.type;
                        break;
                    case 'signpen':
                        if(teen){
                            $('#canvas_bak').css('cursor',cursorTeen.signpen);
                        }else{
                            $('#canvas_bak').css('cursor',cursorNor.signpen);
                        }
                        seaConf.board.curToolType=obj.type;
                        break;
                    case 'rec':
                        if(teen){
                            $('#canvas_bak').css('cursor',cursorTeen.rec);
                        }else{
                            $('#canvas_bak').css('cursor',cursorNor.rec);
                        }
                        seaConf.board.curToolType=obj.type;
                        break;
                    case 'rub':
                        if(teen){
                            $('#canvas_bak').css('cursor',cursorTeen.rub);
                        }else{
                            $('#canvas_bak').css('cursor',cursorNor.rub);
                        }
                        seaConf.board.curToolType=obj.type;
                        break;
                    case 'newrub':
                        if(teen){
                            $('#canvas_bak').css('cursor',cursorTeen.newrub);
                        }else{
                            $('#canvas_bak').css('cursor',cursorNor.newrub);
                        }
                        seaConf.board.curToolType=obj.type;
                        break;
                    case 'text':
                        if($('#Center_chose')){
                            $('#Center_chose').css('display','none');
                        }
                        if(teen){
                            $('#canvas_bak').css('cursor',cursorTeen.text);
                        }else{
                            $('#canvas_bak').css('cursor',cursorNor.text);
                        }
                        seaConf.board.curToolType=obj.type;
                        break;
                    case 'draft':
                        if(teen){
                            $('#canvas_bak').css('cursor',seaConf.cursor.teen.draft);
                        }else{
                            $('#canvas_bak').css('cursor',seaConf.cursor.normal.draft);
                        }
                        seaConf.board.curToolType=obj.type;
                        break;
                    case 'back':
                        var tem_e={
                            'handleType':1,/*删*/
                            'drawingType':1,/*代表撤销*/
                            'specialValue':null
                        }
                        //通知服务器回退
                        seaDataSend.sendCommData('paint',JSON.stringify(tem_e));
                        break;
                    case 'clear':
                        var tem_e={
                            'handleType':1,/*删*/
                            'drawingType':2,/*代表清空*/
                            'specialValue':null
                        }
                        //通知客户端撤销
                        seaDataSend.sendCommData('paint',JSON.stringify(tem_e));
                        break;
                    default:
                        console.error('[%s] -----------> unKnow draw type : %s',window.getTimeNow(),obj.type);
                        break;
                }
                
                //MAC恢复默认光标
                if(seaConf.host.mainHost==='mac'){
                    $('#canvas_bak').css('cursor',"auto");
                }
                
                //更新画笔
                seaBoard.draw(obj.type);
            }
        }
    }
    exports.initPageNum=function (obj) {
        seaDataSend.sendCommData('teenpage',JSON.stringify(obj));
    };
    exports.agentTools=function (oper,obj) {
        Tools.operAgent(oper,obj);
    };
    exports.updateBoardConf= function (obj) {
        seaBoard.setBoardConf(obj);
    };
    exports.reviewCanvas= function (tw,th,tl,tt) {
        seaBoard.resizePaint(tw,th,tl,tt);
    }
});
