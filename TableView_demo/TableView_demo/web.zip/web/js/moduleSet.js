/**
 * Created by Administrator on 2016/8/16.
 * module info:
 *        管理页面中的模块，按需加载
 */
define(function (require, exports, module) {
    var seaConf = require('boardConf').conf;
    var seaLang = require('lang').lang;
    var seaTools=require('moduleTools');
    var module = {
        'loadModule': function () {
            var temModuleSet = seaConf.moduleSet;
            var isPDF = true;

            //按需加载
            //外层容器
            if (temModuleSet.contain) {
                console.log('[%s] -----------> load contain', window.getTimeNow());
                module.moduleContain();
            }
            //课件显示
            if (temModuleSet.course) {
                console.log('[%s] -----------> load course', window.getTimeNow());
                module.moduleCourse(seaConf.host.textType);
            }
            //白板画布
            if (temModuleSet.board) {
                console.log('[%s] -----------> load board', window.getTimeNow());
                module.moduleBoard();
            }
            //翻页
            if (temModuleSet.page) {
                console.log('[%s] -----------> load page', window.getTimeNow());
                module.modulePage();
            }
            //工具条
            if (temModuleSet.tools) {
                console.log('[%s] -----------> load tools', window.getTimeNow());
                module.moduleTools();
            }
            //升级提示
            if (temModuleSet.update) {
                console.log('[%s] -----------> load update', window.getTimeNow());
                module.moduleUpdate();
            }
            //滚动提示信息
            if (temModuleSet.dataScroll) {
                console.log('[%s] -----------> load scroll data', window.getTimeNow());
                module.moduleDataScroll();
            }
            //固定提示信息
            if (temModuleSet.dataFixed) {
                console.log('[%s] -----------> load fiexd data', window.getTimeNow());
                module.moduleDataFixed();
            }
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            //CC蒙层
            if (temModuleSet.ccLayer) {
                console.log('[%s] -----------> load cc layer', window.getTimeNow());
                module.moduleCCLayer();
            }
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            //时间提示模块
            if (temModuleSet.timeTip) {
                console.log('[' + window.getTimeNow() + ']' + '----------->' + 'load time tip');
                module.moduleTimeTip();
            }
            //教材切换
            if (temModuleSet.switch) {
                module.loadSwitch();
            }
            //教材音頻菜單切换
            // alert(temModuleSet.tabMenu)
            if (temModuleSet.tabMenu) {
                module.loadTabMenu();
            }
        },
        loadSwitch: function () {
            var $btn_switch = $("<a class='btn-switch'>Switch Material</a>");
            $btn_switch.hide();
            $btn_switch.click(function () {
                window.comm_type_send("H5ChangeBook", "{}");
            });
            $(".toolContain").append($btn_switch);
        },
        loadTabMenu: function () {
            var audioList = seaConf.host.textUrl.audioList ? seaConf.host.textUrl.audioList : [];
            var videoList = seaConf.host.textUrl.videoList ? seaConf.host.textUrl.videoList : [];
            var audioStr = '';
            var videoStr = '';
            if (audioList.length > 0) {
                $.each(audioList, function (i, item) {
                    audioStr += '<div class="music-pop-item" url="'+ item.URL +'"><span class="m-name">' + item.ChName + '</span><span class="m-state"></span></div>'
                })
            }
            if (videoList.length > 0) {
                $.each(videoList, function (i, item) {
                    videoStr += '<p class="video-pop-item" url="'+ item.URL +'">' + item.ChName + '</p>'
                })
            }
            var lang = seaLang[seaConf.host.language].tools;
            var tabMenuStr = '<div class="tabMenuCon" id="tabMenuCon" style="display: none;">' +
                                '<i></i>' +
                                '<div class="tabMenu-item" style="display: none;">' +
                                    '<div class="course-pop pop"><p>13123123123123123</p><p>13123123123123123</p></div>' +
                                    '<span class="course"></span>' +
                                    '<p>'+ lang.teachingMaterial +'</p>' +
                                    '<div class="triangle"></div>' +
                                '</div>' +
                                '<div class="tabMenu-item" style="display: none;">' +
                                    '<div class="music-pop pop">'+
                                       audioStr +
                                    '</div>' +
                                    '<span class="music"></span>' +
                                    '<p>'+ lang.audio +'</p>' +
                                    '<div class="triangle"></div>' +
                                '</div>' +
                                '<div class="tabMenu-item" style="display: none;">' +
                                    '<div class="video-pop pop">' + videoStr + '</div>' +
                                    '<span class="video"></span>' +
                                    '<p>'+ lang.video +'</p>' +
                                    '<div class="triangle"></div>' +
                                '</div>' +
                              '</div>'
            $(".toolContain").append(tabMenuStr);
        },
        //------------------------out module-------------------------------//
        'moduleContain': function () {
            //父模块
            var str = '<div class="workSpace" id="workSpace">' +
                '<div id="scrollbar1">' +
                '<div class="viewport" id="dsa">' +
                '<div class="overview" id="overview">' +
                '<div id="workContainer">' +
                '<iframe class="showDomain" id="showDomain" scrolling="no"></iframe>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '<div class="scrollbar">' +
                '<div class="track">' +
                '<div class="thumb" id="scroll1_thumb">' +
                '<div class="end"></div>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>';
            $('#mainContainer').append(str);
            //调用滚动条js的初始化函数
            $('#scrollbar1').tinyscrollbar();
            // 拓展全局tip
            $.extend({
                showTip: function (msg) {
                    var tip = $('<p class="tip-con">'+ msg +'</p>');
                    $('#mainContainer').append(tip);
                    setTimeout(function(){
                        $('.tip-con').remove();
                    }, 1000)
                }
            })
            //根据不同的教室来设置不同的背景颜色
            // if (seaConf.host.classType == 'teen') {
            //     $('#workSpace').css('background-color', 'rgb(248,243,232)');
            // } else if (seaConf.course.courseType == '1v1') {
            //     $('#workSpace').css('background-color', 'rgb(239,243,247)');
            // }
        },
        'modulePage': function () {
            var lang = seaLang[seaConf.host.language].tools;
            var className = (seaConf.course.isMultiVC && 'toolbarRight_m') || 'toolbarRight';

            var str =
                '<div class="toolbar" id="toolbar_id">' +
                '<div class="toolContain">' +
                '<div class="toolbarLeft">' +
                '</div>' +
                '<div class="toolbarCenter">' +
                '</div>' +
                '<div class="' + className + '">' +
                '<ul>' +
                '<li class="item_update"><span id="update_tea" title = "' + lang.sync + '"></span></li>' +
                '<li class="lessonPlan"><span id="lessonPlan" title = "' + lang.plan + '"></span></li>' +
                '<li class="item_pre forbid"><span title="' + lang.prev + '" id="previousPage"></span></li>' +
                '<li class="item_num"><input type="tel" id="pageNumber" value="1"/></li>' +
                '<li class="item_count"><span id="numPages"></span></li>' +
                '<li class="item_next"><span title="' + lang.next + '" id="nextPage"  tabindex="14"></span></li>' +
                '</ul>' +
                '</div>' +
                '</div>' +
                '</div>';
            $('#mainContainer').append(str);
            if (seaConf.user.type == 'stu') {
                $('.' + className).hide();
            }
            if (seaConf.course.isMultiVC) {
                //如果是多视频教室 宽度调整，位置调整
                $('#toolbar_id').css({
                    'right': '0px'
                });
            }
        },
        'moduleTools': function () {
            var str1 = '<div class="tool_m_l_r" id="toolbar_left" style="left: 0px;"></div>'
                + '<div class="tool_m_l_r" id="toolbar_right" style="right: 0px;"></div>'
                + '<div class="tool_m_l_r" id="toolbar_bottom" style="bottom: 0px;"></div>';

            var str2 =
                '<div class="outerCenter">' +
                '<ul class="centerBak">' +
                '<li id="chose_font" class="chose_font" tabindex="-1">' +
                '<span class="font_small"></span>' +
                '<span class="font_big"></span>' +
                '</li>' +
                '<li class="' + (seaConf.course.isMultiVC ? 'tools_handle_m' : 'tools_handle') + '" id="tools_handle">';

            console.log('[' + window.getTimeNow() + ']' + '----------->' + 'load fiexd data');

            var lang = seaLang[seaConf.host.language].tools;
            var color = '<span class="hand_color" id="hand_color" stitle="' + lang.color + '" title = "' + lang.color + '"><b class="selectColor"></b><span id="color_box" class="color_box"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></span></span>',
                line = '<span class="hand_pen" id="hand_pen" stitle="' + lang.paint + '" title = "' + lang.paint + '"></span>',
                signline = '<span class="hand_signpen" id="hand_signpen" stitle="' + lang.highlighter + '" title = "' + lang.highlighter + '"></span>',
                square = '<span class="hand_rec" id="hand_rec" stitle="' + lang.rec + '" title = "' + lang.rec + '"></span>',
                text = '<span class="hand_text" id="hand_text" stitle="' + lang.text + '" title = "' + lang.text + '"></span>',
                rubber = '<span class="hand_rub" id="hand_rub" stitle="' + lang.eraser + '" title = "' + lang.eraser + '"></span>',
                newrub = '<span class="hand_newrub" id="hand_newrub" stitle="' + lang.eraser + '" title = "' + lang.eraser + '"></span>',
                drag = '<span class="hand_draft" id="hand_draft" stitle="' + lang.drag + '" title = "' + lang.drag + '"></span>',
                back = '<span class="hand_back" id="hand_back" stitle="' + lang.undo + '" title = "' + lang.undo + '"></span>',
                clear = '<span class="hand_clear" id="hand_clear" stitle="' + lang.clear + '" title = "' + lang.clear + '"></span>',
                magic = '<span class="hand_magic" id="hand_magic" style="display: none" title = "魔法表情"></span>';

            //下面根据配置文件来决定显示还是隐藏部分工具，智能调整工具条的长度
            var count = 0,//记录当前的可用的工具的总个数
                sign = 0,//记录文字工具之前的工具的总个数 为了确定文字大小选择的显示位置
                first = '',//记录第一个工具
                titleArr = [];//一次记录显示的工具的title提示

            //  此处不能同步config信息???????
            first = (count == 0) ? 'hand_color' : first;
            str2 += color;//形成html字符串
            count++;
            titleArr.push(seaLang.en.tools.color);
            if (seaConf.host.tools.text) {
                first = (count == 0) ? 'hand_text' : first;
                str2 += text;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.text);
            }
            // if(seaConf.host.tools.color){
            //   alert(1)
            //   first=(count==0)?'hand_color':first;
            //   str2+=color;//形成html字符串
            //   count++;
            //   titleArr.push('color');
            // }
            // titleArr.push('color');

            if (seaConf.host.tools.pen) {
                first = (count == 0) ? 'hand_pen' : first;
                str2 += line;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.paint);
            }
            if (seaConf.host.tools.rec) {
                first = (count == 0) ? 'hand_rec' : first;
                str2 += square;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.rec);
            }
            if (seaConf.host.tools.signpen) {
                first = (count == 0) ? 'hand_signpen' : first;
                str2 += signline;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.highlighter);
            }
            if (seaConf.host.tools.rub) {
                first = (count == 0) ? 'hand_rub' : first;
                str2 += rubber;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.eraser);
            }
            if (seaConf.host.tools.newrub) {
                first = (count == 0) ? 'hand_newrub' : first;
                str2 += newrub;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.eraser);
            }
            if (seaConf.host.tools.back) {
                first = (count == 0) ? 'hand_back' : first;
                str2 += back;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.undo);
            }
            if (seaConf.host.tools.clear) {
                first = (count == 0) ? 'hand_clear' : first;
                str2 += clear;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.clear);
            }
            if (seaConf.host.tools.draft) {
                first = (count == 0) ? 'hand_draft' : first;
                str2 += drag;//形成html字符串
                count++;
                titleArr.push(seaLang.en.tools.drag);
            }

            //if(seaConf.user.type=='tea'){
            //    first=(count==0)?'hand_magic':first;
            //    str2+=magic;
            //    count++;
            //    titleArr.push('magic');
            //}
            //修改为以下逻辑  count不++，暂时不显示，但是要加入magic的html字符串，修改为客户端通知，因为魔法表情不一定下载完成了
            if (seaConf.user.type == 'tea') {
                first = (count == 0) ? 'hand_magic' : first;
                str2 += magic;
                titleArr.push('magic');
            }
            //封尾，保证标签的闭合性
            str2 += '</li>' +
                '</ul>' +
                '</div>';
            //已不用
            var str3 = '<div id="tool_move"></div>';
            $('#mainContainer').append(str2);
            // alert('顺序追加' + seaConf.moduleSet.tools)
            
            //如果没有可用工具，则隐藏工具条
            if (first == '') {
                $('.outerCenter').hide();
            } else {

                //如果是英文的系统则修改提示信息
                if (seaConf.user.type != 'tea') $('#tools_handle span').attr("title", seaLang.en.msg.msg1);

                if (seaConf.course.isMultiVC) {
                    //多视频一对多教室样式
                    //处理第一个的边距
                    $('#' + first).css('margin-left', '15px');
                    //计算设置宽度
                    $('#tools_handle').css('width', 30 + count * 44 + 'px');
                    //计算设置文字选择的边距
                    $('#chose_font').css('margin-left', (sign * 44 + 13) + 'px');//sign*44+15-2
                    //设置默认的字体
                    $('#chose_font').find('.font_big').addClass('selectedFont');
                    $('#chose_font').removeClass('chose_font_small').addClass('chose_font_big');
                } else {
                    //正常一对多教室

                    //调整工具栏左边距
                    // $('.outerCenter').css('left', function () {
                    //     return ($('#mainContainer').width()-$('#tools_handle').width())/6+'px';
                    // });
                    //处理第一个的边距
                    $('#' + first).css('margin-left', '15px');
                    //计算设置宽度
                    //$('#tools_handle').css('width',20+count*22+'px');
                    //计算设置文字选择的边距
                    $('#chose_font').css('margin-left', (sign * 22 + 1) + 'px');//sign*(20+2)+15-14
                    //设置默认的字体
                    $('#chose_font').find('.font_small').addClass('selectedFont');
                    $('#chose_font').removeClass('chose_font_big').addClass('chose_font_small');
                }
            }
        },
        'moduleDataScroll': function () {
            // var str = '<div class="scroll_tea"></div>';
            // $('#mainContainer').append(str);
            // //修改背景颜色
            // if (seaConf.host.classType == 'teen') {
            //     $('.scroll_tea').css('background-color', 'rgb(250, 237, 192)');
            // }
        },
        'moduleDataFixed': function () {
            var str = '<div class="fixdata_tea"><div style="position: relative;width: 100%;height: 100%;"><span>Your lesson is recorded for quality purposes. And a quality evaluator might be observing your lesson.</span><div id="data_close"></div></div></div>';
            $('#mainContainer').append(str);
            //fixed data css change
            if (seaConf.host.classType == 'teen') {
                $('.fixdata_tea').css('background-color', 'rgb(98, 97, 93)');
                $('.fixdata_tea').css('cursor', seaConf.cursor.teen.normal);
            } else {
                $('.fixdata_tea').css('cursor', seaConf.cursor.normal.normal);
            }
        },
        'moduleTimeTip': function () {
            var str = '<div class="timeTipCon"><div class="timeInfo"><span>00:00</span></div></div>';
            $('#mainContainer').append(str);
        },
        'moduleUpdate': function () {
            var str =
                '<div id="update_cue">' +
                '<ul>' +
                '<li class="l1_close"><span id="cue_close"></span></li>' +
                '<li class="l2_info"><span>AC教室又增加新功能啦，升级后即可使用.提示：可在AC主界面左下角系统菜单中点击升级</span></li>' +
                '<li class="l3_chose"><span id="cue_stop" class="cue_stop">不再提示</span></li>' +
                '</ul>' +
                '</div>';
            $('#mainContainer').append(str);
            if (seaConf.host.language == 'en') {
                var tipWordsC = '<span>New functions in AC,try after upgrading it!Tips: Click on "Upgrade" in the MENU at  the AC main page.</span>';
                $('#update_cue').find('.l2_info').html(tipWordsC);
                $('#update_cue').find('.cue_stop').html('Don\'t ask me again');
            }
        },
        //------------------------out module-------------------------------//

        //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
        //--------------------------for cc---------------------------------//
        'moduleCCLayer': function () {
            var str = '<div id="layerCon"></div>';
            $('#mainContainer').append(str);
        },
        //--------------------------for cc---------------------------------//

        //-------------------------------------------------for h5Course demo-----------------------------------------------------------------

        //------------------------inner module-------------------------------//
        'moduleBoard': function () {
            var str = '<div id="paintBoard" class="paintBoard"><div style="position: relative;width: 100%;height: 100%">' +
                '<div id="input" autofocus="autofocus" tabindex="-1">' +
                '<p id="edit" contenteditable="plaintext-only"></p>' +
                '</div>' +
                '<div class="rotate-con"></div>'+
                '<div id="mouseTea"><canvas id="canvasMouse" width="20" height="20"></canvas></div>' +
                '<canvas class="canvas" id="canvas">浏览器不支持</canvas>' +
                '<canvas class="canvas" id="canvas_bak" tabindex="-1"></canvas>' +
                '</div></div>' +
                '<div id="inputBakContain"><span id="inputBak"></span><div>';
            $('#workContainer').append(str);
            //修改光标
            if(seaConf.host.classType=='teen'){
                if(seaConf.user.type!=='tea'){
                    $('#canvas_bak').css('cursor',seaConf.cursor.teen.forbidden);
                }else{
                    $('#canvas_bak').css('cursor',seaConf.cursor.teen.normal);
                    // alert('2'+seaConf.board.pauseDraw)
                    seaConf.board.pauseDraw=false;
                }
                //关于对方的鼠标
                $('#mouseTea').css({
                    'width': seaConf.cursor.teen.size.wid + 'px',
                    'height': seaConf.cursor.teen.size.hei + 'px',
                    'background-image': seaConf.cursor.teen.ferule,
                    'background-repeat': 'no-repeat'
                });
                $('#input').css('cursor', seaConf.cursor.teen.draft);
            }
            else{
                if(seaConf.user.type!=='tea'){
                    $('#canvas_bak').css('cursor',seaConf.cursor.normal.forbidden);
                }else{
                    $('#canvas_bak').css('cursor',seaConf.cursor.teen.normal);
                    // alert('4'+seaConf.board.pauseDraw)
                    seaConf.board.pauseDraw=false;
                }
                //关于对方的鼠标
                $('#mouseTea').css({
                    'width': seaConf.cursor.normal.size.wid + 'px',
                    'height': seaConf.cursor.normal.size.hei + 'px',
                    'background-image': seaConf.cursor.normal.ferule,
                    'background-repeat': 'no-repeat'
                });
                $('#input').css('cursor', seaConf.cursor.normal.draft);
            }

            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            //如果是互动教材，白板是透明色
            if (seaConf.host.textType === 'h5Course') {
                if (seaConf.user.type === 'tea') {
                    $("#paintBoard").css("background-color", seaConf.h5Course.canvasColor);
                }
                //默认没有画布
                $("#paintBoard").hide();
            }
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
        },
        'moduleCourse': function (type) {
            //根据类型加载不同的课件
            switch (type) {
                case 'pdf':
                    $('#showDomain').attr('src', './courseLoad/pdf/pdf.html');
                    break;
                case 'h5Course':
                    $('#showDomain').attr('src', seaConf.host.textUrl.h5Course.urlControl + '?' + new Date().getTime());
                    break;
                default :
                    break;
            }
            //init obj iFrame  初始化子iframe对象
            window.iFrameParIO.parentCon = $(window.parent.document).contents().find("#showDomain")[0].contentWindow;
        },
        //------------------------inner module-------------------------------//

    }
    exports.loadModuleStart = function () {
        module.loadModule();
    };
});
