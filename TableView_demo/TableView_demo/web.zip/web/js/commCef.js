/**
 * Created by Administrator on 2016/8/15.
 * module info:
 *        用于和c++交互的模块
 */
//achieve communication agent
define(function (require, exports, module) {
    var seaConf=require('boardConf').conf,
        seaCheck=require('checkData');

    function consumeServerData(data, pi, pj) {
        //先置哨兵为false
        seaConf.cToJsChildTaskEnd = false;
        var i = 0,
            j = 0,
            pi = pi,
            pj = pj,
            runArr = [],
            runLen = 0,
            childArr = [],
            childLen = 0,
            childIndex = -1,

            isBFalse = false, //为了区别是不是Base64 decode失败
            // isDFalse = false,
            isCFalse = false; //为了避免try catch到c++的错误，造成死机制循环


        //初始化数据 分两种情况
        // 一种是第一次执行或者完整执行一次consumeServerData后发现cToJsCacheArr还有新的数据加入继续执行
        // 一种是在完整执行一次consumeServerData函数的时候出现错误，继续执行下一次

        if(data == undefined){
            //第一种情况
            runArr = seaConf.cToJsCacheArr.splice(0);
            pi = 0;
            pj = 0;
        }else{
            //第二种情况
            runArr = data;
        }

        runLen = runArr.length;

        var type = '',
            value = null;
        // debugger;
        try{
            for(i = pi; i < runLen; i++){
                childIndex = runArr[i].dataIndex;

                // console.log('===========test encode================>consumeServerData 当前执行:');
                // console.log(childIndex);

                isBFalse = true;
                childArr = JSON.parse(MyBase64.decode(runArr[i].data));
                isBFalse = false;
                childLen = childArr.length;
                for(j = pj; j < childLen; j++){
                    type = childArr[j].type;
                    value = childArr[j].value;
                    // console.log('~~~~~~~'+childIndex+'~~~~~~~~~~~~'+j+'~~~~~~~~~~');
                    if(type != undefined && value != undefined){
                        seaCheck.getCheckDataEncode(type,value);
                    }else{
                        if(type == undefined) throw "type is undefined!"
                        if(value == undefined) throw "value is undefined!"
                    }
                }
                //还原pj，保证下次for时从0开始，避免漏掉数据
                pj = 0;

                //每成功消费一次arr数据和c++握手一次
                isCFalse = true;
                window.comm_type_get_encode_back && window.comm_type_get_encode_back('complete',JSON.stringify({index:childIndex}));
                isCFalse = false;
            }
        }catch (e){
            console.warn('|-------------consumeServerData---------->消费服务器数据时出错!');
            console.warn(e);

            if(isBFalse){
                console.log('===========test encode================>consumeServerData Base64出错');
                //假如是Base64造成的出错
                window.comm_type_get_encode_back && window.comm_type_get_encode_back('BaseError',JSON.stringify({
                    index : childIndex,
                    errorInfo : e
                }));
                window.comm_type_get_encode_back && window.comm_type_get_encode_back('complete',JSON.stringify({index:childIndex}));
                return consumeServerData(runArr.slice(0),++i,j);
            }

            if(!isCFalse){//确保不是c++的错误触发try catch机制
                console.log('===========test encode================>consumeServerData 处理数据出错');
                //在消费每一次的数据的时候出现任何问题都要进行告知c++
                window.comm_type_get_encode_back && window.comm_type_get_encode_back('DataError',JSON.stringify({
                    index : childIndex,
                    errorInfo : e,
                    errorPosition : j  //不能直接给错误数据，因为可能是decode或者Json.parse引起的错误，而且数据量还会大
                }));
                //在消费每一次的数据的时候出现任何问题后，确保下一条数据的正确执行  return是为了不会重复消费
                return consumeServerData(runArr.slice(0),i,++j);
            }
            console.log('===========test encode================>consumeServerData 其他错误！');
        }
        // setTimeout(function () {
            console.log('!!!!!!!!!!!!!!test encode!!!!!!!!!!!!!!!!!!!!!!!!>consumeServerData 结束一次！');
            //保证所有的缓存数据都被消费掉
            if(seaConf.cToJsCacheArr.length > 0){
                //消费数据的同时有新数据传入
                consumeServerData();
            }else{
                //表示这次的消费截止了
                console.log('===========test encode================>consumeServerData 运行完，重设task状态！');
                seaConf.cToJsChildTaskEnd = true;
            }
        // },500);
    }

    //两个挂载到window的函数，用于和c++通信
    ////window function to get data from Cef(Server data) 用于c++向js发送信息
    window.comm_type_get= function(type,jsonStr){
        //for mac test
        //if(typeof jsonStr=='object'){
        //    try {
        //        console.log('--------------------------------------test jsonStr :');
        //        console.log('--------------------------------------json :');
        //        console.log(jsonStr);
        //        if(type=='url'){
        //            console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!受到加密后的是：'+jsonStr.url);
        //            console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!解密之后是 ：'+window.MyBase64.decode(jsonStr.url));
        //        }
        //        jsonStr=JSON.stringify(jsonStr);
        //    }catch (e){
        //        console.error('--------------------------------------failed when turn json to jsonStr:'+e);
        //    }
        //    jsonStr=JSON.stringify(jsonStr);
        //}
        console.log("client->js:",type,jsonStr);
        seaCheck.getCheckData(type,jsonStr);
    }

    window.comm_type_get_encode = function (dataIndex, arrStr) {
        try{
            console.log("client->js:",dataIndex,arrStr);
            seaConf.cToJsCacheArr.push({
                dataIndex : dataIndex,
                data : arrStr
            });
            console.log('===========test encode================>comm_type_get_encode enter:');
            console.log(seaConf.cToJsCacheArr.length);
            if(seaConf.cToJsChildTaskEnd){
                console.log('===========test encode================>comm_type_get_encode 上次任务已经结束:');
                //消费cache数据
                consumeServerData();
            }else{
                console.log('===========test encode================>comm_type_get_encode 上次任务尚未结束:');
            }
        }catch (e){
            console.warn('|-------------comm_type_get_encode---------->消费服务器数据时出错!');
            console.warn(e);
        }
    }

    //function used to send data to the outer（c++/mac/ios/....）  用于js向c++通信
    window.comm_type_send=function(type,jsonStr){
        try{
            console.log("js->client:",type,jsonStr);
            //for mac test
            if(seaConf.host.mainHost==='mac'){
                window.webkit.messageHandlers.AcJs_get.postMessage(JSON.stringify({type:type,value:jsonStr}));
                return;
            }
            //window.AcJs_get(type,jsonStr); 调用c++预先定义的函数
            if(!seaConf.isSupportEncodeFunc){
                window.AcJs_get(type,jsonStr);
            }else{
                seaConf.jsToCArr.push({
                    type : type,
                    value : JSON.parse(jsonStr)
                });
                //判断当前是否在时间段内
                if(seaConf.jsToCTimer == null){
                    //未在时间段内，启动监听
                    seaConf.jsToCTimer = window.setTimeout(function () {
                        try{
                            var targetData = JSON.stringify(seaConf.jsToCArr.splice(0));
                            window.AcJs_get_encode(targetData);
                        }catch (e){
                            console.warn('|-------------AcJs_get_encode---------->发送到C++时出错!');
                            console.warn(e);
                        }finally{
                            //还原状态
                            window.clearTimeout(seaConf.jsToCTimer);
                            seaConf.jsToCTimer = null;
                        }
                    },seaConf.jsToCTime);
                }

            }
        }catch(e){
            console.log('[%s] -----> failed to send data to cef3 : [%s]',window.getTimeNow(),e);
        }
    }
});
