/**
 *  语言包配置
 */
define(function (require, exports, module) {
    exports.lang = {
        'cn': {
            'tools': {
                'color': '颜色',
                'text': '文字',
                'paint': '画笔',
                'rec': '矩形',
                'highlighter': '荧光笔',
                'eraser': '橡皮擦',
                'undo': '回退',
                'clear': '清除',
                'drag': '拖动',
                'prev': '上一页',
                'next': '下一页',
                'sync': '同步',
                'plan': '教案',
                'teachingMaterial': '教材',
                'audio': '音频',
                'video': '视频'
            },
            'msg': {
                'msg1': '老师不在教室，不能使用白板工具',
                'msg2': '未被授权，不能使用白板工具',
                'tabVideoMsg': '正在播放音频，不能播放视频',
                'playErrorMsg': '播放失败，请稍后重试',
                'noAudio': '无音频',
                'noVideo': '无视频',
                'canUsePaint': '可以使用画笔工具啦！'
            }
        },
        'en': {
            'tools': {
                'color': 'Color',
                'text': 'Text',
                'paint': 'Paintbrush',
                'rec': 'Rectangle',
                'highlighter': 'Highlighter',
                'eraser': 'Eraser',
                'undo': 'Undo',
                'clear': 'Clear',
                'drag': 'Drag',
                'prev': 'Previous Page',
                'next': 'Next Page',
                'sync': 'Synchronize',
                'plan': 'Teaching Plan',
                'teachingMaterial': 'teachingMaterial',
                'audio': 'music',
                'video': 'video'
            },
            'msg': {
                'msg1': 'Since the teacher is not in the classroom, whiteboard can‘t be used',
                'msg2': 'You are not authorized to use whiteboard tools',
                'tabVideoMsg': 'Audio playing, unable to play video',
                'playErrorMsg': 'Play failed. Please try again later',
                'noAudio': 'No Music',
                'noVideo': 'No Video',
                'canUsePaint': 'You can paint！'
            }
        }
    }
});