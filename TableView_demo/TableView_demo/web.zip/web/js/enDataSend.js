/**
 * Created by Administrator on 2016/9/10.
 * module info:
 *        用于拆环，弥补设计补足
 *        但是使用我修改的合并js后失去了自己的意义 ，之后的话会干掉
 */
define(function (require, exports, module) {
    var seaConf=require('boardConf').conf
    exports.sendCommData= function (type,jsonStr) {
        if(type==='paint'&&seaConf.host.textType==='h5Course'&&!seaConf.h5Course.startClass){
            //当互动教材还没有开始上课时，所有的绘制信息不同步，只在本端显示
            return;
        }
        window.comm_type_send(type,jsonStr);
    }
});