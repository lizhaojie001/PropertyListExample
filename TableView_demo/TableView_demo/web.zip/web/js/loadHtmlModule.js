/**
 * Created by Administrator on 2016/8/15.
 * module info:
 *        分析完逻辑之后管理模块加载和时间调用
 */
define(function (require, exports, module) {
    exports.loadStart=function () {
        //start load module according data
        //same module between 'teen class' and 'adult class'
        // same module:moduleContain moduleCourse moduleBoard moduleUpdate CreateDataFixed
        console.log('[%s] -----------> load html',window.getTimeNow());
        require('moduleSet').loadModuleStart();//调用moduleSet模块，创建html元素
        console.log('[%s] -----------> bind event',window.getTimeNow());
        require('eventBind').eventStart();//对已经创建的html元素根据数据池进行事件的绑定
    }
});