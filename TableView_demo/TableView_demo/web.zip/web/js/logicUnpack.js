/**
 * Created by Administrator on 2016/8/15.
 * module info:
 *        逻辑管理模块
 *        统一处理逻辑初始化逻辑，服务器下发数据类型分发
 *        和iframe通信逻辑
 */
define(function (require, exports, module) {
    var seaConf=require('boardConf').conf,
        seaLang = require('lang').lang,
        seaLoad=require('loadHtmlModule'),
        seaTools=require('moduleTools'),
        seaDataSend=require('enDataSend'),
        animate = require('animate').animate;

    //固定算法，tg教材 其中的3是为了弥补接口的错误
    var CalculateOffset=function (cx, cy, emType)
    {
        var x=0,y=0;
        var temX=cx,temY=cy;
        switch(parseInt(emType))
        {
            case 0:
                break;
            case 1:
                temX = cx * 732 / 1000;
                temY = temX / 2;
                x = cx * 265 / 1003;
                y = cy * 117 / 503;
                break;
            case 2:
                temX = cx * 268768 / 367500;
                temY = temX * 153853 / 268768;
                x = cx * 870 / 3675;
                y = cy * 49244 / 210000;
                break;
            case 3:
                break;
            default:
                break;
        }

        return {marginX:parseInt(x),marginY:parseInt(y),width:parseInt(temX),height:parseInt(temY)};
    }

    window.iFrameParIO={//comm with iFrame 和frame做交互的对象
        'parentCon':null,//object of parent IFrame,used to achieve comm with iframe 用于存储子iframe的对象，用于调用子iframe内的方法
        //init function  when course is loaded  当课程被下载完后的初始化操作
        'initI': function (cur,count) {
            console.log('[%s] -----------> init page data: {curpage: %d ,countpage: %d }',window.getTimeNow(),cur,count);
            //更新本地页码信息
            seaConf.classInfo.textInfo.curPage=parseInt(cur);
            seaConf.classInfo.textInfo.countPage=parseInt(count);

            //-------------------------------------------------for h5Course demo----------------------------------------------------------------
            //分别更新互动教材和pdf的页码信息
            seaConf[seaConf.host.textType].countPage=parseInt(count);
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------

            //更新服务器页码信息
            seaConf.classInfo.serverInfo.countPage=parseInt(count);
            seaConf.classInfo.serverInfo.curPage=seaConf[seaConf.host.textType].curPage;
            if(seaConf.classInfo.serverInfo.curPage!=seaConf.classInfo.textInfo.curPage){
                //如果当支持互动教材的新版本切到pdf时，防止停留在第一页
                seaTools.agentTools('gopage',{targetPage:seaConf.classInfo.serverInfo.curPage});
            }

            //-------------------------------------------------for h5Course demo  有风险-----------------------------------------------------------------
            if(seaConf.host.textType!=='h5Course'){
                //更新iframe内的鼠标样式
                if(seaConf.host.classType=='teen'){//青少
                    this.parentCon.document.body.style.cursor=seaConf.cursor.teen.normal;
                }
                else{
                    this.parentCon.document.body.style.cursor=seaConf.cursor.normal.normal;
                }
            }
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------

            //如果页码模块存在  初始化总页码，然后显示模块
            if(seaConf.moduleSet.page){//if page module is alive
                $('#numPages').text('/ '+count);
                $('#toolbar_id').css('display','inline-block');
            }
            //draw is ready  更新观察者
            seaConf.classInfo.drawInfo.ready=true;
            //consume the data from svc when course is not ready  清空缓存池中的数据
            logicUnpack.clearCache();
            //初始化一次工具
            seaTools.agentTools('tools',{type:seaConf.board.curToolType})
        },
        //init board's items
        'dataDrawI': function (wid,hei,left,top) {
            // console.log(wid,hei,left,top)
            //根据拿到的教材信息走固定算法得出可绘制区域的大小和边距对象
            var tem=null;
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            if(seaConf.host.textType==='h5Course'){
                //all default for h5Course demo
                tem={
                    marginX:left,
                    marginY:top,
                    width:wid,
                    height:hei
                };
            }else{
                tem=CalculateOffset(wid,hei,seaConf.course.metrialType);
            }
            //-----------------------------------------------------------------------------------------------------------------------------------

            //ensure data is fresh  数据保鲜，更新数据池
            seaConf.classInfo.textInfo.width=wid;
            seaConf.classInfo.textInfo.height=hei;
            seaConf.classInfo.textInfo.rate=hei / wid;
            seaConf.classInfo.drawInfo.width=tem.width;
            seaConf.classInfo.drawInfo.height=tem.height;
            //ensure wid and hei is the max 确保充满
            wid=Math.max(wid,$('#showDomain').width());
            hei=Math.max(hei,$('#showDomain').height());
            //设置教材显示的高度
            $('#showDomain').css({
                'height': hei
            });
            //判断画板模块存在 然后设置画布的大小和位置
            if(seaConf.moduleSet.board){
                var tw=0,
                    th=0,
                    tl=0,
                    tt=0;
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                if(seaConf.host.textType==='h5Course'){
                    //all default for h5Course demo
                    tw=tem.width;
                    th=tem.height;
                    tl=tem.marginX;
                    tt=tem.marginY;
                }else{
                    tw=tem.width;
                    th=tem.height;
                    tl=left+tem.marginX+($('#workSpace').width()-wid)/ 2;
                    tt=top+tem.marginY;
                }
                //-----------------------------------------------------------------------------------------------------------------------------------

                seaTools.reviewCanvas(tw,th,tl,tt);
            }
            // 重置教材大小
            window.iFrameParIO.pdfCourse.resize();
            if (seaConf.classInfo.drawInfo.teaScrollDisable) {
                return
            } else {
                $('#scrollbar1').tinyscrollbar_update();
            }
        },
        //unused after 2.6,this will make something is wrong,bad way 已经废弃了
        'removeScrollI': function (wid) {
            console.log('[%s] -----------> height taller and remove scroll',window.getTimeNow());
            //when offset of height is less than 100px,we let width become litter and remove scroll
            $('#showDomain').width(wid);
            $('#showDomain').css('left', function () {
                return ($('#workSpace').width()-wid)/2;
            });
            if(seaConf.host.textType==='pdf'){
                //make iFrame child's resize event
                this.pdfCourse.resize();
            }else if(seaConf.host.textType==='h5Course'){
                this.H5Course.resize();
            }
        },
        //used to set course's page  用于设置iframe（教材）的页码
        'setPageO': function (num) {
            //pdf和h5Course的分别管理
            if(seaConf.host.textType==='pdf'){
                //make iFrame child's resize event
                this.pdfCourse.setPage(num);
            }else if(seaConf.host.textType==='h5Course'){
                this.H5Course.setPage(num);
            }
        },
        //unused after 2.6,this will make something is wrong,bad way 已经废弃了
        'resetModuleO': function () {
            $('#showDomain').css('left',0);
            this.parentCon.resetscroll=true;
        },
        //notify iframe to resize 通知课件进行resize操作，iframe不做多余的resize监听
        'resizeEventO': function () {
            if(seaConf.host.textType==='pdf'){
                //make iFrame child's resize event
                // console.log('resizeEventO')
                this.pdfCourse.resize();
            }else if(seaConf.host.textType==='h5Course'){
                this.H5Course.resize();
            }
        },
        //for iframe to get course url 用于iframe请求当前教材的信息
        'getUrlO': function () {
            return seaConf.host.textUrl;
        },
        //for pdf ,when pdf loaded is bad ,notify outer reload  用于pdf专属的接口：当下载的pdf出现问题后，通知客户端进行不同的操作
        'loadMes': function (info) {
            window.comm_type_send('load',info);
        },
        'setDrawConf': function (flag) {
            seaConf.pdf.doResize = flag;
        },
        //统一管理pdf的通知
        'pdfCourse': {
            resize: function () {
                window.iFrameParIO.resizePage({
                    callback: function (canvasW, canvasH) {
                        window.iFrameParIO.parentCon.handleChlIO.resize();  // 此处的resize实际就是执行里面dataDrawI方法（异步最后执行）传出配置给父的dataDrawI,但是触发resize的前提是宽高都变，在上墙时不会触发，需手动调用父的dataDrawI
                        setTimeout(function () {
                            // MAC端改变窗口可能不会自动resize，需手动resize
                            if (seaConf.isMac && !seaConf.pdf.doResize) {
                                seaConf.pdf.doResize = true;
                                // 避免多次执行
                                if (seaConf.pdf.resizeTimes > 0) {
                                    seaConf.pdf.resizeTimes = 0;
                                    return
                                }
                                seaConf.pdf.resizeTimes++;
                                console.log('---------canvas resize------', canvasW, canvasH)
                                // 手动resize
                                window.iFrameParIO.parentCon.handleChlIO.draw(canvasW + 'px', canvasH + 'px');
                            }

                            seaConf.pdf.doResize = false;
                            //处理当缩放时产生的当前教材的错位
                            window.iFrameParIO.pdfCourse.setPage(seaConf.classInfo.textInfo.curPage);
                        }, 10)
                    }
                });
            },
            setPage: function (num) {
                window.iFrameParIO.parentCon.handleChlIO.setPage(num);//初始化页数
            }
        },
        'changeCourse': function (obj) {
            console.log('[%s] -----------> change course to %s',window.getTimeNow(),obj.targetCourse);
            seaConf.classInfo.drawInfo.ready=false;
            if(obj.targetCourse==='pdf'){
                if(obj.urlData&&obj.urlData.url){
                    var urlTem=window.MyBase64.decode(obj.urlData.url);
                    if(urlTem.split('?')[0]!=seaConf.host.textUrl.pdf.split('?')[0]){
                        console.log('[%s] -----------> urlData is %s',window.getTimeNow(),JSON.stringify(obj.urlData));
                        //如果新的url存在
                        // 先回归pdf页码信息
                        seaConf.pdf.curPage=1;
                        // 再更新当前的pdf路径
                        seaConf.host.textUrl.pdf=urlTem;
                    }
                }
                seaConf.host.textType='pdf';
                $("#paintBoard").show();
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                //还原白板背景颜色
                $("#paintBoard").css("background-color", "transparent");

                if((seaConf.user.type==='stu'&&seaConf.course.courseType==='1v1')||seaConf.user.type==='tea'){//user's type is allowed to draw 允许老师和学生绘制的逻辑
                    console.log('[%s] -----------> update board to canDraw(true) when changeCourse(1v1 stu pdf)',window.getTimeNow());
                    seaConf.course.canDraw=true;//更新注明该用户拥有可以绘制的权利
                    //update conf of WEBTools
                    seaTools.updateBoardConf({'paintModule':'draw'});//通知白板
                }
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                $('#showDomain').attr('src','./courseLoad/pdf/pdf.html?'+new Date().getTime());

                //init obj iFrame
                window.iFrameParIO.parentCon=$(window.parent.document).contents().find("#showDomain")[0].contentWindow;

            }else if(obj.targetCourse==='h5Course'){
                if(obj.urlData&&obj.urlData.countNum){
                    //如果新的url存在
                    // 先回归互动教材页码信息
                    seaConf.h5Course.curPage=1;
                    // 再更新当前的互动教材路径
                    console.log('[%s] -----------> urlData is %s',window.getTimeNow(),JSON.stringify(obj.urlData));
                    seaConf.host.textUrl.h5Course=obj.urlData;
                }
                seaConf.host.textType='h5Course';
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                //如果是互动教材，白板是透明色
                if(seaConf.host.textType==='h5Course'&&seaConf.user.type==='tea'){
                    $("#paintBoard").css("background-color", seaConf.h5Course.canvasColor);
                }

                // if(seaConf.user.type==='stu'){//互动教材学生不可绘制
                //     console.log('[%s] -----------> update board to canDraw(false) when changeCourse(stu h5Course)',window.getTimeNow());
                //     seaConf.course.canDraw=false;//更新注明该用户拥有可以绘制的权利
                //     //update conf of WEBTools
                //     seaTools.updateBoardConf({'paintModule':'draw'});//通知白板
                // }
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                $("#paintBoard").hide();
                $('#showDomain').attr('src',seaConf.host.textUrl.h5Course.urlControl+'?'+new Date().getTime());
            }
        },
        'H5Course':{
            init: function () {
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                if(window.iFrameParIO.parentCon.sendSyncData===undefined){
                    //iframe 加载失败
                    console.error('[%s] -----------> failed to load controller.html,change course type!',window.getTimeNow());
                    var tem_e={
                        'type':'error'
                    }
                    seaDataSend.sendCommData('H5CourseLoad',JSON.stringify(tem_e));
                    return false;
                }else{
                    var user=seaConf.user;
                    var teaState=user.type=='tea'?'in':(user.teaLogin?'in':'out');
                    var classT=seaConf.course.courseType;
                    var lan=seaConf.host.language;
                    var courseid=seaConf.course.courseId;
                    var initObj={
                        userInfo:{
                            userType:user.type,
                            userId:user.userId,
                            teaState:teaState
                        },
                        classInfo:{
                            classType:classT,
                            language:lan
                        },
                        courseInfo:{
                            courseId:courseid,
                            pageCount:seaConf.host.textUrl.h5Course.countNum,
                            headUrl:seaConf.host.textUrl.h5Course.headUrl
                        },
                        startClass:seaConf.h5Course.startClass,
                        startPractice:seaConf.h5Course.startPractice
                    };
                    console.log('[%s] -----------> parentIFrame : send init data :',window.getTimeNow());
                    if(window.iFrameParIO.parentCon.sendSyncData){
                        window.iFrameParIO.parentCon.sendSyncData('init',initObj);
                    }else{
                        console.error('[%s] -----------> parentIFrame : error happened when send init data to child',window.getTimeNow());
                    }

                    //for test
                    window.iFrameParIO.initI(1,seaConf.host.textUrl.h5Course.countNum);

                    return true;
                }
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            },
            resize:function () {
                // alert('resize')
                if(!seaConf.h5Course.resizeFirst){
                    var temObj={
                        type:'resize'//resize
                    };
                    window.iFrameParIO.H5Course.notify(temObj);
                }
                seaConf.h5Course.resizeFirst=false;
            },
            setPage:function (num) {
                var temObj={
                    type:'page',//翻页通知
                    targetNum:num//目标页码
                };
                window.iFrameParIO.H5Course.notify(temObj);
            },
            comm: function (obj) {
                var temObj=obj;
                temObj.uuid=0;
                console.log('[%s] -----------> parentIFrame : get data from svc and send to child',window.getTimeNow());
                console.log(temObj);
                if(window.iFrameParIO.parentCon.sendSyncData){
                    window.iFrameParIO.parentCon.sendSyncData('comm',temObj.specialValue.value);
                }else{
                    console.error('[%s] -----------> parentIFrame : error happened when send svc data to child',window.getTimeNow());
                }
            },
            notify: function (obj) {
                if(window.iFrameParIO.parentCon.sendSyncData!==undefined){
                    console.log('[%s] -----------> parentIFrame : send notify data',window.getTimeNow());
                    console.log(obj);
                    if(window.iFrameParIO.parentCon.sendSyncData){
                        window.iFrameParIO.parentCon.sendSyncData('notify',obj);
                    }else{
                        console.error('[%s] -----------> parentIFrame : error happened when send notify data to child',window.getTimeNow());
                    }
                }
            },
            sendMSG: function (type,obj) {
                switch (type){
                    case 'svcMes':
                        console.log('[%s] -----------> parentIFrame : get svcMes data :',window.getTimeNow());
                        console.log(obj);

                        var temObj={
                            'handleType':0,//add
                            'drawingType':400,//ppt
                            'id':1000,
                            'specialValue':{
                                value:obj
                                //value:JSON.stringify(obj)
                            }
                        }
                        seaDataSend.sendCommData('paint',JSON.stringify(temObj));
                        break;
                    case 'loadData':
                        //now unused
                        break;
                    case 'startClass':
                        if(obj.type==='startClass'&&!seaConf.h5Course.startClass){
                            console.log('[%s] -----------> parentIFrame : get startClass:',window.getTimeNow());
                            console.log(obj);
                            seaConf.h5Course.startClass=true;
                            if(seaConf.user.type==='tea'&&obj.firstTime){
                                seaTools.agentTools('gopage',{targetPage:'1'});
                            }
                            // seaTools.agentTools('startClass',obj);
                        }
                        break;
                    case 'startPractice':
                        if(obj.type==='startPractice'&&!seaConf.h5Course.startPractice){
                            console.log('[%s] -----------> parentIFrame : get startPractice:',window.getTimeNow());
                            console.log(obj);
                            seaConf.h5Course.startPractice=true;
                            //这里应该判断是老师还是第一次点击的事件
                            //...
                            seaTools.agentTools('startPractice', obj);
                        }
                        break;
                    case 'backFirst':
                        if(obj.type==='backFirst'){
                            console.log('[%s] -----------> parentIFrame : get backFirst:',window.getTimeNow());
                            console.log(obj);
                            if(seaConf.user.type==='tea'){
                                seaTools.agentTools('gopage',{targetPage:'1'});
                            }
                        }
                        break;
                    case 'updateStuPage'://供老师端使用 用于同步学生的页码
                        if(seaConf.user.type==='tea'){
                            console.log('[%s] -----------> parentIFrame : get updateStuPage:',window.getTimeNow());
                            console.log(obj);
                            seaTools.agentTools('updateStuPage',{targetPage:obj.targetPage});
                        }else{
                            console.error('[%s] -----------> parentIFrame : error happened when stu get updateStuPage',window.getTimeNow());
                        }
                        break;
                    case 'pageInit':
                        console.error('[%s] -----------> parentIFrame : wrong function is used!',window.getTimeNow());
                        console.error('wrong function is used!');
                        //console.log('['+window.getTimeNow()+']'+'----------->'+'parentIFrame : get page data :');
                        //console.log(obj);
                        //var cur= obj.currentPage,
                        //    count=obj.pageCount;
                        //window.iFrameParIO.initI(cur,count);
                        break;
                    case 'boardSet':
                        var top= obj.top,
                            left=obj.left,
                            width=obj.width,
                            height=obj.height;
                        console.log('[%s] -----------> parentIFrame : set whiteBoard data :',window.getTimeNow());
                        console.log('                ---------------------------------->(top,left,width,height)(%d,%d,%d,%d)',top,left,width,height);
                        window.iFrameParIO.dataDrawI(width,height,left,top);
                        break;
                    case 'tool':
                    //console.log('******************************************parentIFrame : get tool data :');
                    //console.log(obj);
                    //var st=obj.switch;//get switch type  on or off
                    //if(st==='on'){
                    //    seaConf.board.pauseDraw=false;
                    //    seaTools.updateBoardConf({'pauseDraw':false});//update Board conf
                    //    $('#paintBoard').show();
                    //}else{
                    //    seaConf.board.pauseDraw=true;
                    //    seaTools.updateBoardConf({'pauseDraw':true});//update Board conf
                    //    $('#paintBoard').hide();
                    //}
                    //break;
                    default:
                        break;
                }
            }
        },
        'getPdfDoc': function (callback) {
            var pdfDoc = window.iFrameParIO.parentCon.handleChlIO.getPdfDoc();
            if (pdfDoc) {
                pdfDoc.getPage(seaConf.classInfo.textInfo.curPage).then(function(page) {
                    var viewport = page.getViewport({scale: 1});
                    callback({
                        pageWidth: viewport.viewBox[2],
                        pageHeight: viewport.viewBox[3]
                    });
                });
            }
        },
        'resizePage': function (params) {
            var contW = $('#workContainer').width();
            var contH = $('#workContainer').height();
            if (seaConf.firstIn) {
                contH = contH - 99; // 去掉工具栏的高度
                seaConf.firstIn = false;
            }
            try {
                window.iFrameParIO.getPdfDoc(function (conf) {
                    var pageW = conf.pageWidth;
                    var pageH = conf.pageHeight;
                    var pageRate = pageW / pageH;
                    if (pageRate >= 1) { // 横版教材
                        if (pageRate <= contW / contH) { // 教材宽高比 小于 屏幕宽高比
                            contW = Math.round(contH * pageRate);
                            // 高度充满，宽度自适应，水平居中显示
                            $('#showDomain').css({
                                'top': 0,
                                'left': '50%',
                                'transform': 'translateX(-50%)'
                            });
                        } else {
                            var prevConH = contH;
                            contH = Math.round(contW / pageRate);
                            // 宽度充满，高度自适应，垂直居中显示
                            $('#showDomain').css({
                                'left': 0,
                                'top': '50%',
                                'transform': 'translateY(-50%)'
                            });
                            // 画板同步调整位置
                            $('#paintBoard').css({
                                'left': 0,
                                'top': (prevConH - contH) / 2 + 'px'
                            });
                        }
                        //设置css
                        $('#showDomain').css({
                            'width': contW,
                            'height': contH,
                        });
                    } else {
                        // 竖版教材，宽度铺满屏幕，高度自适应
                        var tempPageH = pageH * contW / pageW;
                        $('#showDomain').css({
                            'width': contW,
                            'height': tempPageH,
                            'top': 0,
                            'left': 0
                        });
                    }
                    if (params.callback) {
                        params.callback(contW, contH);
                    }
                })
            } catch(e) {

            }
        }
    }
    var logicUnpack={
        //unpack info that get from server according company's business logic to load different module
        //根据公司的业务逻辑将从服务器拿到的数据信息解包以便加载不同的模块
        'conf':{//这里是一些固定的配置信息
            'courseRole':{
                '0':'student',
                '1':'1v1 teacher',
                '4':'open lecture teacher',
                '5':'PSO student',
                '6':'PSO teacher',
                '7':'chinese teacher',
                '64':'cc'//can not draw
            },
            'courseStyle':{
                '0':'1v1',
                '1':'open lecture',
                '2':'multi video classroom',
                '3':'experience lecture',
                '4':'competitive Small-class-based lecture',
                '5':'active open lecture',
                '6':'PSO training lecture',
                '7':'SA open lecture',
                '8':'PT ways lecture',
                '9':'CEGC(CE Unit lecture)',
                '10': 'chinese teacher lecture',
                '12':'B2S open lecture',
                '13':'class lecture'
            },
            'userRole':{
                '-1':'guest',
                '0': 'student',
                '1':'1v1 teacher',
                '2':'experience user',
                '3':'unKnow type',
                '4': '1vn teacher',
                '5':'PSO student',
                '6':'PSO teacher',
                '7':'chinese teacher',
                '16':'control',
                '64':'cc sales',
                '65':'crit',
                '99':'1vN administrator'
            },
            'userType':{
                '1':'teacher',
                '2':'student',
                '3':'administrator',
                '4':'customer service'
            },
            'textType':{
                '0':'pdf',
                '1':'ppt',
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                '2':'h5Course'
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            },
            'teaType':[1,4,6,7],
            'stuType':[0,3,5]
        },
        'init': function (type,obj) {
            //init handle data
            switch (type){
                case 'course':
                    seaConf.serverData.objCourseInfo=obj;
                    console.log('[%s] -----------> objCourseInfo: %s',window.getTimeNow(),JSON.stringify(obj));
                    break;
                case 'user':
                    seaConf.serverData.objUserInfo=obj;
                    console.log('[%s] -----------> objUserInfo: %s',window.getTimeNow(),JSON.stringify(obj));
                    break;
                case 'host':
                    seaConf.serverData.objHostInfo=obj;
                    console.log('[%s] -----------> objHostInfo: %s',window.getTimeNow(),JSON.stringify(obj));
                    break;
                case 'url':
                    seaConf.serverData.objURLInfo=obj;
                    console.log('[%s] -----------> objURLInfo: %s',window.getTimeNow(),JSON.stringify(obj));
                    break;
                case 'courseAll':
                    seaConf.serverData.objCourseAllInfo=obj;
                    console.log('[%s] -----------> objCourseAllInfo: %s',window.getTimeNow(),JSON.stringify(obj));
                    break;
                default :
                    console.warn('[%s] -----------> objOtherInitInfo: %s', window.getTimeNow(),JSON.stringify(obj));
                    return;
                    break;
            }

            //ensure all data for loading html had been accepted  确保运行前拿到了所有的必要数据
            if(seaConf.serverData.objCourseInfo!=null
                &&seaConf.serverData.objUserInfo!=null
                &&seaConf.serverData.objHostInfo!=null
                &&seaConf.serverData.objURLInfo!=null)
            {
                var aliasCourse = seaConf.course,//课程信息别名
                    aliasUser = seaConf.user,//用户信息别名
                    aliasHost = seaConf.host,//宿主信息别名
                    aliasServerData = seaConf.serverData;//服务端信息别名
                //下面的字段详见数据池注释
                //course info
                //是否可以翻页
                aliasCourse.turnPage = (aliasServerData.objCourseInfo.CanTurnPage!=undefined)?
                    (aliasServerData.objCourseInfo.CanTurnPage==1?true:false):true;
                //教材类型0 1 2 3
                aliasCourse.metrialType = aliasServerData.objCourseInfo.metrialtype||0;
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                aliasCourse.courseId = aliasServerData.objCourseInfo.courseId||'';
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                //教材详细类型
                aliasCourse.courseStyle =aliasServerData.objCourseInfo.coursestyle&&logicUnpack.conf.courseStyle[aliasServerData.objCourseInfo.coursestyle]|| 'undefined';
                //教材类型 1v1 1vN？
                aliasCourse.courseType = (aliasServerData.objCourseInfo.coursestyle!=undefined)?
                    (aliasServerData.objCourseInfo.coursestyle==0?'1v1':'1vN'):'1v1';

                //判断是否为多视频教室
                aliasCourse.isMultiVC=aliasServerData.objCourseInfo.coursestyle===2?true:false;

                //获取当前的课程开始的时间
                aliasCourse.startedTime=aliasServerData.objCourseInfo.startedTime||0;
                //user info
                //用户信息 tea stu other
                aliasUser.type = "other";
                if(aliasServerData.objCourseInfo.courserole!=undefined){
                    if(logicUnpack.conf.teaType.indexOf(aliasServerData.objCourseInfo.courserole)!=-1)aliasUser.type = "tea";
                    if(logicUnpack.conf.stuType.indexOf(aliasServerData.objCourseInfo.courserole)!=-1)aliasUser.type = "stu";
                }
                //cc的逻辑
                if(aliasServerData.objCourseInfo.courserole!=undefined){
                    if(aliasServerData.objCourseInfo.courserole==64){//cc的逻辑
                        aliasUser.type='cc';
                    }else if(aliasServerData.objCourseInfo.courserole==65){//crit的逻辑
                        aliasUser.type='crit';
                    }
                }

                aliasUser.courseRole = aliasServerData.objCourseInfo.courserole&&logicUnpack.conf.courseRole[aliasServerData.objCourseInfo.courserole]||'undefined';
                aliasUser.userRole = aliasServerData.objUserInfo.userrole&&logicUnpack.conf.userRole[aliasServerData.objUserInfo.userrole]||'undefined';
                aliasUser.userType = aliasServerData.objUserInfo.usertype&&logicUnpack.conf.userType[aliasServerData.objUserInfo.usertype]||'undefined';
                aliasUser.userId = aliasServerData.objUserInfo.userid||'undefined';
                //host info
                aliasHost.mainHost = aliasServerData.objHostInfo.mainhost||'undefined';
                aliasHost.language = aliasServerData.objHostInfo.language||'cn';
                aliasHost.versionType = aliasServerData.objHostInfo.versionType||'undefined';
                aliasHost.tipData.fixedData=(aliasServerData.objHostInfo.tipdata!=undefined)?
                    (aliasServerData.objHostInfo.tipdata.fixdata!=undefined?aliasServerData.objHostInfo.tipdata.fixdata:false):false;
                aliasHost.tipData.scrollData=(aliasServerData.objHostInfo.tipdata!=undefined)?
                    (aliasServerData.objHostInfo.tipdata.scrollData!=undefined?aliasServerData.objHostInfo.tipdata.fixedData:true):true;
                aliasHost.textType=aliasServerData.objHostInfo.textType&&logicUnpack.conf.textType[aliasServerData.objHostInfo.textType]||'pdf';
                // aliasHost.textType = 'h5Course'; //临时写死成h5的教材
                seaConf.h5Course.open=aliasHost.textType=='pdf'?false:true;//如果刚开始是pdf，则表示当前不支持新协议：pageNew
                aliasHost.textUrl=aliasServerData.objURLInfo||'undefined';
                aliasHost.classType=aliasServerData.objHostInfo.showtype||'normal';
                aliasHost.tools=aliasServerData.objHostInfo.toolsconf||aliasHost.tools;

                if(aliasUser.courseRole==5){
                    //PSO stu
                    seaConf.board.stu.pencil.color='#FF0000';
                }else if(aliasUser.courseRole==6){
                    //PSO tea
                    seaConf.board.tea.pencil.color='#0078FF';
                }

                //判断是否支持encode function
                (window.AcJs_get_encode != undefined) && (seaConf.isSupportEncodeFunc = true);

                //--------------------------------------for h5Course demo  (增加&& aliasHost.textType!='h5Course')-------------------------------------------------------
                //固定逻辑（老师都可以绘制，pdf:1v1学生可以绘制 H5Course：学生能使用画笔）
                if(aliasUser.type==='stu'||aliasCourse.courseType==='1v1'||aliasUser.type==='tea'){//user's type is allowed to draw 允许学生绘制的逻辑
                    console.log('[%s] -----------> update board to canDraw(true) when initData(1v1 stu and tea)',window.getTimeNow());
                    aliasCourse.canDraw=true;//更新注明该用户拥有可以绘制的权利
                    //update conf of WEBTools
                    seaTools.updateBoardConf({'paintModule':'draw'});//通知白板
                }
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                //update edit for drawing 固定逻辑，当有新的橡皮开放或者拖拽功能开放时版本统一置为new，主要针对是否支持重写操作
                // aliasHost.tools.rub = true;  // 临时置为true
                // aliasHost.tools.newrub = false;  // 临时置为false
                if(aliasHost.tools.newrub||aliasHost.tools.draft){
                    seaConf.board.version='new';
                    seaTools.updateBoardConf({'version':'new'});
                }

                console.log('[%s] -----------> result:',window.getTimeNow());
                console.log('                                ----->'+'user: %s',JSON.stringify(aliasUser));
                console.log('                                ----->'+'course: %s',JSON.stringify(aliasCourse));
                console.log('                                ----->'+'host: %s',JSON.stringify(aliasHost));

                var courseTypeEx = seaConf.serverData.objCourseAllInfo.courseTypeEx;

                //固定逻辑
                if(aliasUser.type=='tea'){
                    //老师支持滚动提示
                    aliasHost.tipData.scrollData=true;//更新提示信息中的滚动信息哨兵
                    seaConf.moduleSet.dataScroll=true;//更新模块配置中的滚动模块哨兵
                    seaConf.moduleSet.tabMenu=true;//更新模块配置中身份为老师就展示切换教材的信息哨兵(此版本无论老师还是学生都暂不显示menu)

                    seaConf.event.barScroll=true;//teacher's scroll event 更新事件配置中的滚动条事件哨兵（用于同步两端的滚动条）
                    seaConf.event.mouse=true;//teacher's mouse event  更新事件配置中的鼠标事件哨兵（用于同步两端的鼠标位置）
                    seaConf.event.scrollData=true;//更新事件配置中的滚动信息提示哨兵

                    if(aliasHost.tipData.fixedData){//判断是否存在固定提示信息
                        seaConf.event.fixedData=true;//更新事件配置信息的固定提示哨兵
                        seaConf.moduleSet.dataFixed=true;//更新模块配置信息中的固定模块哨兵
                    }

                    //1VN和1V1的青少配置H5画板工具栏
                    // if(seaConf.course.courseType=='1vN' || (seaConf.course.courseType=='1v1' && (courseTypeEx==4 || courseTypeEx==5 || courseTypeEx==6 || courseTypeEx==7))){
                    if(seaConf.course.courseType=='1vN' || seaConf.course.courseType=='1v1'){
                        seaConf.moduleSet.page=true;//更新模块配置中的翻页模块哨兵
                        seaConf.moduleSet.tools=true;//更新模块配置中的工具条模块哨兵
                    }

                    //1V1不显示提示
                    if(seaConf.course.courseType=='1v1'){
                        seaConf.moduleSet.dataScroll=false;
                        seaConf.moduleSet.dataFixed=false;
                    }

                    //老师显示特效关闭/重播按钮
                    animate.btnVisible(true);

                }else{//非老师
                    seaConf.moduleSet.tools=true;// 强制更改tools模块哨兵?
                    //当为1vN并且可以翻页的时候 更新模块配置中的翻页哨兵
                    if(seaConf.course.courseType=='1vN'&&seaConf.course.turnPage){
                        seaConf.moduleSet.page=true;//更新模块配置中的翻页模块哨兵
                    }else if(seaConf.course.courseType=='1v1'){
                        seaConf.event.mouse=true;//student's mouse event  更新事件配置信息的鼠标事件哨兵
                        seaConf.moduleSet.page=true;//更新模块配置中的翻页模块哨兵
                    }
                }

                //MAC必显示画板工具栏
                // if(seaConf.host.mainHost==='mac'){
                //     seaConf.moduleSet.page=true;
                //     seaConf.moduleSet.tools=true;
                // }

                //如果是多视频教室 打开时间提示模块 关闭信息提示
                if(aliasCourse.isMultiVC){
                    seaConf.moduleSet.timeTip=true;
                    seaConf.event.timeTip=true;

                    aliasHost.tipData.scrollData=false;//更新提示信息中的滚动信息哨兵
                    seaConf.moduleSet.dataScroll=false;//更新模块配置中的滚动模块哨兵
                    seaConf.event.fixedData=false;//更新事件配置信息的固定提示哨兵
                    seaConf.moduleSet.dataFixed=false;//更新模块配置信息中的固定模块哨兵
                }
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                if(aliasUser.userRole==='cc sales'){
                    seaConf.moduleSet.ccLayer=true;
                }
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------


                //load html  加载html
                seaLoad.loadStart();
                //根据用户类型提取数据池中的数据初始化白板的配置
                if(aliasUser.type=='tea'){
                    seaTools.updateBoardConf(seaConf.board.tea);
                    aliasUser.teaLogin=true; //更新老师进入的字段
                    // alert('3'+seaConf.board.pauseDraw)
                    seaConf.board.pauseDraw=false;//为老师提供随时可以绘制的支持
                    console.log('[%s] -----------> update board to pause draw(false) when init and user type is tea',window.getTimeNow());
                    seaTools.updateBoardConf({'pauseDraw':false});//通知白板，打开绘制支持
                }
                else{
                    seaTools.updateBoardConf(seaConf.board.stu);
                }

                window.comm_type_send("h5_ready",JSON.stringify({}));
            }
        },
        'update': function (obj) {//处理数据
            if(!seaConf.classInfo.drawInfo.ready){//draw unready  当白板没有准备好绘制时
                seaConf.boardDataCache.push(obj);//入队列
                console.log('[%s] -----------> canvas is not ready , push data to Array : %s',window.getTimeNow(),JSON.stringify(obj));
            }
            else{
                if(obj.type=='enterout'){//teacher enter class or out  sdk下发的通知，老师进出教室的通知
                    if(seaConf.user.type!=='tea'){
                        // alert('belo'+JSON.parse(obj.jsonStr).Bl_E_O)
                        if(seaConf.user.teaLogin&&JSON.parse(obj.jsonStr).Bl_E_O==0){//屏蔽重复的通知
                            //accept teacher out when teacher is in class
                            // alert(22)
                            console.log('[%s] -----------> teacher out class',window.getTimeNow());

                            //更新哨兵
                            seaConf.user.teaLogin=false;
                            //暂停绘制功能
                            seaConf.board.pauseDraw=true;
                            console.log('[%s] -----------> update board to pause draw(true) when teacher out class',window.getTimeNow());
                            seaTools.updateBoardConf({'pauseDraw':true});//update Board conf
                            seaTools.agentTools('tools',{'type':seaConf.board.curToolType});//统一一次白板，为了触发固定逻辑
                            // if(seaConf.moduleSet.tools){//if update module is alive
                            //     $('#outerCenter').css('display','none');//当不能绘制的时候隐藏工具
                            // }
                            // if(seaConf.moduleSet.board){
                            //     seaTools.agentTools('tools',{'type':seaConf.board.curToolType});//统一一次白板，为了触发固定逻辑
                            // }
                            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                            if(seaConf.host.textType==='h5Course'){
                                var dataLogin={
                                    type:'teaState',
                                    state:'out'
                                }
                                window.iFrameParIO.H5Course.notify(dataLogin);
                            }
                            //-----------------------------------------------------------------------------------------------------------------------------------

                            //如果是英文的系统则修改提示信息
                            $('#tools_handle span').attr("title", seaLang[seaConf.host.language].msg.msg1);
                        }
                        else if(!seaConf.user.teaLogin&&JSON.parse(obj.jsonStr).Bl_E_O==1){
                            //accept teacher enter class when teacher is out class
                            console.log('[%s] -----------> teacher enter class',window.getTimeNow());
                            // alert(33)
                            //更新哨兵
                            seaConf.user.teaLogin=true;
                            // seaConf.board.pauseDraw=true;
                            seaTools.updateBoardConf({'pauseDraw':true});//update Board conf
                            seaTools.agentTools('tools',{'type':seaConf.board.curToolType});//统一一次白板，为了触发固定逻辑
                            //判断是否和老师在同一页
                            if(seaConf.classInfo.serverInfo.curPage==seaConf.classInfo.textInfo.curPage) {
                                //开启绘制功能
                                console.log('[%s] -----------> update board to pause draw(false) when teacher enter class and page number is same',window.getTimeNow());
                                // alert('4'+seaConf.board.pauseDraw)
                                // 此处可能会影响翻页 因为逻辑重新整理了
                                // seaConf.board.pauseDraw=false;
                                // seaTools.updateBoardConf({'pauseDraw':false});//update Board conf
                            }

                            if(seaConf.moduleSet.tools){//如果存在这个模块 不做显示因为是公开课本身不会有tools
                                //...
                            }
                            // if(seaConf.course.canDraw&&seaConf.moduleSet.board){
                            //     seaTools.agentTools('tools',{'type':seaConf.board.curToolType});//统一一次白板，为了触发固定逻辑
                            // }
                            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                            if(seaConf.host.textType==='h5Course'){
                                var dataLogin={
                                    type:'teaState',
                                    state:'in'
                                }
                                window.iFrameParIO.H5Course.notify(dataLogin);
                            }
                            //-----------------------------------------------------------------------------------------------------------------------------------
                            //如果是英文的系统则修改提示信息
                            $('#tools_handle span').attr("title", seaLang[seaConf.host.language].msg.msg2);
                        }
                    }
                }
                //显示or隐藏教材切换按钮
                else if(obj.type == "changebookbtn"){
                    var temObj=JSON.parse(obj.jsonStr);
                    var $btn = $(".toolContain .btn-switch");
                    if(temObj.visible == "true"){
                        $btn.show();
                    }else{
                        $btn.hide();
                    }
                }
                //播放动画
                else if(obj.type == "animate"){
                    var temObj=JSON.parse(obj.jsonStr);
                    var $div = $(".anime");
                    var $iframe = $(".anime iframe");
                    if(temObj.play == "true"){
                        animate.id = temObj.id;
                        animate.play(temObj.path);
                    }else{
                        animate.stop();
                    }
                }
                else{
                    //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                    var temObj=JSON.parse(obj.jsonStr);
                    //截取互动教材的指令信息
                    if(temObj.handleType==0&&obj.type=='paint'&&temObj.drawingType==seaConf.h5Course.idType){
                        console.log('[%s] -----------> get data:',window.getTimeNow());
                        console.log(temObj);
                        window.iFrameParIO.H5Course.comm(temObj);
                    }else{
                        seaTools.agentTools(obj.type,JSON.parse(obj.jsonStr));
                    }
                    //-----------------------------------------------------------------------------------------------------------------------------------
                }
            }
        },
        'clearCache': function () {//清除之前因为白板没准备好服务器下发的数据
            var obj={
                'cur':seaConf.classInfo.textInfo.curPage-1,
                'count':seaConf.classInfo.textInfo.countPage
            };
            //先通知一次客户端页码
            seaTools.initPageNum(obj);

            if(seaConf.moduleSet.board){//if board module is alive
                if(seaConf.boardDataCache.length!=0){//client get board data from server when board is not ready
                    console.log('[%s] -----------> cache to paint when canvas is ready',window.getTimeNow());
                    console.log('[%s] -----------> cache : ',window.getTimeNow());

                    var tem=null;
                    for(var i= 0,j=seaConf.boardDataCache.length;i<j;i++){
                        var a=seaConf.boardDataCache.shift();
                        console.log('        -----------> %s',JSON.stringify(a));
                        if(a.type!='scroll'){
                            logicUnpack.update(a);
                        }else{//屏蔽多个滚动条信息
                            tem=a;
                        }
                    }
                    if(tem!=null){//更新一次滚动条
                        logicUnpack.update(tem);
                    }
                }
            }
        }
    };

    exports.dataGet=function (type,objStr) {
        //accept server data
        //接收数据
        if(['course','user','host','url','boardSet','appointMemberList','courseAll','userAll'].indexOf(type)!=-1){//把初始化信息摘出来
            //serverData initData of loadHtml to logic module
            var obj=objStr;
            if(Object.prototype.toString.call(objStr) == '[object String]'){
                obj = JSON.parse(objStr);
            }
            if(type=='url'){
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                //obj.url=window.MyBase64.decode(obj.url);
                //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
                try {
                    console.log('---------------------type==\'url\'-------------------')
                    console.log(window.MyBase64.decode(obj.pdf))
                    console.log('---------------------type==\'url\'-------------------')
                    obj.pdf=window.MyBase64.decode(obj.pdf);
                    obj.h5Course.countNum=parseInt(obj.h5Course.countNum);
                    obj.h5Course.headUrl=window.MyBase64.decode(obj.h5Course.headUrl);
                    obj.h5Course.urlControl=window.MyBase64.decode(obj.h5Course.urlControl);
                    console.log('[%s] -----------> get URL data from client:',window.getTimeNow());
                    console.log('                      ----------->controlURL: %s',obj.h5Course.urlControl);
                    console.log('                      ----------->headSTR: %s',obj.h5Course.headUrl);
                    console.log('                      ----------->count page： %s',obj.h5Course.countNum);
                }catch (e){

                }
            }
            logicUnpack.init(type,obj);
        }
        else if(type==='changeCourse'){
            window.iFrameParIO.changeCourse(JSON.parse(objStr));
            //serverData but not initData
            var obj={
                'type':'tools',
                'jsonStr':JSON.stringify({type:'clear'})
            };
            logicUnpack.update(obj);
        }else if(type == 'testEncode'){
            console.log('===========test encode================>router enter:');
            console.log(objStr);

            window.comm_type_send('testEncodeBack',objStr);
        }
        else{//处理其他信息
            //serverData but not initData
            var obj={
                'type':type,
                'jsonStr':objStr
            };
            logicUnpack.update(obj);
        }
    };
});
