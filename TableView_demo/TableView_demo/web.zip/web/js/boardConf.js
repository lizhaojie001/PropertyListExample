/**
 * Created by Administrator on 2016/8/17.
 * module info:
 *        数据池，用于各个模块共享交互
 *        数据池中包含当前信息和固定配置信息
 */
define(function (require, exports, module) {
    exports.conf={
        'serverIOArr':[],//storage server input or out data 存储服务器的数据（缓冲池，数据节流）
        'boardDataCache':[],//storage server data when draw handle is not ready 缓冲池，用于当教材和白板没有准备好的时候存储服务器下发的数据
        'isSupportEncodeFunc':false,//指定是否支持编码的方法
        'cToJsCacheArr':[],//存发送给js的数据缓冲数组
        'cToJsChildTaskEnd':true,//表示当前的任务是否已经完成
        'jsToCArr':[],//存储向c++发送的数据
        'jsToCTime':300,//指定向c++发送数据时的时区长度
        'jsToCTimer':null,//向c++发送数据时的时间对象
        'firstIn': true, //第一次加载教材
        'serverData':{//服务器的数据，用于存储最开始从客户端接收到的数据
            'objCourseInfo':null,//class info 教室的信息
            'objUserInfo':null,//user info 用户的信息
            'objHostInfo':null,//host info 宿主信息
            'objURLInfo':null,//url info 课件信息 比如url
        },
        'user':{
            'type':'stu',//'stu'/'tea' 用户的类型
            'userRole':'',//detailed user's role 用户的详细角色信息
            'userType':'',//user's power stu/administrator/tea/... 和权限相关的类型
            'courseRole':'',//user's type in course 教室内的角色
            'userId':'',//user's id 用户的id
            'teaLogin':false,//true/false 老师是否已经进入教室
        },
        'course':{
            'turnPage':true,//true/false 教材是否可以翻页
            'canDraw':false,//if user's type can draw 本教材是否允许绘制，总开关
            'courseType':'1v1',//1v1 1vN 教室的类型
            'courseId':'',//课程id
            'metrialType':0,//drawing area 0 1 2 3 教材的类型 有固定的算法（关于pdf的显示区域问题：pdf是0和3是tg，1 普通2不常见）
            'courseStyle':0,//detailed course style 教室的详细类型
            'isMultiVC':false,//是否为多视频教室  特殊对待的1vN教室
            'startedTime':0,//当前教室已经开始的时间 ms级别
            'localTime':0//当收到客户端传来的startedTime后，记录本地的时间
        },
        'host':{
            'mainHost':'window',//reserved unused 暂时未使用，留给区分mac和window或者其他的端口
            'language':'cn',//language  语言
            'versionType':0,//if open new handle 0:no 1:yes 2:no local configure 之前的本地配置，是否开启新功能，已废弃
            'textType':'pdf',//'pdf'  'ppt' ... 教材的类型
            'textUrl':{
                pdf:'',
                h5Course:{
                    countNum:0,
                    headUrl:'',
                    urlControl:''
                },
                audioList: [],  // 音频列表
                videoList: []   // 视频列表
            },//url of text
            'classType':'normal',//'normal'  'teen' 区分青少还是成人教室
            'tipData':{//for teacher 提示信息
                'scrollData':false,//tip scrolled  滚动的提示信息
                'fixedData':false//tip fixed   固定的提示信息
            },
            'tools':{ //根据这个来判断采用哪些工具
                //工具条信息
                'color': true,
                'pen':false,//画笔
                'signpen':false,//荧光笔
                'rec':false,//矩形
                'rub':false,//旧版橡皮擦
                'newrub':false,//新版橡皮擦
                'text':false,//文字
                'draft':false,//拖拽
                'back':false,//回退
                'clear':false,//清空
            }
        },
        'moduleSet':{//根据这个来加载模块
            //module sign
            'contain':true,//主模块壳
            'update':true,//收到无法分析的信令时的提示升级信息
            'page':false,//显示页码和翻页的模块
            'tools':false,//工具条模块
            'board':true,//白板模块
            'course':true,//教材模块
            'dataScroll':false,//滚动提示信息模块
            'dataFixed':false,//固定提示信息模块
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            'ccLayer':false,
            //-------------------------------------------------for h5Course demo-----------------------------------------------------------------
            'timeTip':false,//时间提示模块
            'switch':true,//教材切换按钮
            'tabMenu':false//教材音频视频切换按钮
        },
        'event':{//事件绑定 根据这些来判断是否要绑定这些事件
            //event need to bind when html is loaded
            'mouse':false,//鼠标事件
            'barScroll':false,//滚动条同步
            'scrollData':false,//信息滚动
            'fixedData':false,//固定信息的关闭，只关闭一次不再显示
            'timeTip':false//时间提示信息
        },
        'classInfo':{//教室内信息
            'textInfo':{//教材信息
                'curPage':1,//>=1 本地当前的页码
                'countPage':0,//>=1 本地总页码
                'width':0, //本地教材的宽高
                'height':0, //本地教材的宽高
                'rate': 0
            },
            'drawInfo':{//绘制白板的信息
                'width':0,//白板宽度
                'height':0,//白板的高度
                'left':0,//白板的左边距
                'top':0,//白板的上边距
                'ready':false,//course loaded? true:false 白板是否已经准备好了可以绘制的状态
                'teaScrollDisable': false //
            },
            'serverInfo':{//服务器的信息
                //record server data
                'curPage':1,//>=1 服务器当前的页码
                'countPage':0//>=1 服务器的总页码
            },
            'cursorStyle':{//unused 未使用
                'iframe':'',
                'canvas':''
            }
        },
        'update':{//收到无法分析的信令时的提示升级信息
            //used to record if never tip is clicked
            'tip_update':true//是否点击了不再显示
        },
        'board':{//白板信息
            'version':'old',//new handle?'new':'old' new:newRubber\drag\reedit 新老版本：新版本存在新的橡皮擦，拖拽功能，和文字的重写，用于控制是否开放这些功能
            'curToolType':'pen',//record current tool 当前的画笔类型
            'pauseDraw':true,//for whiteBoard,it can not be drawed when pause is true , 当canDraw为true时有效，表示是否暂停绘制，暂停绘制时可以显示来自服务端的数据
            'isShowTool': false,   // 专门用来记录翻页时是否受过权的哨兵，用来进一步处理pause(page和gopage中的情景)
            'audioPlayState':false,//音频播放就置为true，视频播放会覆盖窗口，无需处理
            'mouse':{//current mouse position  鼠标信息
                'curX':0, //当前的位置x坐标
                'curY':0, //当前的位置y坐标
                //---------------------------------share for mouse display----------------------------------------
                'mouseMax':5,//控制教鞭从接收到上一次的对方鼠标位置显示后直到隐藏的秒数
                'mouseSign':0//记录从接收到上一次的对方鼠标位置后过了多少秒
                //---------------------------------share for mouse display----------------------------------------
            },
            'font':{//文字大小信息
                'big':32,//大文字
                'small':25//小文字
            },
            //default set for board 默认白板的初始化信息
            'tea':{//老师的白板默认初始化信息
                'type':'tea',//老师
                'pencil':{//画笔
                    'color':'#FF0000',//画笔的颜色
                    'size':3//画笔的大小
                },
                'sign_pencil':{//荧光笔
                    'color':'#FF0000',//荧光笔颜色
                    'size':20//荧光笔的大小
                },
                'rub':{//橡皮
                    'size':30//橡皮的大小
                },
                'font':{//文字
                    'fontStyle':'songti',//文字的样式
                    'fontSize':32, //文字的大小
                    'fontColor':'#FF0000'//文字的颜色
                },
                'target':{//鼠标移动时的当前选中的画笔的颜色
                    'color':'#0000FF'
                }
            },
            //default set for board
            'stu':{
                'type':'stu',
                'pencil':{
                    'color':'#0078FF',
                    'size':3
                },
                'sign_pencil':{
                    'color':'#FFFF00',
                    'size':20
                },
                'rub':{
                    'size':30
                },
                'font':{
                    'fontStyle':'songti',
                    'fontSize':32,
                    'fontColor':'#0078FF'
                },
                'target':{
                    'color':'#0000FF'
                }
            }
        },
        'cursor':{//for change mouse style 鼠标样式
            'normal':{ //普通成人教室
                'size':{//大小
                    'wid':'46',
                    'hei':'46'
                },
                'forbidden':'url(images/nor_forbid.png) 0 0,auto',//禁止绘制
                'normal':'url(images/nor_normal.png) 0 0,auto',//正常
                'ferule':'url("images/nor_ferule.png")',//教鞭
                'pen':'url(images/nor_pen.png) 9 46,auto',//铅笔
                'signpen':'url(images/nor_signpen.png) 0 46,auto',//荧光笔
                'rec':'url(images/nor_rec.png) 23 23,auto',//矩形
                'rub':'url(images/nor_rub.png) 23 23,auto',//橡皮
                'newrub':'url(images/nor_newrub.png) 23 23,auto',//新版的橡皮
                'text':'url(images/nor_text.png) 23 23,auto',//文本
                'draft':'url(images/nor_move.png) 23 23,auto',//拖拽
                'wait':''//unused now 未使用
            },
            'teen':{
                'size':{
                    'wid':'64',
                    'hei':'64'
                },
                'forbidden':'url(images/young_forbid.png) 0 0,auto',
                'normal':'url(images/young_normal.png) 0 0,auto',
                'ferule':'url("images/young_ferule.png")',
                'pen':'url(images/young_pen.png) 0 64,auto',
                'signpen':'url(images/young_signpen.png) 0 64,auto',
                'rec':'url(images/young_rec.png) 32 32,auto',
                'rub':'url(images/young_rub.png) 15 64,auto',
                'newrub':'url(images/young_rub.png) 15 64,auto',
                'text':'url(images/young_text.png) 32 32,auto',
                'draft':'url(images/young_move.png) 2 2,auto',
                'wait':'url(images/young_wait.png) 12 12,auto'//unused now
            }
        },
        'pdf':{
            //单独记录pdf的页码
            curPage:1,
            countPage:0,
            lessonPlan: {},
            doResize: false, //是否执行resize操作（handleCHlIO.draw方法）
            resizeTimes: 0, //resize次数
        },
        'h5Course':{
            idType:400,//互动教材协议的type
            open:false,//当前版本是否支持H5
            //单独记录pdf的页码
            curPage:1,
            countPage:0,
            startClass:false,//开始上课
            startPractice:false,//开始练习
            resizeFirst:true,//是否是第一次缩放标志
            canvasColor:'rgba(202, 232, 174, 0.2)'//画布的颜色配置
        },
        'isMac': navigator.userAgent.indexOf('Mac OS X') > 0 ? true : false //是否是mac设备
    };
});
