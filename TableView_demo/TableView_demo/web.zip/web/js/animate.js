/**
 * 动画
 */
define(function (require, exports, module) {
    var animate = {
        timeid:0,

        //播完完毕后自动关闭时间
        autoTime:60000,

        //传给服务器
        id:0,

        init:function(){
            var $div = $("<div class='anime'><iframe scrolling='no'></iframe><div class='btns'></div></div>");
            var $btn_play = $("<a class='btn-play'>replay</a>");
            var $btn_close = $("<a class='btn-close'>close</a>");

            var $btns = $div.find(".btns");
            $btns.append($btn_play);
            $btns.append($btn_close);
            $btns.hide();

            $(document.body).append($div);
            $div.hide();

            var $iframe = $(".anime iframe");
            var iframe = $iframe.get(0);
            $btn_play.click(function(){
                animate.replay();
            });

            $btn_close.click(function(){
                animate.close();
            });

            window.animeComplete = function(){
                console.log("动画播放完毕");
                //$btns.show();
                var data = {type:"stop",id:animate.id};
                window.comm_type_send("animate",JSON.stringify(data));

                //60秒自动关闭
                //animate.timeid = setTimeout(animate.close,animate.autoTime);
            }
        },

        replay:function(){
            //clearTimeout(animate.timeid);

            var $div = $(".anime");
            var $btns = $div.find(".btns");
            var $iframe = $(".anime iframe");
            var iframe = $iframe.get(0);
            $div.show();
            //$btns.hide();
            iframe.contentWindow.exportRoot.gotoAndPlay(1);

            var data = {type:"play",id:animate.id};
            window.comm_type_send("animate",JSON.stringify(data));
        },

        close:function(){
            //clearTimeout(animate.timeid);

            var $div = $(".anime");
            var $iframe = $(".anime iframe");
            $div.hide();
            $iframe.attr("src","");
            //window.comm_type_send("animate",'{"type":"close"}');
            var data = {type:"close",id:animate.id};
            window.comm_type_send("animate",JSON.stringify(data));
        },

        play:function(path){
            //clearTimeout(animate.timeid);

            var $div = $(".anime");
            var $btns = $div.find(".btns");
            var $iframe = $(".anime iframe");
            $div.show();
            //$btns.hide();
            $iframe.attr("src",path);
        },

        stop:function(){
            clearTimeout(animate.timeid);

            var $div = $(".anime");
            var $iframe = $(".anime iframe");
            $div.hide();
            $iframe.attr("src","");
        },

        btnVisible:function(b){
            var $btns = $(".anime .btns");
            if(b){
                $btns.show();
            }
            else{
                $btns.hide();
            }
        }
    }

    animate.init();
    exports.animate = animate;
});