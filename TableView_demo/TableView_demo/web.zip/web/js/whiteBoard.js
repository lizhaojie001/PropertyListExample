/**
 * Created by Administrator on 2016/8/16.
 * module info:
 *          白板模块
 */
define(function (require,exports,module) {
    var seaConf=require('boardConf').conf,
        seaDataSend=require('enDataSend');
    var WEBTools={
        conf:{
            //user type  用户类型
            'type':'stu',
            // 'uid': seaConf.serverData.objUserInfo.uid,
            //pause to draw there is some thing is not allowed to draw  ,eg:tea is out class ,stu is not allowed to draw  暂停绘制？
            'pauseDraw':true,
            //'show' and 'draw',two kind module  当前模式：绘制模式（允许绘制）：显示模式（不允许绘制但是可以显示服务器的绘制信息）？
            'paintModule':'show',
            //something used to control if new handle is opened  版本：控制新功能是否开启的 新橡皮 拖拽 重写
            'version':'old',
            //conf info for draw handle  绘制的基本信息配置
            'pencil':{
                'color':'#0078FF',
                'size':3
            },
            'rub':{//旧版橡皮擦
                'size':30
            },
            'sign_pencil':{
                'color':'#FFFF00',
                'size':20
            },
            'font':{
                'fontStyle':'songti',
                'fontSize':32,
                'fontColor':'#0078FF'
            },
            'target':{//当前笔迹 高亮
                'color':''
            },
            'canvas':{
                //canvas info
                'target':null,//show result canvas 结果层
                'targetContext':null,//2d obj  结果层的2d对象
                'targetBak':null,//show progress canvas  过程层
                'targetBakContext':null,//2d obj  过程层的2d对象
                'width':0,  //宽度
                'height':0,  //高度
                'left':0, //左边距
                'top':0, //上边距
                //tea's font color 老师的文字颜色
                'teaFontC':'',
                //tea's pen's color 老师的画笔颜色
                'teaPenC':'',
                //info of tea's sign pen 老师的荧光笔颜色
                'teaSignPen':'',
                //stu's font color 学生的文字颜色
                'stuFonC':'',
                //stu's pen color 学生的画笔颜色
                'stuPenC':'',
                //info of stu'd sign pen 学生的荧光笔颜色
                'stuSignPen':''
            },
            'paintBoard':{
                'PaintBoard':null,//paint board target 画布容器的对象
                'input':null,//progress input for drag 文本输入框容器的对象
                'edit':null,//progress edit 文字输入框的对象
                //策略：建立一个用户看不到的和input和edit完全相同的输入框和容器，输入已经输入的文字，判断何时换行
                'inputBak':null,//for show words(when newline) 用于识别单词何时换行
                'inputBakContain':null//for show words(when newline) 用于识别单词何时换行
            }
        },
        'recordConArr':[],//record all paint handle 记录所有的绘制数据信息
        'orderList':[],//record all order according time 存储操作序列 先后顺序
        'svcId':1,//svc id 维护确保每一条笔迹有不同的id号
        
        binded:false,//防止未绑定
        curDrawType:'pen',//used to remember current draw type,first time used to set default handle type 记录当前的画笔类型
        //表示鼠标移动时上一步是否有颜色变化
        //last time there is a color change or not
        colorChange:false,
        colorChangeId:-1,//record last color changed target id 记录上一个颜色变化的id
        
        //move之前是否触发了down事件防止没有点击操作时的move事件执行
        //down event is made or not before move event
        downEvent:false,
        //当up事件被触发,用于检测是否为移出画布被触发
        //out event is made or not when up event is alive
        outEvent:false,
        //record current target name 记录当前的笔迹对象
        curTarget:null,
        
        dragData:{
            //initial left and top
            initialLeft:0,//记录目标对象的初始左偏移
            initialTop:0,//记录目标对象的初始右偏移
        },
        
        textData:{
            signTextDrag:false,//writing drag or not? 区分是否在文字编辑的过程中进行了文本框的移动
            signREdit:false,//sign of reedit 文本编辑是否处于重写模式
            inputBorder:0,  //用于拖动的外边框的宽度
            inputMaxWid:0, //编辑框容器的最大的宽度，用于自动换行
            inputMaxHei:0, //编辑框容器的最大的高度，用于自动换行
            fontSize:0, //文字的大小
            //record text input to avoid height is overtop 记录当前已经输入的文本信息，用于当输入文字超出最大高度时的文本还原
            textInput:'',
            //记录上一次已经输入的文本信息，用于当输入文字超出最大高度时的文本还原
            lastTextInput:'',
            //record mouse point when text for click to drag 记录鼠标信息，用于拖拽
            pointXTD:0,
            pointYTD:0,
            //record input left and top
            pointLeftTD:0,//文字输入框左上角位置
            pointTopTD:0,//文字输入框左上角位置
        },
        
        mouseData:{//鼠标信息
            //开始位置
            startX:0,
            startY:0,
            //当前位置
            nowX:0,
            nowY:0,
            //结束的位置
            endX:0,
            endY:0,
            //一次过程中最小的x坐标
            minX:0,
            //一次过程中最小的y坐标
            minY:0,
            //一次过程中最大的x坐标
            maxX:0,
            //一次过程中最大的y坐标
            maxY:0,
            //记录所有的点信息
            pointArr:[]//record all mouse point data
        },

        toolTip: {
            padding: {
                horizontal: 8,
                vertical: 6
            },
            radius: 10,
            font: '16px sans-serif',
            bgColor: '#fff',
            fontColor: '#492CAB',
            triangleWidth: 6,
            hasToolTip: false,
            record: null
        },
        
        initWEBTools:function (){
            if(document.getElementById("canvas")!=undefined){
                //初始化对象信息，注意防止出现null或者undefined错误
                this.conf.canvas.target=document.getElementById("canvas");//结果层
                this.conf.canvas.targetBak=document.getElementById("canvas_bak");//过程层
                this.conf.canvas.targetContext=this.conf.canvas.target.getContext('2d');
                this.conf.canvas.targetBakContext=this.conf.canvas.targetBak.getContext('2d');
                
                this.conf.paintBoard.PaintBoard=document.getElementById('paintBoard');//画布容器
                this.conf.paintBoard.input=document.getElementById('input');//输入框容器
                this.conf.paintBoard.edit=document.getElementById('edit');//输入框
                this.conf.paintBoard.inputBak=document.getElementById("inputBak");
                this.conf.paintBoard.inputBakContain=document.getElementById('inputBakContain');
                //先隐藏文字输入框
                this.conf.paintBoard.input.style.display='none';
                //document.title='Html_White_Board';
                //初始化canvas中的老师和学生的配置信息
                this.conf.canvas.stuFonC=seaConf.board.stu.font.fontColor;
                this.conf.canvas.stuPenC=seaConf.board.stu.pencil.color;
                this.conf.canvas.stuSignPen=seaConf.board.stu.sign_pencil.color;
                this.conf.canvas.teaFontC=seaConf.board.tea.font.fontColor;
                this.conf.canvas.teaPenC=seaConf.board.tea.pencil.color;
                this.conf.canvas.teaSignPen=seaConf.board.tea.sign_pencil.color;
                
                //---------------为了防止老师不允许划线的意外---------------------
                if(seaConf.user.type==='tea'){
                    this.conf.pauseDraw=false;
                }
                //---------------为了防止老师不允许划线的意外---------------------
                
                //如果当前模式是绘制模式 防止建立多余的监听机制
                if(this.conf.paintModule=='draw'){
                    //建立文本编辑过程中的键盘事件  两个事件必须同时监听否则会出现监听不到的现象
                    /*WEBTools.conf.paintBoard.edit.onkeyup= function (e) {
                        WEBTools.key_event(WEBTools.conf.paintBoard.edit,e);
                    }
                    WEBTools.conf.paintBoard.edit.onkeydown= function (e) {
                        WEBTools.key_event(WEBTools.conf.paintBoard.edit,e);
                    }*/
                    //初始化默认的当前的画笔
                    WEBTools.draw(WEBTools.curDrawType);
                    //绑定画布的鼠标事件
                    WEBTools.bind(WEBTools.conf.canvas.targetBak);
                    //绑定文本操作中的事件
                    WEBTools.bind(WEBTools.conf.paintBoard.input);
                    WEBTools.binded=true;
                }
            }
        },
        
        review: function (wid,hei,left,top) {
            wid=Math.round(wid);
            hei=Math.round(hei);
            left=Math.round(left);
            top=Math.round(top);
            //-----------------------屏蔽缩放屏幕时的文字错乱---------------------------
            if(WEBTools.conf.paintBoard.input&&WEBTools.conf.paintBoard.input.style.display!='none'){
                WEBTools.write_end();
            }
            //-----------------------屏蔽缩放屏幕时的文字错乱---------------------------
            //防止出现null和undefined 防止未初始化现象
            if(!this.conf.canvas.target){
                this.initWEBTools();
            }
            console.log('[%s] -----------> resize paint size: (width,height,left,top)(%d,%d,%d,%d)',window.getTimeNow(),wid,hei,left,top);
            //一些别名
            var temPBS=this.conf.paintBoard.PaintBoard.style,
                temIBCS=this.conf.paintBoard.inputBakContain.style,
                temCanvas=this.conf.canvas.target,
                temCanvasBak=this.conf.canvas.targetBak;
            //设置容器的位置属性
            temPBS.width=wid+'px';
            temPBS.height=hei+'px';
            temPBS.left=left+'px';
            temPBS.top=top+'px';
            //used to achieve text tool,user can not see  保证用户看不到用于判断换行的input和edit，不能隐藏，否则监听不到换行
            temIBCS.top=top+'px';
            temIBCS.left=left+'px';
            //设置画布的位置属性
            temCanvas.width=wid;
            temCanvas.height=hei;
            temCanvasBak.width=wid;
            temCanvasBak.height=hei;
            //获取offset信息，防止绘制的偏移现象
            var offset=WEBTools.getOffset(WEBTools.conf.paintBoard.PaintBoard);
            //更新当前的属性信息
            this.conf.canvas.width=wid;
            this.conf.canvas.height=hei;
            this.conf.canvas.left=offset.left;
            this.conf.canvas.top=offset.top;
            //更新数据池的信息
            seaConf.classInfo.drawInfo.left=offset.left;
            seaConf.classInfo.drawInfo.top=offset.top;
            if(seaConf.classInfo.serverInfo.curPage==seaConf.classInfo.textInfo.curPage){
                //用于如果resize之后的重绘本地数据信息
                WEBTools.repaint();
            }
        },
        
        draw:function (graphType){
            console.log(WEBTools.orderList)
            //防止出现null和undefined 防止未初始化现象
            if(!this.conf.canvas.target){
                this.initWEBTools();
            }
            //处理操作信息
            if(graphType!='back'&&graphType!='clear'){
                WEBTools.curDrawType=graphType;//record current draw type 记录当前的画笔类型
            }else if(graphType=='back'){
                if(WEBTools.orderList.length!=0){
                    var targetId=WEBTools.orderList.pop();//取最后一个操作的id，并在orderList中移出
                    if(targetId){//防止空
                        WEBTools.handle_back(targetId);//调用撤销函数
                    }
                }
            }else{
                WEBTools.handle_clear();//清空
            }
        },
        
        bind:function (target){
            target.removeEventListener('mousedown',WEBTools.mousedown);
            target.removeEventListener('mousemove',WEBTools.mousemove);
            target.removeEventListener('mouseup',WEBTools.mouseup);
            target.removeEventListener('mouseout',WEBTools.mouseout);
            target.addEventListener('mousedown',WEBTools.mousedown,false);
            target.addEventListener('mousemove',WEBTools.mousemove,false);
            target.addEventListener('mouseup',WEBTools.mouseup,false);
            target.addEventListener('mouseout',WEBTools.mouseout,false);
        },
        
        mousedown:function (e){
            e=e||window.event||arguments.callee.caller.arguments[0];
            //更新outEvent
            WEBTools.outEvent=false;
            // console.log('seaConf.board.pauseDraw'+seaConf.board.pauseDraw)
            // console.log('WEBTools.conf.pauseDraw' + WEBTools.conf.pauseDraw)
            if(WEBTools.conf.paintModule=='draw'&&!WEBTools.conf.pauseDraw){//if canvas can be allowed to draw now
                var context =WEBTools.conf.canvas.targetBakContext,
                    canvasW=WEBTools.conf.canvas.width,
                    canvasH=WEBTools.conf.canvas.height;
                //paint the words to the board when we edit words but not click board  防止在编辑文字时，未点击画布其他位置将文字打印在画布上
                if(WEBTools.conf.paintBoard.input.style.display!='none'&&WEBTools.curDrawType!='text'){
                    var id_cur=(e.target || e.srcElement).id;
                    if(id_cur!='input'&&id_cur!='edit'){
                        WEBTools.write_end();
                    }
                }
                WEBTools.downEvent=true;//record down event 记录down事件
                
                //update offset data
                var offset=WEBTools.getOffset(WEBTools.conf.paintBoard.PaintBoard);
                WEBTools.conf.canvas.left=offset.left;
                WEBTools.conf.canvas.top=offset.top;
                
                //update mouse data
                WEBTools.mouseData.startX=Math.round(e.clientX+document.body.scrollLeft-WEBTools.conf.canvas.left);
                WEBTools.mouseData.startY=Math.round(e.clientY+document.body.scrollTop-WEBTools.conf.canvas.top);
                
                var lineWid=Math.round(WEBTools.conf.pencil.size*canvasW/800);
                
                //单独处理矩形区域的点，避免溢出看不到绘制的边线
                if(WEBTools.curDrawType==='rec'){
                    WEBTools.mouseData.startX=(WEBTools.mouseData.startX-lineWid)>=0?WEBTools.mouseData.startX:lineWid;
                    WEBTools.mouseData.startY=(WEBTools.mouseData.startY-lineWid)>=0?WEBTools.mouseData.startY:lineWid;
                }
                
                //更新鼠标信息
                WEBTools.mouseData.minX=WEBTools.mouseData.startX;
                WEBTools.mouseData.minY=WEBTools.mouseData.startY;
                WEBTools.mouseData.maxX=WEBTools.mouseData.startX;
                WEBTools.mouseData.maxY=WEBTools.mouseData.startY;
                
                //set context 设置绘制配置信息
                context.strokeStyle=WEBTools.conf.pencil.color;
                context.lineWidth=lineWid;
                context.moveTo(WEBTools.mouseData.startX,WEBTools.mouseData.startY);
                
                //clear container of all points 先清空一次鼠标数据
                WEBTools.mouseData.pointArr.length=0;
                
                switch (WEBTools.curDrawType){
                    //每一个case基本模式都一样，先记录点信息，然后设置canvas的特定属性，之后就是canvas的固定写法
                    case 'pen':
                        WEBTools.mouseData.pointArr.push({'x':WEBTools.mouseData.startX,'y':WEBTools.mouseData.startY});
                        context.beginPath();
                        break;
                    case 'signpen':
                        WEBTools.mouseData.pointArr.push({'x':WEBTools.mouseData.startX,'y':WEBTools.mouseData.startY});
                        context.save();
                        context.beginPath();
                        context.globalAlpha=0.4;
                        context.globalCompositeOperation='xor';
                        context.strokeStyle=WEBTools.conf.sign_pencil.color;
                        context.lineWidth=WEBTools.conf.sign_pencil.size*canvasW/800;
                        break;
                    case 'rec':
                        WEBTools.mouseData.pointArr.push({'x':WEBTools.mouseData.startX,'y':WEBTools.mouseData.startY});
                        break;
                    case 'rub':
                        var sizerub=WEBTools.conf.rub.size;
                        WEBTools.mouseData.pointArr.push({'x':WEBTools.mouseData.startX,'y':WEBTools.mouseData.startY});
                        context.clearRect(WEBTools.mouseData.startX-sizerub/2,WEBTools.mouseData.startY-sizerub/2,sizerub,sizerub);
                        break;
                    case 'newrub':
                        var tem_e=WEBTools.curTarget;
                        if(tem_e){
                            //统一颜色
                            // WEBTools.reInitColor();
                            // //修改当前的笔迹颜色
                            // tem_e.color=WEBTools.conf.target.color;
                            //所有笔迹重新绘制
                            WEBTools.repaint();
                        }
                        break;
                    case 'text':
                        var target = e.target || e.srcElement;
                        if(target.id=='input'){//拖拽
                            //标记哨兵 表明现在正在处于拖拽状态
                            WEBTools.textData.signTextDrag=true;
                            //设置为只读状态
                            WEBTools.conf.paintBoard.edit.readOnly='true';
                            //设置当前状态下的最大宽高
                            WEBTools.conf.paintBoard.input.style.minWidth=WEBTools.conf.paintBoard.input.scrollWidth+'px';
                            WEBTools.conf.paintBoard.input.style.minHeight=WEBTools.conf.paintBoard.input.scrollHeight+'px';
                            //阻止事件的默认事件以及向上冒泡
                            e.preventDefault();
                            e.stopPropagation();
                        }
                        else if(target.id=='edit'){//输入
                            //更改哨兵
                            WEBTools.textData.signTextDrag=false;
                            //可写
                            WEBTools.conf.paintBoard.edit.readOnly='';
                            //阻止冒泡
                            e.stopPropagation();
                        }else{
                            if(WEBTools.conf.paintBoard.input.style.display=="none")
                            {
                                if(WEBTools.curTarget!=null&&WEBTools.curTarget.drawingType==4){//重写
                                    //reedit module
                                    WEBTools.reEditText(e);
                                }
                                else{//写文字
                                    //first time to text
                                    WEBTools.write_start(WEBTools.mouseData.startX,WEBTools.mouseData.startY);
                                }
                            }
                            else{//打印
                                WEBTools.write_end();
                                WEBTools.clearConText();
                                WEBTools.textData.signTextDrag=false;
                            }
                        }
                        break;
                    case 'draft':
                        if(WEBTools.curTarget&&WEBTools.curTarget.drawingType!=10){
                            //必须记录的两个重要信息 初始的位置信息
                            WEBTools.dragData.initialLeft=WEBTools.curTarget.drag_left;
                            WEBTools.dragData.initialTop=WEBTools.curTarget.drag_top;
                            // WEBTools.curTarget.color=WEBTools.conf.target.color;
                            //先隐藏这笔，但是要画在蒙版上
                            WEBTools.curTarget.display=0;
                            WEBTools.repaint();
                            WEBTools.curTarget.display=1;
                            WEBTools.curTarget.handle(context,2);
                        }
                        break;
                    default :
                        break;
                }
                if(WEBTools.curDrawType!='text'){
                    e.preventDefault();
                    e.stopPropagation();
                }
            }
        },
        mousemove:function (e){
            e=e||window.event||arguments.callee.caller.arguments[0];
            //更新outEvent
            WEBTools.outEvent=false;
            var context=WEBTools.conf.canvas.targetBakContext,
                canvasW=WEBTools.conf.canvas.width,
                canvasH=WEBTools.conf.canvas.height;
            //calculate the point {x,y} to line to
            var x =  Math.round(e.clientX+document.body.scrollLeft - WEBTools.conf.canvas.left);
            var y =  Math.round(e.clientY+document.body.scrollTop - WEBTools.conf.canvas.top);
            WEBTools.mouseData.nowX=x;
            WEBTools.mouseData.nowY=y;
            //record current points data for mouse synchronous 更新鼠标信息为了方便鼠标同步时判断有效的鼠标移动
            seaConf.board.mouse.curX= Math.round(e.clientX);
            seaConf.board.mouse.curY=  Math.round(e.clientY);
            if(WEBTools.downEvent){//in the event of down event is alive 判断如果down事件被点击
                
                WEBTools.mouseData.minX=(x<WEBTools.mouseData.minX)?x:WEBTools.mouseData.minX;
                WEBTools.mouseData.maxX=(x>WEBTools.mouseData.maxX)?x:WEBTools.mouseData.maxX;
                WEBTools.mouseData.minY=(y<WEBTools.mouseData.minY)?y:WEBTools.mouseData.minY;
                WEBTools.mouseData.maxY=(y>WEBTools.mouseData.maxY)?y:WEBTools.mouseData.maxY;
                
                switch (WEBTools.curDrawType){
                    case 'pen':
                        context.lineTo(x ,y);
                        context.stroke();
                        //防止点数据过多引起崩溃
                        if(WEBTools.mouseData.pointArr.length > 450){
                            WEBTools.mouseup();
                        }else{
                            WEBTools.mouseData.pointArr.push({'x':x,'y':y});
                        }
                        break;
                    case 'signpen':
                        context.lineTo(x ,y);
                        context.stroke();
                        //防止点数据过多引起崩溃
                        if(WEBTools.mouseData.pointArr.length > 450){
                            WEBTools.mouseup();
                        }else{
                            WEBTools.mouseData.pointArr.push({'x':x,'y':y});
                        }
                        break;
                    case 'rec':
                        context.beginPath();
                        WEBTools.clearConText();
                        context.moveTo(WEBTools.mouseData.startX , WEBTools.mouseData.startY);
                        context.lineTo(x  ,WEBTools.mouseData.startY );
                        context.lineTo(x  ,y );
                        context.lineTo(WEBTools.mouseData.startX  ,y );
                        context.lineTo(WEBTools.mouseData.startX  ,WEBTools.mouseData.startY );
                        context.lineTo(x  ,WEBTools.mouseData.startY );
                        context.stroke();
                        break;
                    case 'rub':
                        var sizerub=WEBTools.conf.rub.size;
                        //防止点数据过多引起崩溃
                        if(WEBTools.mouseData.pointArr.length > 450){
                            WEBTools.mouseup();
                        }else{
                            WEBTools.mouseData.pointArr.push({'x':x,'y':y});
                            WEBTools.conf.canvas.targetContext.clearRect(x-sizerub/2,y-sizerub/2,sizerub,sizerub);
                        }
                        break;
                    case 'newrub':
                        WEBTools.curTarget=WEBTools.e_search(x,y);
                        var targetCr=WEBTools.curTarget;
                        if(targetCr){
                            // WEBTools.reInitColor();
                            // targetCr.color=WEBTools.conf.target.color;
                            WEBTools.repaint();
                        }
                        else{
                            // WEBTools.reInitColor();
                            WEBTools.repaint();
                        }
                        break;
                    case 'text':
                        if(WEBTools.textData.signTextDrag)//编辑过程中的拖拽
                        {
                            //WEBTools.textData.pointXTD maybe == WEBTools.mouseData.startX and maybe not
                            WEBTools.conf.paintBoard.input.style.left=WEBTools.textData.pointXTD+x-WEBTools.mouseData.startX+'px';
                            WEBTools.conf.paintBoard.input.style.top=WEBTools.textData.pointYTD+y-WEBTools.mouseData.startY+'px';
                            //WEBTools.textData.pointLeftTD and WEBTools.textData.pointTopTD used to avoid tea turn page when stu is dragging text
                            WEBTools.textData.pointLeftTD=WEBTools.textData.pointXTD+x-WEBTools.mouseData.startX;
                            WEBTools.textData.pointTopTD=WEBTools.textData.pointYTD+y-WEBTools.mouseData.startY;
                        }
                        break;
                    case 'draft':
                        //这里做移动操作
                        //improve safety
                        if(WEBTools.curTarget){
                            WEBTools.clearConText();
                            var s=WEBTools.curTarget.canvasWidth/canvasW;
                            // WEBTools.curTarget.color = seaConf.user.type=='tea' ? seaConf.board.tea.pencil.color : seaConf.board.stu.pencil.color
                            WEBTools.curTarget.drag_left= Math.round((x-WEBTools.mouseData.startX)*s+WEBTools.dragData.initialLeft);
                            WEBTools.curTarget.drag_top= Math.round((y-WEBTools.mouseData.startY)*s+WEBTools.dragData.initialTop);
                            WEBTools.curTarget.handle(context,2);
                        }
                        break;
                }
            }
            else if(!WEBTools.conf.pauseDraw&&WEBTools.conf.version=='new'&&!WEBTools.textData.signREdit){//新功能中的down未触发，移动鼠标，高亮当前的笔迹
                WEBTools.curTarget=null;
                WEBTools.curTarget=WEBTools.e_search(x,y);
                if(WEBTools.curTarget){//当前鼠标区域存在笔迹
                    var a=(WEBTools.curDrawType=='newrub')?true:false,//新版橡皮擦 new rubber
                        //draft module but current target type is not Highlighter pen
                        b=(WEBTools.curDrawType=='draft'&&WEBTools.curTarget.drawingType!=10)?true:false,//当前对象不是荧光笔且处于拖拽模式
                        //text module but current target type is text
                        c=(WEBTools.curDrawType=='text'&&WEBTools.curTarget.drawingType==4)?true:false,//处于编辑模式切当前为文字文字
                        //different id from last color changed target
                        d=WEBTools.curTarget.id!=WEBTools.colorChangeId;
                    if((a||b||c)&&d){
                        // WEBTools.reInitColor();
                        // WEBTools.colorChange=true;
                        // if(WEBTools.curTarget.drawingType!=4)//not text
                        // {
                        //     WEBTools.curTarget.color=WEBTools.conf.target.color;
                        // }
                        // else//text
                        // {
                        //     WEBTools.curTarget.font_color=WEBTools.conf.target.color;
                        // }
                        WEBTools.repaint();
                        WEBTools.colorChangeId=WEBTools.curTarget.id;
                    }
                }
                else if(WEBTools.colorChange){//当前鼠标区域没有笔迹，但是之前的操作有笔迹颜色的变化
                    //回复颜色
                    // WEBTools.reInitColor();
                    //重绘
                    WEBTools.repaint();
                    //修改哨兵
                    WEBTools.colorChange=false;
                    WEBTools.colorChangeId=-1;
                }
            }
            //除去文本的默认事件处理  文本之前已经处理，不再统一处理，涉及到拖拽
            if(WEBTools.curDrawType!='text'){
                e.preventDefault();
                e.stopPropagation();
            }
            var target = null;
            target = WEBTools.e_search(x,y);
            // 有授权的用户才展示画笔轨迹
            if(!WEBTools.downEvent &&  WEBTools.curDrawType!='draft' && target && !WEBTools.conf.pauseDraw && target.display){
                WEBTools.drawToolTip(context, x, y, target);
            } else if (WEBTools.toolTip.record) {
                // 鼠标位置没有笔迹，但有提示记录，清除上一次的提示信息
                context = context.canvas.getContext("2d");
                context.clearRect(WEBTools.toolTip.record.x,WEBTools.toolTip.record.y,WEBTools.toolTip.record.w,WEBTools.toolTip.record.h);
                WEBTools.toolTip.record = null;
            }
        },
        mouseup:function (e){
            e=e||window.event||arguments.callee.caller.arguments[0];
            if(!WEBTools.conf.pauseDraw&&WEBTools.downEvent){
                var re;
                var canvasW=WEBTools.conf.canvas.width,
                    canvasH=WEBTools.conf.canvas.height;
                //处理文本的拖拽的过程中文本区域超出canvas的区域
                if(WEBTools.curDrawType=='text'){
                    re=WEBTools.inputRange();//获取纠正数据
                    WEBTools.conf.paintBoard.edit.focus();
                }
                //down事件完毕
                WEBTools.downEvent = false;
                var x= 0,
                    y=0;
                ////修改矩形画出白板区域
                //if(WEBTools.outEvent&&WEBTools.curDrawType==='rec'){
                //    x=WEBTools.mouseData.nowX;
                //    y=WEBTools.mouseData.nowY;
                //}else{
                //avoid window.event is undefined
                //避免window.event为undefined
                x = (e.clientX)?(Math.round(e.clientX+document.body.scrollLeft - WEBTools.conf.canvas.left)):WEBTools.mouseData.nowX;
                y = (e.clientY)?(Math.round(e.clientY+document.body.scrollTop - WEBTools.conf.canvas.top)):WEBTools.mouseData.nowY;
                //}
                
                //单独处理矩形区域的点，避免溢出看不到绘制的边线
                if(WEBTools.curDrawType==='rec'){
                    //策略：先对0做纠正，然后再比较当前的点信息加边宽和canvas的宽高对比，调节当前的点
                    var lineWid=Math.round(WEBTools.conf.pencil.size*canvasW/800);
                    x=(x-lineWid)>=0?x:lineWid;
                    y=(y-lineWid)>=0?y:lineWid;
                    
                    x=(x+lineWid-WEBTools.conf.canvas.width)<=0?x:WEBTools.conf.canvas.width-lineWid;
                    y=(y+lineWid-WEBTools.conf.canvas.height)<=0?y:WEBTools.conf.canvas.height-lineWid;
                }
                
                WEBTools.mouseData.minX=(x<WEBTools.mouseData.minX)?x:WEBTools.mouseData.minX;
                WEBTools.mouseData.maxX=(x>WEBTools.mouseData.maxX)?x:WEBTools.mouseData.maxX;
                WEBTools.mouseData.minY=(y<WEBTools.mouseData.minY)?y:WEBTools.mouseData.minY;
                WEBTools.mouseData.maxY=(y>WEBTools.mouseData.maxY)?y:WEBTools.mouseData.maxY;
                
                //计算当前的笔迹的矩形区域
                var child_div_W= Math.max(Math.round(WEBTools.mouseData.maxX-WEBTools.mouseData.minX),Math.round(10*canvasW/800));
                var child_div_H= Math.max(Math.round(WEBTools.mouseData.maxY-WEBTools.mouseData.minY),Math.round(10*canvasW/800));
                
                WEBTools.mouseData.pointArr.push({'x':x,'y':y});
                
                //mouse's move is effective or not  屏蔽无意义的点击，防抖处理
                var effectMove=WEBTools.mouseData.minX!=WEBTools.mouseData.maxX||WEBTools.mouseData.minY!=WEBTools.mouseData.maxY;
                switch (WEBTools.curDrawType){
                    case 'pen':
                        /*封装obj*/
                        if(effectMove){
                            var obj={
                                'handleType':0,//add
                                'drawingType':0,//pen
                                'id':WEBTools.svcId,
                                'specialValue':{
                                    'user_id': seaConf.serverData.objUserInfo.uid,
                                    'user_nick': seaConf.serverData.objUserInfo.userName,
                                    'owner':WEBTools.conf.type,
                                    'pencil_color':WEBTools.conf.pencil.color,
                                    'pencil_size':WEBTools.conf.pencil.size,
                                    'canvasWidth':canvasW,
                                    'canvasHeight':canvasH,
                                    'child_div_W':child_div_W,//current handwriting's area  笔迹的矩形区域
                                    'child_div_H':child_div_H,//current handwriting's area  笔迹的矩形区域
                                    'margin_left':Math.round(WEBTools.mouseData.minX),//current handwriting's position  笔迹矩形区域的边距
                                    'margin_top':Math.round(WEBTools.mouseData.minY),//current handwriting's position   笔迹矩形区域的边距
                                    'point':WEBTools.mouseData.pointArr.slice(0)//container of points  点信息
                                }
                            };
                            //显示该笔迹
                            WEBTools.showPaint(obj);
                            //发送给服务端
                            seaDataSend.sendCommData('paint',JSON.stringify(obj));
                            //清除过程层笔迹
                            WEBTools.clearConText();
                        }
                        break;
                    case 'signpen':
                        if(effectMove){
                            /*封装obj*/
                            var obj={
                                'handleType':0,//add
                                'drawingType':10,//sign pen
                                'id':WEBTools.svcId,
                                'user_id': seaConf.serverData.objUserInfo.uid,
                                'user_nick': seaConf.serverData.objUserInfo.userName,
                                'specialValue':{
                                    'user_id': seaConf.serverData.objUserInfo.uid,
                                    'user_nick': seaConf.serverData.objUserInfo.userName,
                                    'owner':WEBTools.conf.type,
                                    'pencil_color':WEBTools.conf.sign_pencil.color,
                                    'pencil_size':WEBTools.conf.sign_pencil.size,
                                    'canvasWidth':canvasW,
                                    'canvasHeight':canvasH,
                                    'child_div_W':child_div_W,//current handwriting's area  笔迹的矩形区域
                                    'child_div_H':child_div_H,//current handwriting's area  笔迹的矩形区域
                                    'margin_left':Math.round(WEBTools.mouseData.minX),//current handwriting's position  笔迹矩形区域的边距
                                    'margin_top':Math.round(WEBTools.mouseData.minY),//current handwriting's position  笔迹矩形区域的边距
                                    'point':WEBTools.mouseData.pointArr.slice(0)//container of points 点信息
                                }
                            };
                            
                            //显示该笔迹
                            WEBTools.showPaint(obj);
                            //发送给服务端
                            seaDataSend.sendCommData('paint',JSON.stringify(obj));
                            //恢复一次
                            WEBTools.conf.canvas.targetBakContext.restore();
                            //清除过程层笔迹
                            WEBTools.clearConText();
                        }
                        break;
                    case 'rec':
                        if(effectMove){
                            child_div_W=WEBTools.mouseData.maxX-WEBTools.mouseData.minX;
                            child_div_H=WEBTools.mouseData.maxY-WEBTools.mouseData.minY;
                            
                            /*封装obj*/
                            var obj={
                                'handleType':0,//add
                                'drawingType':2,//rectangle
                                'id':WEBTools.svcId,
                                'specialValue':{
                                    'user_id': seaConf.serverData.objUserInfo.uid,
                                    'user_nick': seaConf.serverData.objUserInfo.userName,
                                    'owner':WEBTools.conf.type,
                                    'pencil_color':WEBTools.conf.pencil.color,
                                    'pencil_size':WEBTools.conf.pencil.size,
                                    'canvasWidth':canvasW,
                                    'canvasHeight':canvasH,
                                    'child_div_W':child_div_W,//current handwriting's area  笔迹的矩形区域
                                    'child_div_H':child_div_H,//current handwriting's area  笔迹的矩形区域
                                    'margin_left':Math.round(WEBTools.mouseData.minX),//current handwriting's position  笔迹矩形区域的边距
                                    'margin_top':Math.round(WEBTools.mouseData.minY),//current handwriting's position  笔迹矩形区域的边距
                                    'point':WEBTools.mouseData.pointArr.slice(0)//container of points  点信息
                                }
                            };
                            //显示该笔迹
                            WEBTools.showPaint(obj);
                            //发送给服务端
                            seaDataSend.sendCommData('paint',JSON.stringify(obj));
                            //清除过程层笔迹
                            WEBTools.clearConText();
                        }
                        break;
                    case 'rub':
                        /*封装obj*/
                        var obj={
                            'handleType':0,//add
                            'drawingType':3,//rubber
                            'id':WEBTools.svcId,
                            'specialValue':{
                                'user_id': seaConf.serverData.objUserInfo.uid,
                                'user_nick': seaConf.serverData.objUserInfo.userName,
                                'owner':WEBTools.conf.type,
                                'pencil_color':WEBTools.conf.pencil.color,
                                'pencil_size':WEBTools.conf.pencil.size,
                                'canvasWidth':canvasW,
                                'canvasHeight':canvasH,
                                'child_div_W':child_div_W,//current handwriting's area  笔迹的矩形区域
                                'child_div_H':child_div_H,//current handwriting's area  笔迹的矩形区域
                                'margin_left':Math.round(WEBTools.mouseData.minX),//current handwriting's position  笔迹矩形区域的边距
                                'margin_top':Math.round(WEBTools.mouseData.minY),//current handwriting's position  笔迹矩形区域的边距
                                'point':WEBTools.mouseData.pointArr.slice(0)//container of points  点信息
                            }
                        };
                        
                        var sizerub=WEBTools.conf.rub.size;
                        //清除最后一个点
                        WEBTools.conf.canvas.targetContext.clearRect(x-sizerub/2,y-sizerub/2,sizerub,sizerub);
                        
                        //显示该笔迹
                        WEBTools.showPaint(obj);
                        //发送给服务端
                        seaDataSend.sendCommData('paint',JSON.stringify(obj));
                        console.log("发送橡皮擦数据:",JSON.stringify(obj));
                        break;
                    case 'newrub':
                        var tem_e=WEBTools.e_search(x,y);
                        console.log(tem_e)
                        console.log(tem_e.Arr_data_handle)
                        if (seaConf.user.type != 'tea') {
                            if(tem_e.Arr_data_handle[0].specialValue.user_id != seaConf.serverData.objUserInfo.uid) {
                                return
                            }
                        }
                        if(tem_e){
                            /*封装obj*/
                            var obj={
                                'handleType':0,//add
                                'drawingType':500,//new handle
                                'id':WEBTools.svcId,
                                'specialValue':{
                                    'id': tem_e.id,
                                    'type': 0 //new rubber
                                }
                            };
                            //回复颜色
                            // if(tem_e.drawingType==4){
                            //     tem_e.color=WEBTools.conf.font.fontColor;
                            // }else if(tem_e.drawingType==10){
                            //     tem_e.color=WEBTools.conf.target.color;
                            // }else{
                            //     tem_e.color=WEBTools.conf.pencil.color;
                            // }
                            //显示
                            WEBTools.showPaint(obj);
                            
                            WEBTools.repaint();
                            seaDataSend.sendCommData('paint',JSON.stringify(obj));
                        }
                        else{
                            // WEBTools.reInitColor();
                            WEBTools.repaint();
                        }
                        
                        
                        break;
                    case 'text':
                        if(WEBTools.textData.signTextDrag){
                            var input=WEBTools.conf.paintBoard.input,
                                edit=WEBTools.conf.paintBoard.edit,
                                inputBakCon=WEBTools.conf.paintBoard.inputBakContain;
                            var bor=2* WEBTools.textData.inputBorder;//获取input的border宽度
                            var minW=Math.round((WEBTools.conf.font.fontSize)*canvasW/800);//设置的默认的显示的输入框大小
                            //获取当前的偏移值
                            WEBTools.textData.pointLeftTD=WEBTools.textData.pointXTD+x-WEBTools.mouseData.startX;
                            WEBTools.textData.pointTopTD=WEBTools.textData.pointYTD+y-WEBTools.mouseData.startY;
                            //纠正当前的偏移值
                            WEBTools.textData.pointXTD=WEBTools.textData.pointLeftTD+re.shiftX;
                            WEBTools.textData.pointYTD=WEBTools.textData.pointTopTD+re.shiftY;
                            //获取当前的文本的宽高
                            WEBTools.textData.inputMaxWid=canvasW-WEBTools.textData.pointXTD - bor;
                            WEBTools.textData.inputMaxHei=canvasH-WEBTools.textData.pointYTD - bor;
                            //重置容器的最大的宽高
                            input.style.maxWidth=WEBTools.textData.inputMaxWid + 'px';
                            input.style.maxHeight=WEBTools.textData.inputMaxHei + 'px';
                            inputBakCon.style.maxWidth=WEBTools.textData.inputMaxWid + 'px';
                            inputBakCon.style.maxHeight=WEBTools.textData.inputMaxHei + 'px';
                            //根据纠正的值重置边距位置
                            input.style.left=WEBTools.textData.pointXTD+'px';
                            input.style.top=WEBTools.textData.pointYTD+'px';
                            //设置最小的宽高
                            input.style.minWidth=minW+'px';
                            input.style.minHeight=minW+'px';
                            //还原
                            WEBTools.textData.signTextDrag=false;
                            //可写
                            edit.readOnly='';
                        }
                        break;
                    case 'draft':
                        if(effectMove){
                            if(x-WEBTools.mouseData.startX!=0||y-WEBTools.mouseData.startY!=0){//是否移动了
                                if(WEBTools.curTarget&&!WEBTools.textData.signREdit){
                                    //if current target over or not， four kinds 拖拽时是否超出画布，四个方向四种情况
                                    // var s=canvasW/WEBTools.curTarget.canvasWidth;
                                    // if(s*(WEBTools.curTarget.margin_left+WEBTools.curTarget.drag_left)<0){
                                    //     WEBTools.curTarget.drag_left= Math.round(0-WEBTools.curTarget.margin_left);
                                    // }
                                    // if(s*(WEBTools.curTarget.margin_top+WEBTools.curTarget.drag_top)<0){
                                    //     WEBTools.curTarget.drag_top= Math.round(0-WEBTools.curTarget.margin_top);
                                    // }
                                    // if(s*(WEBTools.curTarget.margin_left+WEBTools.curTarget.drag_left+WEBTools.curTarget.child_div_W)>canvasW){
                                    //     WEBTools.curTarget.drag_left= Math.round((canvasW-10)/s-WEBTools.curTarget.child_div_W-WEBTools.curTarget.margin_left);
                                    // }
                                    // if(s*(WEBTools.curTarget.margin_top+WEBTools.curTarget.drag_top+WEBTools.curTarget.child_div_H)>canvasH){
                                    //     WEBTools.curTarget.drag_top= Math.round(canvasH/s-WEBTools.curTarget.child_div_H-WEBTools.curTarget.margin_top);
                                    // }
                                    
                                    WEBTools.clearConText();
                                    var obj={
                                        'handleType': 0,//add
                                        'drawingType':500,//new handle
                                        'id': WEBTools.svcId,
                                        'specialValue':{
                                            'id': WEBTools.curTarget.id,
                                            'type':1,//drag
                                            'drag_left':Math.round(WEBTools.curTarget.drag_left) ,//x轴拖拽的距离
                                            'drag_top':Math.round(WEBTools.curTarget.drag_top) //y轴拖拽的距离
                                        }
                                    };
                                    
                                    WEBTools.showPaint(obj);
                                    
                                    console.log(WEBTools.conf.canvas.targetContext);
                                    WEBTools.curTarget.handle(WEBTools.conf.canvas.targetContext,2);
                                    seaDataSend.sendCommData('paint',JSON.stringify(obj));
                                }
                            }
                        }else{
                            WEBTools.repaint();
                        }
                        break;
                    default :
                        break;
                }
                try {
                    if(WEBTools.curDrawType!='text'){
                        WEBTools.clearConText();
                        e.preventDefault();
                        e.stopPropagation();
                    }
                }catch (e){
                
                }
            }
            WEBTools.outEvent=false;
        },
        mouseout:function (e){
            var target = e.target || e.srcElement;
            //out事件发生
            WEBTools.outEvent=true;
            if(WEBTools.downEvent&&target.id!='input'&&target.id!='edit'&&WEBTools.curDrawType!='text')
            {
                //策略
                //强制的触发up事件
                WEBTools.mouseup();
            }
            e.preventDefault();
            e.stopPropagation();
        },
        
        key_event:function (that,e){
            //-------------------处理拖住过程中的输入-------------------
            if(WEBTools.textData.signTextDrag){
                WEBTools.mouseup();
            }
            //-------------------处理拖住过程中的输入-------------------
            //防止直接复制网页的文字，显示网页乱码
            that.innerText=that.innerText.toString();
            //赋值
            WEBTools.textData.textInput=that.innerText;
            //策略
            //用一个属性相同的input和edit来决定看是否超出了canvas的区域
            WEBTools.conf.paintBoard.inputBak.innerText='';
            WEBTools.conf.paintBoard.inputBak.innerText=WEBTools.textData.textInput;
            if(WEBTools.conf.paintBoard.inputBakContain.scrollHeight!=WEBTools.conf.paintBoard.inputBakContain.clientHeight&& e.keyCode!=8&&e.keyCode!=46){
                //超出了高度  不再允许写入但是允许删除
                //恢复到之前的文字
                that.innerText=WEBTools.textData.lastTextInput;
                //移动光标到尾部
                WEBTools.keyAction(that);
                e.preventDefault();
            }else{
                //没有超出canvas的高度
                WEBTools.textData.lastTextInput=WEBTools.textData.textInput;
                WEBTools.textData.textInput='';
            }
            //实现有滚动条（滚动条未移到最底部）时输入文字可以自动拉动滚动条下移
            var xt=parseInt(document.getElementById('paintBoard').style.top.replace('px',''))+parseInt(WEBTools.conf.paintBoard.input.style.top.replace('px',''))+parseInt(WEBTools.conf.paintBoard.input.scrollHeight),
                xs=parseInt(document.getElementById('overview').style.top.replace('px','')),
                xc=parseInt(document.getElementById('workSpace').style.height.replace('px',''));
            if(xt+xs-xc>0){//判断现在已经需要下移滚动条 并且滚动条未到最底部
                //先更新滚动效果
                document.getElementById('overview').style.top=xc-xt-2* WEBTools.textData.inputBorder+'px';
                //再重置滚动条
                $('#scrollbar1').tinyscrollbar_update(xt-xc);
            }
            //移动光标到尾部
            WEBTools.keyAction(that);
            WEBTools.conf.paintBoard.inputBak.innerText="";
        },
        write_start:function (x,y){//x y current point
            var input=WEBTools.conf.paintBoard.input,
                edit=WEBTools.conf.paintBoard.edit,
                inputBak=WEBTools.conf.paintBoard.inputBak,
                inputBakCon=WEBTools.conf.paintBoard.inputBakContain,
                canvasW=WEBTools.conf.canvas.width,
                canvasH=WEBTools.conf.canvas.height;
            //获取焦点
            edit.autofocus="true";
            
            edit.innerText="";
            WEBTools.textData.textInput="";
            
            //for set initial input's width and height
            var w=Math.round((WEBTools.conf.font.fontSize)*canvasW/800);//根据当前的画布大小和文字的大小动态形成默认的编辑区域的宽度
            var h=Math.round((WEBTools.conf.font.fontSize+10)*canvasW/800);//根据当前的画布的大小和文字的大小动态形成编辑区域的高度  10是防止出现滚动条的调节值
            var b=Math.round(4*canvasW/800);//border  4是相对与800px来说的边框宽度
            //to avoid edit over input 防止刚开始点击时出现的输入框超出canvas的区域 做值得纠正：举例：右下角点击，出现的边框位置纠正
            y=((y+h+2*b)>canvasH)?(canvasH-h-2*b):y;
            x=((x+w+2*b)>canvasW)?(canvasW-w-2*b):x;
            //记录css的值
            WEBTools.textData.inputBorder=b;
            WEBTools.textData.inputMaxWid=canvasW - x -2*b;
            WEBTools.textData.inputMaxHei=canvasH - y -2*b;
            WEBTools.textData.fontSize=Math.round(WEBTools.conf.font.fontSize*canvasW/800);
            //设置css
            input.style.border='dashed '+WEBTools.textData.inputBorder+'px blue';
            input.style.zIndex=5;
            input.style.maxWidth= WEBTools.textData.inputMaxWid + 'px';
            input.style.maxHeight= WEBTools.textData.inputMaxHei + 'px';
            input.style.display='block';
            input.style.left=x+'px';
            input.style.top=y+'px';
            
            edit.style.minWidth=w+'px';
            edit.style.display='block';
            edit.style.font='bold '+WEBTools.textData.fontSize+"px "+WEBTools.conf.font.fontStyle;
            
            // inputBakCon.style.border='dashed '+WEBTools.textData.inputBorder+'px blue';
            inputBakCon.style.maxWidth= WEBTools.textData.inputMaxWid + 'px';
            inputBakCon.style.maxHeight= WEBTools.textData.inputMaxHei + 'px';
            inputBak.style.font='bold '+WEBTools.textData.fontSize+"px "+WEBTools.conf.font.fontStyle;
            //记录当前的初始值
            WEBTools.textData.pointXTD=x;
            WEBTools.textData.pointYTD=y;
            WEBTools.textData.pointLeftTD=x;
            WEBTools.textData.pointTopTD=y;
        },
        write_writing: function () {//text but something else is alive,text must be drawed to pain board 已废弃
            if(WEBTools.conf.paintBoard.input.style.display!='none'){
                WEBTools.write_end();
            }
        },
        write_end:function (){//text end
            var canvasW=WEBTools.conf.canvas.width,
                canvasH=WEBTools.conf.canvas.height;
            var child_w=parseInt(WEBTools.conf.paintBoard.input.scrollWidth),//取编辑器的宽
                child_h=parseInt(WEBTools.conf.paintBoard.input.scrollHeight);//取编辑器的高
            //隐藏编辑器
            WEBTools.conf.paintBoard.input.style.display="none";
            WEBTools.conf.paintBoard.edit.style.display="none";
            
            var theString="";//用于存储待处理的文字串
            var changedStr='';//用于存储处理完的文字串
            var replacedStr='';//用于存储处理完的文字串
            //一些标记，标记当前未处理串中是否存在各种标签
            var sign_div= -1,//是否存在<div>
                sign_br= -1,//是否存在<br>
                sign_div_end=-1,//是否存在</div>
                sign_for= 0,//for循环
                sign_len=0;//avoid dead loop 避免死循环，保证循环能释放
            theString=WEBTools.conf.paintBoard.edit.innerHTML;//取元数据
            theString=WEBTools.removeDanger(theString);//移除js脚本或者html代码，避免xss攻击
            
            sign_len=theString.length;
            //因为鉴于使用的是maxHeight,所以会存在以下的各种情况，换行：<div>********</div>  <br>  需要将这几种情况修改掉，替换为换行符
            if(theString.indexOf('<div>')!=-1||theString.indexOf('<br>')!=-1){//there is a line break  存在其中一种情况，存在换行
                for(sign_for=0;sign_for<sign_len;sign_for++){
                    //判断存在哪一种情况
                    sign_div=theString.indexOf('<div>');
                    sign_br=theString.indexOf('<br>');
                    sign_div_end=theString.indexOf('</div>');
                    
                    if(sign_div==-1){//there is not any div  不存在<div>
                        if(sign_br==-1){//there is not any div and br 不存在<br>
                            theString=theString.replace(/<\/div>/g,''); //不管有没有，干掉</div> 容错
                            break;
                        }
                        else{//only br  只有<br>的情况
                            theString=theString.replace(/<br>/g,'\n');
                            break;
                        }
                    }else{//some div is here 存在<div>
                        if(sign_br==-1){//there is not any br 表明<div></div>之间不存在<br>
                            theString.replace(/<div>/g,'\n').replace(/<\/div>/g,'');
                            break;
                        }else{//some br is here   两种情况都存在
                            if(sign_br<sign_div){//br is head  这种情况<br>在前
                                theString=theString.replace(/<br>/,'\n');
                            }else{//div first  这种情况<div>在前
                                if(sign_br<sign_div_end){//br between <div> and </div>  这种情况<div><br></div>
                                    theString.replace(/<div>/,'\n').replace(/<\/div>/,'').replace(/<br>/,'');
                                }else{//br out <div></div> 这种情况<div></div><br>
                                    theString.replace(/<div>/,'\n').replace(/<\/div>/,'');
                                }
                            }
                        }
                    }
                }
                //强制在处理一次，避免出错
                if(theString.indexOf('<div>')!=-1){
                    theString=theString.replace(/<div>/g,'\n').replace(/<\/div>/g,'').replace(/<br>/g,'');
                }else{
                    theString=theString.replace(/<br>/g,'\n');
                }
            }
            //下面开始拿上面处理过的数据，从相同属性的input和edit中过一遍，找到换行的结点插入换行符
            if(theString!=''){
                var str_temp="";
                var recordI=0;//avoid dead loop  避免死循环
                var curHeight=0;//current height  当前的高度
                var inputBakContain=WEBTools.conf.paintBoard.inputBakContain;
                
                WEBTools.conf.paintBoard.inputBak.innerText="";
                for(var i=0;i< theString.length;i++,recordI++){
                    if(theString.charAt(i)!="\n"&&theString.charAt(i)!="\r\n")//当前的字符不是换行符
                    {//no any \n
                        WEBTools.conf.paintBoard.inputBak.innerText+= theString.charAt(i);
                        //策略：
                        //先判断当前的scrollHeight和上一个curHeight比较是不是变化了，如果变化了还不足以说明已经还行了，因为一些操作也能造成这种现象
                        //再拿WEBTools.conf.font.fontSize/3和上面两者之间的差值作比较，以确保现在是换行
                        //这样做的理由是如果真的是换行的话，一定会大于WEBTools.conf.font.fontSize/3
                        if(curHeight!=0&&inputBakContain.scrollHeight>curHeight&&
                            Math.abs(inputBakContain.scrollHeight-curHeight)>WEBTools.conf.font.fontSize/3)//sign of \n
                        {
                            str_temp+='\n';
                            changedStr+=str_temp;
                            str_temp= theString.charAt(i);
                        }else{//no any \n 当前的字符还不是可以换行的字符
                            str_temp+= theString.charAt(i);
                        }
                        if(i+1== theString.length){//end  当前为最后一个字符
                            changedStr+=str_temp;
                        }
                        //更新记录当前的高度
                        curHeight=inputBakContain.scrollHeight;
                    }
                    else//当前的字符是换行符
                    {//handle of \n
                        str_temp+='\n';
                        changedStr+=str_temp;
                        str_temp="";
                        //换行后从头再来
                        WEBTools.conf.paintBoard.inputBak.innerText='';
                        curHeight=inputBakContain.scrollHeight;
                    }
                }
                //回复现场
                WEBTools.conf.paintBoard.inputBak.innerText="";
                replacedStr=changedStr;
            }
            //区别是重写还是第一次写文字
            if(!WEBTools.textData.signREdit){
                //第一次写文字，避免写空
                if(theString!=''){//avoid null
                    var obj={
                        'handleType':0,//add
                        'drawingType':4,//text
                        'id':WEBTools.svcId,
                        'specialValue':{
                            'user_id': seaConf.serverData.objUserInfo.uid,
                            'user_nick': seaConf.serverData.objUserInfo.userName,
                            'owner':WEBTools.conf.type,
                            'font':{
                                'font_color':WEBTools.conf.pencil.color,
                                'font_size':Math.round(WEBTools.conf.font.fontSize*canvasW/800),
                                'font_style':WEBTools.conf.font.fontStyle
                            },
                            'canvasWidth':canvasW,
                            'canvasHeight':canvasH,
                            'child_div_W':Math.round(child_w) ,//current handwriting's area 笔迹的矩形区域
                            'child_div_H': Math.round(child_h),//current handwriting's area 笔迹的矩形区域
                            'margin_left':Math.round(WEBTools.textData.pointXTD),//current handwriting's position 笔迹的矩形区域的边距
                            'margin_top':Math.round(WEBTools.textData.pointYTD),//current handwriting's position 笔迹的矩形区域的边距
                            'str_text':window.MyBase64.encode(replacedStr)//text   将处理完的文字发送到对端，一、避免再次解析 二、保持两端的一致性
                        }
                    };
                    //发送到服务器
                    seaDataSend.sendCommData('paint',JSON.stringify(obj));
                    //本端显示
                    WEBTools.showPaint(obj);
                }
            }
            else{//重写
                var s=WEBTools.curTarget.canvasWidth/canvasW;
                //新的笔迹区域的宽高
                WEBTools.curTarget.child_div_W= Math.round(child_w*s);
                WEBTools.curTarget.child_div_H= Math.round(child_h*s);
                //在重写中拖拽的距离
                WEBTools.curTarget.drag_left= Math.round((WEBTools.textData.pointXTD)*s-WEBTools.curTarget.margin_left);
                WEBTools.curTarget.drag_top= Math.round((WEBTools.textData.pointYTD)*s-WEBTools.curTarget.margin_top);
                
                
                var obj={
                    'handleType': 0,//add
                    'drawingType':500,//new handle
                    'id':WEBTools.svcId,
                    'specialValue':{
                        'id':WEBTools.curTarget.id,
                        'type':2,//reedit
                        'font':{
                            'font_color':WEBTools.conf.pencil.color,
                            'font_size':Math.round(WEBTools.conf.font.fontSize*s),
                            'font_style':WEBTools.conf.font.fontStyle
                        },
                        'child_div_W': Math.round(WEBTools.curTarget.child_div_W),//current handwriting's area 笔迹的矩形区域
                        'child_div_H': Math.round(WEBTools.curTarget.child_div_H),//current handwriting's area 笔迹的矩形区域
                        'drag_left':Math.round(WEBTools.curTarget.drag_left),//drafted distance x轴拖拽的距离
                        'drag_top':Math.round(WEBTools.curTarget.drag_top),//drafted distance y轴拖拽的距离
                        'str_text':window.MyBase64.encode(replacedStr)//edited text 将处理完的文字发送到对端，一、避免再次解析 二、保持两端的一致性
                    }
                };
                //发送到服务器
                seaDataSend.sendCommData('paint',JSON.stringify(obj));
                //显示这一笔
                WEBTools.curTarget.display=1;
                //本端显示
                WEBTools.showPaint(obj);
                //更新哨兵
                WEBTools.textData.signREdit=false;
            }
            //downEvent结束
            WEBTools.downEvent=false;
            //重置，为下一次的输入
            WEBTools.conf.paintBoard.edit.innerText='';
        },
        
        inputRange:function (){//文字操作时，用来判断是否需要调整边框的位置 ，避免溢出canvas画布
            var input=WEBTools.conf.paintBoard.input,
                canvasW=WEBTools.conf.canvas.width,
                canvasH=WEBTools.conf.canvas.height;
            
            var inputWid=parseInt(input.scrollWidth),
                inputHei=parseInt(input.scrollHeight),
                inputLeft=parseInt(input.style.left.replace('px','')),
                inputTop=parseInt(input.style.top.replace('px',''));
            
            var shiftLeft= 0,shiftTop=0;
            var b=2* WEBTools.textData.inputBorder;
            
            //right over
            if((inputLeft+inputWid+b>=canvasW)){
                shiftLeft=canvasW-inputLeft-inputWid-b;
            }
            //bottom over
            if(inputTop+inputHei+b>=canvasH){
                shiftTop=canvasH-inputTop-inputHei-b;
            }
            //left over
            if(inputLeft<0){
                shiftLeft=0-inputLeft;
            }
            //top over
            if(inputTop<0){
                shiftTop=0-inputTop;
            }
            return {shiftX:shiftLeft,shiftY:shiftTop};
        },
        'removeDanger': function (str) {//避免xss攻击
            var a=str;
            a= a.replace(/&nbsp;/g,' ');
            a=a.replace(/&amp;/g,'&');
            a=a.replace(/&quot;/g,'\\');
            a=a.replace(/&#039;/g,'\'');
            a=a.replace(/&lt;/g,'<');
            a=a.replace(/&gt;/g,'>');
            return a;
        },
        keyAction:function (that) {//光标到最后
            var textbox = that;
            var sel = window.getSelection();
            var range = document.createRange();
            range.selectNodeContents(textbox);
            range.collapse(false);
            sel.removeAllRanges();
            sel.addRange(range);
        },
        
        objFactory: function (handleType,drawingType,id,specialValue) {//used to make obj for draw  未使用
            //unused
            var obj=null;
            obj={
                'handleType':handleType,
                'drawingType':drawingType,
                'id':id,
                'specialValue':specialValue
            };
            return obj;
        },
        
        reEditText:function (e){//用于重写文字的start
            e=e||window.event||arguments.callee.caller.arguments[0];
            var input=WEBTools.conf.paintBoard.input,
                edit=WEBTools.conf.paintBoard.edit,
                inputBak=WEBTools.conf.paintBoard.inputBak,
                inputBakCon=WEBTools.conf.paintBoard.inputBakContain,
                canvasW=WEBTools.conf.canvas.width,
                canvasH=WEBTools.conf.canvas.height;
            
            if(WEBTools.curTarget){
                if(WEBTools.curTarget.handleType==0&&WEBTools.curTarget.drawingType==4){//如果当前双击的目标是文字
                    //标记当前的编辑状态是重写状态
                    WEBTools.textData.signREdit=true;
                    //先在结果层暂时隐藏这一段文字，显示在过程层上
                    WEBTools.curTarget.display=0;
                    //显示其他的笔迹
                    WEBTools.repaint();
                    
                    var tem_text=WEBTools.curTarget.point_Arr_text,
                        s=WEBTools.conf.canvas.width/WEBTools.curTarget.canvasWidth;
                    var b=Math.round(4*canvasW/800);//border
                    //更新本地记录的相关值信息
                    WEBTools.textData.inputBorder=b;
                    WEBTools.textData.inputMaxWid=canvasW-(WEBTools.curTarget.drag_left+WEBTools.curTarget.margin_left) * s-2*b;
                    WEBTools.textData.inputMaxHei=canvasH-(WEBTools.curTarget.drag_top+WEBTools.curTarget.margin_top) * s-2*b;
                    WEBTools.textData.fontSize=Math.round(WEBTools.curTarget.font_size*s);
                    //根据当前比划的数据信息设置新的属性
                    input.style.border='dashed '+WEBTools.textData.inputBorder+'px red';
                    input.style.zIndex=5;
                    input.style.display='block';
                    input.style.maxWidth=WEBTools.textData.inputMaxWid+'px';
                    input.style.maxHeight=WEBTools.textData.inputMaxHei+'px';
                    input.style.left=(WEBTools.curTarget.margin_left+WEBTools.curTarget.drag_left)*s+'px';
                    input.style.top=(WEBTools.curTarget.margin_top+WEBTools.curTarget.drag_top)*s+'px';
                    
                    edit.style.display='block';
                    edit.style.font='bold '+WEBTools.textData.fontSize+"px "+WEBTools.conf.font.fontStyle;
                    
                    inputBak.style.font='bold '+WEBTools.textData.fontSize+"px "+WEBTools.conf.font.fontStyle;
                    
                    // inputBakCon.style.border='dashed '+WEBTools.textData.inputBorder+'px red';
                    inputBakCon.style.maxWidth=WEBTools.textData.inputMaxWid+'px';
                    inputBakCon.style.maxHeight=WEBTools.textData.inputMaxHei+'px';
                    //值输入
                    WEBTools.conf.paintBoard.edit.innerText=tem_text;
                    //make cursor end  将光标移到最后
                    WEBTools.keyAction(WEBTools.conf.paintBoard.edit);
                    //记录当前的位置信息
                    WEBTools.textData.pointXTD=(WEBTools.curTarget.margin_left+WEBTools.curTarget.drag_left)*s;
                    WEBTools.textData.pointYTD=(WEBTools.curTarget.margin_top+WEBTools.curTarget.drag_top)*s;
                    //记录当前的位置信息
                    WEBTools.textData.pointLeftTD=WEBTools.textData.pointXTD;
                    WEBTools.textData.pointTopTD=WEBTools.textData.pointYTD;
                }
            }
        },
        
        reInitColor:function (){//恢复所有比划的颜色
            var temArr=WEBTools.recordConArr;
            for(var i= 0,j=temArr.length;i<j;i++){
                if(temArr[i].drawingType!=10){
                    if(temArr[i].drawingType!=4)
                    {
                        temArr[i].color=temArr[i].login_type=='tea'?WEBTools.conf.canvas.teaPenC:WEBTools.conf.canvas.stuPenC;
                    }
                    else{//text
                        temArr[i].font_color=temArr[i].login_type=='tea'?WEBTools.conf.canvas.teaFontC:WEBTools.conf.canvas.stuFonC;
                    }
                }
                else{//sign pen
                    temArr[i].color=temArr[i].login_type=='tea'?WEBTools.conf.canvas.teaSignPen:WEBTools.conf.canvas.stuSignPen;
                }
            }
        },

        e_search:function (x,y){//寻找当前鼠标位置下的笔迹对象
            var e;
            var s;
            var i,j,k;
            var pointOffset = 5; // 允许的坐标偏差
            var offset=WEBTools.getOffset(WEBTools.conf.paintBoard.PaintBoard);
            WEBTools.conf.canvas.left=offset.left;
            WEBTools.conf.canvas.top=offset.top;
            for(i= 0,j=WEBTools.recordConArr.length;i<j;i++){
                e=WEBTools.recordConArr[i];
                s= WEBTools.conf.canvas.width/ e.canvasWidth;
                if(e.handleType==0&&e.drawingType!=500&& e.drawingType!=3&&e.display==1){
                    if(e.drawingType!=10||WEBTools.curDrawType!='draft'){
                        if (e.drawingType == 4) { // 文字，按区域获取
                            if(x>= (e.margin_left+ e.drag_left)*s&&y>= (e.margin_top+ e.drag_top)*s){
                                if(x<= (e.margin_left+ e.child_div_W+ e.drag_left)*s&&y<=(e.margin_top+ e.child_div_H+ e.drag_top)*s){
                                    return e;
                                }
                            }
                            // 笔迹精确获取
                        } else if (e.drawingType == 2){ // 矩形
                            var point = e.point_Arr_text;
                            var point_a = {x: (point[0].x + e.drag_left)*s, y: (point[0].y + e.drag_top)*s};
                            var point_b = {x: (point[1].x + e.drag_left)*s, y: (point[1].y + e.drag_top)*s};
                            var point_min = {x: Math.min(point_a.x, point_b.x), y: Math.min(point_a.y, point_b.y)};
                            var point_max = {x: Math.max(point_a.x, point_b.x), y: Math.max(point_a.y, point_b.y)};
                            if ((point_min.x - pointOffset <= x && x <= point_min.x + pointOffset || point_max.x - pointOffset <= x && x <= point_max.x + pointOffset) && (point_min.y - pointOffset <= y && y <= point_max.y + pointOffset)) {
                                return e;
                            } else if ((point_min.y - pointOffset <= y && y <= point_min.y + pointOffset || point_max.y - pointOffset <= y && y <= point_max.y + pointOffset) && (point_min.x - pointOffset <= x && x <= point_max.x + pointOffset)) {
                                return e;
                            }
                        } else { // 其他
                            var point = e.point_Arr_text;
                            for (k = 0; k < point.length; k++) {
                                var ponitX = (point[k].x + e.drag_left)*s;
                                var pointY = (point[k].y + e.drag_top)*s;
                                if ((ponitX - pointOffset <= x && x <= ponitX + pointOffset) && (pointY - pointOffset <= y && y <= pointY + pointOffset)) {
                                    return e;
                                }
                            }
                        }
                    }
                }
            }
            return null;
        },
        
        showPaint: function (obj) {//用于根据分析数据对象来实现数据可视化
            console.log('-------------------本地操作和服务端传来的画板data-----------------')
            console.log(obj)
            console.log('-----------------本地操作和服务端传来的画板data----------------')
            try{
                if(obj.handleType==0){//add
                    if([0,2,3,4,10,500].indexOf(obj.drawingType)!=-1){//legal drawingType  合法的或者当前版本已知的操作type
                        
                        if(obj.drawingType!=500){//tradition drawingType  旧版本的操作
                            var tem_e=new paint(obj);//创建当前笔迹对象
                            tem_e.init_paint(obj);//初始化当前笔迹对象的属性
                            if(obj.drawingType == 3){
                                console.log("接收橡皮擦数据:",JSON.stringify(obj));
                            }
                            //绘制分发
                            // console.log('-------------------------WEBTools.conf.canvas.targetContext---------------------------')
                            // console.log(WEBTools.conf.canvas.targetContext)
                            // console.log('-------------------------WEBTools.conf.canvas.targetContext---------------------------')
                            tem_e.handle(WEBTools.conf.canvas.targetContext);
                        }else//new drawingType  500段的新功能
                        {
                            switch (obj.specialValue.type){
                                case 0://new rubber 新橡皮擦
                                    //从数据池中根据id寻找到当前的数据
                                    var e=WEBTools.searchByID(obj.specialValue.id);
                                    if(e!=null){
                                        //重置当前笔迹对象的属性
                                        e.init_paint(obj);
                                        //绘制所有
                                        WEBTools.repaint();
                                    }else{
                                        console.error('[%s] -----------> error happened when new rubber: error id to new rubber',window.getTimeNow());
                                    }
                                    break;
                                case 1://drag 拖拽
                                    //从数据池中根据id寻找到当前的数据
                                    var e=WEBTools.searchByID(obj.specialValue.id);
                                    console.log(e)
                                    if(e!=null){
                                        //重置当前笔迹对象的属性
                                        e.init_paint(obj);
                                        //绘制所有
                                        WEBTools.repaint();
                                    }else{
                                        console.error('[%s] -----------> error happened when draft handle: error id to draft',window.getTimeNow());
                                    }
                                    break;
                                case 2://reedit 重写
                                    //从数据池中根据id寻找到当前的数据
                                    var e=WEBTools.searchByID(obj.specialValue.id);
                                    if(e!=null){
                                        //重置当前笔迹对象的属性
                                        e.init_paint(obj);
                                        //绘制所有
                                        WEBTools.repaint();
                                    }else{
                                        console.error('[%s] -----------> error happened when reedit handle: error id to reedit',window.getTimeNow());
                                    }
                                    break;
                                default :
                                    //发现当前版本不能识别的type，提示用户升级
                                    if(seaConf.update.tip_update){
                                        WEBTools.orderList.push(-2);//未知修改操作（未来可能添加）
                                        WEBTools.svcId++;
                                        $('#update_cue').css('display','block');
                                        console.error('[%s] -----------> get unknown specialValue.type for 500 : type is %d',window.getTimeNow(),obj.specialValue.type);
                                    }
                                    break;
                            }
                        }
                    }
                    //发现当前版本不能识别的type，提示用户升级
                    else if(seaConf.update.tip_update){
                        WEBTools.orderList.push(-3);
                        WEBTools.svcId++;
                        $('#update_cue').css('display','block');
                        console.error('[%s] -----------> get unknown drawingType handleType 0: drawingType is %d',window.getTimeNow(),obj.drawingType);
                    }
                }else if(obj.handleType==1){//delete
                    if(obj.drawingType==1) //back
                        WEBTools.draw('back',1);
                    else if(obj.drawingType==2)  //clear
                        WEBTools.draw('clear',1);
                    //发现当前版本不能识别的type，提示用户升级
                    else if(seaConf.update.tip_update){
                        $('#update_cue').css('display','block');
                        console.error('[%s] -----------> get unknown drawingType of handleType 1: drawingType is %d',window.getTimeNow(),obj.drawingType);
                    }
                }else if(obj.handleType==2){//change
                    //发现当前版本不能识别的type，提示用户升级
                    if(seaConf.update.tip_update){
                        $('#update_cue').css('display','block');
                        console.error('[%s] -----------> get unknown drawingType of handleType 2: drawingType is %d',window.getTimeNow(),obj.drawingType);
                    }
                }else {
                    //发现当前版本不能识别的type，提示用户升级
                    if(seaConf.update.tip_update){
                        $('#update_cue').css('display','block');
                        console.error('[%s] -----------> get unknown handleType: handleType is %d',window.getTimeNow(),obj.handleType);
                    }
                }
            }catch(e){
                console.error('[%s] -----------> error happened when Paint update: %s',window.getTimeNow(),e);
            }
        },
        
        searchByID: function (id) {//根据id在WEBTools.recordConArr中寻找当前笔迹的原始数据
            var i,j;
            var temArr=WEBTools.recordConArr;
            console.log(temArr)
            for(i= 0,j=temArr.length;i<j;i++){
                if(temArr[i].id==id&&temArr[i].changeCount!=0){
                    console.log(temArr[i])
                    return temArr[i];
                }
            }
            return null;
        },
        
        handle_back:function (target_id){//回退操作
            //策略
            //先回退当前笔迹的修改操作：比如拖拽，新橡皮的擦出，重写等
            //再回退笔迹
            var i,j;
            for(i= 0,j=WEBTools.recordConArr.length;i<j;i++){
                if(WEBTools.recordConArr[i].id==target_id&&WEBTools.recordConArr[i].changeCount!=0){//find target
                    WEBTools.clearConText(1);
                    var tem_e=WEBTools.recordConArr[i];
                    tem_e.changeCount--;//先将当前笔迹的改变总量-1
                    if(tem_e.changeCount==0)//init state  表示当前的笔迹已经么可以回退的改变了 ，直接隐藏当前的笔迹
                    {
                        tem_e.display=0;
                        WEBTools.svcId--;//id-1
                    }
                    else{//there are some change after init  表示当前的笔迹还存在可以回退的改变 比如拖拽，新橡皮的擦出，重写等
                        var del=tem_e.Arr_data_handle.pop();//pop最近的历史记录
                        if(del.drawingType==500&&del.specialValue.type==0)
                            tem_e.display=1;
                        else{
                            var obj=tem_e.Arr_data_handle[tem_e.Arr_data_handle.length-1];
                            tem_e.init_paint(obj,1);
                        }
                    }
                    WEBTools.repaint();
                }
            }
        },
        
        handle_clear:function (){//清空操作
            var target_e;
            for(var i=0,j=WEBTools.recordConArr.length;i<j;i++){
                target_e=WEBTools.recordConArr[i];
                //全部隐藏掉
                target_e.display=0;
                //全部改变总量置为0
                target_e.changeCount=0;
            }
            //操作序列置为空
            WEBTools.orderList.length=0;
            WEBTools.repaint();
            
            WEBTools.svcId=1;
        },
        
        clearConText:function (type){//type为undefined清空过程层，不为undefined清空过程层和结果层
            try{
                if(!type)
                    WEBTools.conf.canvas.targetBakContext.clearRect(0,0,WEBTools.conf.canvas.width,WEBTools.conf.canvas.height);
                else
                {
                    WEBTools.conf.canvas.targetContext.clearRect(0,0,WEBTools.conf.canvas.width,WEBTools.conf.canvas.height);
                    WEBTools.conf.canvas.targetBakContext.clearRect(0,0,WEBTools.conf.canvas.width,WEBTools.conf.canvas.height);
                }
            }catch(e){
            
            }
            console.log('---------------------清空--------------------------')
            console.log(WEBTools.recordConArr)
            console.log('----------------------清空-------------------------')
        },
        
        repaint: function () {//重绘
            // console.log('----------------------------------')
            // console.log(WEBTools.recordConArr)
            // console.log('----------------------------------')
            WEBTools.clearConText(1);
            var e;
            var i=0,j=WEBTools.recordConArr.length;
            while(i<j){
                e=WEBTools.recordConArr[i];
                e.handle(WEBTools.conf.canvas.targetContext,2);
                i++;
            }
        },
        
        getOffset:function(Node, offset) {
            if (!offset) {
                offset = {};
                offset.top = 0;
                offset.left = 0;
            }
            if (Node == document.body) {//if current node is body，end
                return offset;
            }
            offset.top += Node.offsetTop;
            offset.left += Node.offsetLeft;
            return WEBTools.getOffset(Node.parentNode, offset);//up and account
        },

        //绘制tooltip提示
        drawToolTip:function(context, x, y, target) {
            var context = context.canvas.getContext("2d");
            // 避免重复弹出
            if (WEBTools.toolTip.record) {
                context.clearRect(WEBTools.toolTip.record.x,WEBTools.toolTip.record.y,WEBTools.toolTip.record.w,WEBTools.toolTip.record.h);
                WEBTools.toolTip.record = null;
            }
            var font = WEBTools.toolTip.font;
            var text = target.Arr_data_handle[0].specialValue.user_nick;
            context.font = font;
            context.textBaseline = 'bottom';
            context.fillStyle = WEBTools.toolTip.bgColor;

            //绘制ToolTip背景
            var margin = 0; // 箭头和鼠标的间距
            var minWidth = 60; // 最小宽度
            var textWidth = context.measureText(text).width;
            var paddingH = WEBTools.toolTip.padding.horizontal;
            var paddingV = WEBTools.toolTip.padding.vertical;
            var width = textWidth + paddingH * 2;
            if (width < minWidth) {
                paddingH = parseInt((minWidth - parseInt(textWidth)) / 2);
                width = textWidth + paddingH * 2;
            }
            var height = parseInt(font, 10) + paddingV * 2;
            var triangleW = WEBTools.toolTip.triangleWidth;
            var rectY = y + margin + 1.3 * triangleW;
            var pointArr = []; // 箭头坐标
            var direction = null; // 箭头方向
            var penWidth = 40;
            if (x < width) { // 气泡朝右
                direction = 'left';
                if (y < height + 1.3 * triangleW) { // 箭头在左上角
                    direction = 'leftTop';
                    // 箭头坐标
                    pointArr = [
                        {x: x, y: y + margin},
                        {x: x, y: rectY + WEBTools.toolTip.radius},
                        {x: x + 2 * triangleW, y: rectY}
                    ];
                    WEBTools.drawRoundedRect(context, x, rectY - 1, width, height, WEBTools.toolTip.radius, WEBTools.toolTip.fontColor);
                    // 存储ToolTip记录
                    WEBTools.toolTip.record = {
                        x: x - 1,
                        y: y + margin,
                        w: width + 2,
                        h: height + 1.3 * triangleW
                    };
                } else if (context.canvas.clientHeight - y - 100 < height + 1.3 * triangleW) { //  箭头在左下角
                    direction = 'leftBottom';
                    // 箭头坐标
                    pointArr = [
                        {x: x + penWidth, y: y},
                        {x: x + penWidth, y: y - 1.3 * triangleW - WEBTools.toolTip.radius},
                        {x: x + penWidth + 2 * triangleW, y: y - 1.3 * triangleW}
                    ];
                    WEBTools.drawRoundedRect(context, x + penWidth, y - 1.3 * triangleW - height + 1, width, height, WEBTools.toolTip.radius, WEBTools.toolTip.fontColor);
                    // 存储ToolTip记录
                    WEBTools.toolTip.record = {
                        x: x + penWidth,
                        y: y - 1.3 * triangleW - height + 1,
                        w: width,
                        h: height + 1.3 * triangleW
                    };
                } else { // 箭头左侧居中
                    pointArr = [
                        {x: x, y: y + 10},
                        {x: x + 1.3 * triangleW, y: y + triangleW + 10},
                        {x: x + 1.3 * triangleW, y: y - triangleW + 10}
                    ];
                    WEBTools.drawRoundedRect(context, x + 1.3 * triangleW - 1, y - 0.5 * height + 10, width, height, WEBTools.toolTip.radius, WEBTools.toolTip.fontColor);
                    // 存储ToolTip记录
                    WEBTools.toolTip.record = {
                        x: x,
                        y: y - 0.5 * height + 10,
                        w: width + 1.3 * triangleW,
                        h: height
                    };
                }
            } else if (context.canvas.clientWidth - x <  0.5 * width){ // 气泡朝左
                direction = 'right';
                if (y < height + 1.3 * triangleW) { // 箭头在右上角
                    direction = 'rightTop';
                    // 箭头坐标
                    pointArr = [
                        {x: x, y: y + margin},
                        {x: x, y: rectY + WEBTools.toolTip.radius},
                        {x: x - 2 * triangleW, y: rectY}
                    ];
                    WEBTools.drawRoundedRect(context, x - width, rectY - 1, width, height, WEBTools.toolTip.radius, WEBTools.toolTip.fontColor);
                    // 存储ToolTip记录
                    WEBTools.toolTip.record = {
                        x: x - width - 1,
                        y: y + margin,
                        w: width + 2,
                        h: height + 1.3 * triangleW
                    };
                } else if (context.canvas.clientHeight - y - 100 < height + 1.3 * triangleW) { // 箭头在右下角
                    direction = 'rightBottom';
                    // 箭头坐标
                    pointArr = [
                        {x: x, y: y + margin},
                        {x: x, y: y - 1.3 * triangleW - WEBTools.toolTip.radius},
                        {x: x - 2 * triangleW, y: y - 1.3 * triangleW}
                    ];
                    WEBTools.drawRoundedRect(context, x - width, y - 1.3 * triangleW - height + 1, width, height, WEBTools.toolTip.radius, WEBTools.toolTip.fontColor);
                    // 存储ToolTip记录
                    WEBTools.toolTip.record = {
                        x: x - width - 1,
                        y: y - 1.3 * triangleW - height + 1,
                        w: width + 2,
                        h: height + 1.3 * triangleW
                    };
                } else { // 箭头右侧居中
                    pointArr = [
                        {x: x, y: y},
                        {x: x - 1.3 * triangleW, y: y + triangleW},
                        {x: x - 1.3 * triangleW, y: y - triangleW}
                    ];
                    WEBTools.drawRoundedRect(context, x - 1.3 * triangleW - width + 1, y - 0.5 * height, width, height, WEBTools.toolTip.radius, WEBTools.toolTip.fontColor);
                    // 存储ToolTip记录
                    WEBTools.toolTip.record = {
                        x: x - 1.3 * triangleW - width,
                        y: y - 0.5 * height,
                        w: width + 1.3 * triangleW,
                        h: height
                    };
                }
            } else if (context.canvas.clientHeight - y - 100 < height + 1.3 * triangleW){ // 气泡朝上
                direction = 'bottom'; // 箭头朝下
                pointArr = [
                    {x: x, y: y + margin},
                    {x: x, y: y - 1.3 * triangleW - WEBTools.toolTip.radius},
                    {x: x - 2 * triangleW, y: y - 1.3 * triangleW}
                ];
                WEBTools.drawRoundedRect(context, x - width, y - 1.3 * triangleW - height + 1, width, height, WEBTools.toolTip.radius, WEBTools.toolTip.fontColor);
                // 存储ToolTip记录
                WEBTools.toolTip.record = {
                    x: x - width - 1,
                    y: y - 1.3 * triangleW - height + 1,
                    w: width + 2,
                    h: height + 1.3 * triangleW
                };
            } else { // 气泡朝下
                direction = 'top'; // 箭头朝上
                pointArr = [
                    {x: x, y: y + margin},
                    {x: x - triangleW, y: rectY},
                    {x: x + triangleW, y: rectY}
                ];
                WEBTools.drawRoundedRect(context, x - 0.5 * width, rectY - 1, width, height, WEBTools.toolTip.radius, WEBTools.toolTip.fontColor);
                // 存储ToolTip记录
                WEBTools.toolTip.record = {
                    x: x - 0.5 * width - 1,
                    y: y + margin,
                    w: width + 2,
                    h: height + 1.3 * triangleW
                };
            }
            WEBTools.drawTriangle(context, WEBTools.toolTip.bgColor, pointArr);
            //绘制ToolTip文字
            context.fillStyle = WEBTools.toolTip.fontColor;
            switch (direction) { // 箭头方向
                case 'left':
                    context.fillText(text, x + 1.3 * triangleW + paddingH, y + 0.5 * height - paddingV + 1 + 10);
                    break;
                case 'leftTop':
                    context.fillText(text, x + paddingH, rectY + height - paddingV + 1);
                    break;
                case 'leftBottom':
                    context.fillText(text, x + penWidth + paddingH, y - 1.3 * triangleW - paddingV + 1);
                    break;
                case 'right':
                    context.fillText(text, x - 1.3 * triangleW - width + paddingH, y + 0.5 * height - paddingV + 1);
                    break;
                case 'rightTop':
                    context.fillText(text, x - width + paddingH, rectY + height - paddingV);
                    break;
                case 'rightBottom':
                case 'bottom':
                    context.fillText(text, x - width + paddingH, y - 1.3 * triangleW - paddingV + 1);
                    break;
                case 'top':
                    context.fillText(text, x - 0.5 * width + paddingH, rectY + height - paddingV);
                    break;
            }
        },

        drawRoundedRect: function(ctx, x, y, width, height, r) {
            ctx.beginPath(); // draw top and top right corner
            ctx.moveTo(x + r, y);
            ctx.arcTo(x + width, y, x + width, y + r, r); // draw right side and bottom right corner
            ctx.arcTo(x + width, y + height, x + width - r, y + height, r); // draw bottom and bottom left corner
            ctx.arcTo(x, y + height, x, y + height - r, r); // draw left and top left corner
            ctx.arcTo(x, y, x + r, y, r);
            ctx.closePath();
            ctx.fill();
        },
        
        drawTriangle: function (ctx, bgColor, pointArr) {
            //填充三角形（等边）
            ctx.beginPath();
            ctx.moveTo(pointArr[0].x,pointArr[0].y);
            ctx.lineTo(pointArr[1].x,pointArr[1].y);
            ctx.lineTo(pointArr[2].x,pointArr[2].y);
            ctx.closePath();
            ctx.fillStyle= bgColor;//以纯色绿色填充
            ctx.fill(); //闭合形状并且以填充方式绘制出来
        }
    }
    
    var paint= function (obj) {
        //parent class
        this.Arr_data_handle=new Array();//record every change's all data to back 用于存储所有的历史记录信息
        
        if(obj.specialValue.owner!=undefined){//预留
            this.login_type=obj.specialValue.owner;
        }else{//Compatible with older versions  适配老版本
            //为了记录颜色
            if(obj.drawingType==4)//text
            {
                this.login_type= obj.specialValue.font.font_color==WEBTools.conf.canvas.teaFontC?'tea':'stu';
            }
            else
            {
                this.login_type= obj.specialValue.pencil_color==WEBTools.conf.canvas.teaPenC?'tea':'stu';
            }
        }
        this.version_type=WEBTools.conf.version;//版本信息
        this.id=WEBTools.svcId;//id
        this.handleType=obj.handleType;
        this.drawingType=obj.drawingType;
        //update conf
        WEBTools.orderList.push(WEBTools.svcId);//加入操作列表
        WEBTools.recordConArr.push(this);//加入对应的对象列表
        WEBTools.svcId++;//递增id
    }

//初始化信息
    paint.prototype.init_paint= function (obj,type) {//init paint data  为当前的对象赋值
        if(!type)
            this.Arr_data_handle.push(obj);//入栈
        // console.log(this.Arr_data_handle)
        if(obj.handleType==0){//add
            if(obj.drawingType!=500){//旧操作
                this.canvasWidth=obj.specialValue.canvasWidth;//记录当前的笔迹的相对的画布大小
                this.canvasHeight=obj.specialValue.canvasHeight;//记录当前的笔迹的相对的画布大小
                //it maybe change after,but now set 1
                this.changeCount=1;//记录更改的次数 默认为1（出生）
                //1 will show, 0 won't  控制是否显示
                this.display=1;
                
                this.child_div_W=obj.specialValue.child_div_W;//笔记区域的大小
                this.child_div_H=obj.specialValue.child_div_H;//笔记区域的大小
                this.margin_left=obj.specialValue.margin_left;//笔记区域的边距
                this.margin_top=obj.specialValue.margin_top;//笔记区域的边距
                this.drag_left=0;//笔迹的拖拽的距离
                this.drag_top=0;//笔迹的拖拽的距离
                //记录笔迹的属性style
                if(obj.drawingType==4)//text 文本
                {
                    this.font_color=obj.specialValue.font.font_color;
                    this.font_size=obj.specialValue.font.font_size;
                    this.font_style=obj.specialValue.font.font_style;
                    this.point_Arr_text=window.MyBase64.decode(obj.specialValue.str_text).replace(/\/u0027/g,'\'');//replace适配老版本
                }
                else//pen
                {
                    this.color=obj.specialValue.pencil_color;
                    this.size=obj.specialValue.pencil_size;
                    this.point_Arr_text=obj.specialValue.point;
                }
            }else{
                //new handle 新操作（具有在已有笔迹的基础上更改性质的操作）
                //update conf
                WEBTools.orderList.push(this.id);
                WEBTools.svcId++;
                if(!type)
                    this.changeCount++;//没更改一次，更新哨兵一次
                switch (obj.specialValue.type){
                    case 0://new rubber 新橡皮
                        this.display=0;
                        break;
                    case 1://drag  拖拽
                        this.drag_left=obj.specialValue.drag_left;
                        this.drag_top=obj.specialValue.drag_top;
                        break;
                    case 2://reedit 重写
                        this.child_div_W=obj.specialValue.child_div_W;
                        this.child_div_H=obj.specialValue.child_div_H;
                        this.drag_left=obj.specialValue.drag_left;
                        this.drag_top=obj.specialValue.drag_top;
                        this.point_Arr_text=window.MyBase64.decode(obj.specialValue.str_text).replace(/\/u0027/g,'\'');
                        break;
                    default :
                        break;
                }
            }
        }
        else if(obj.handleType==1){
            /*delete*/
        }else if(obj.handleType==2){
            /*change*/
        }
    }

//按类型操作
    paint.prototype.handle= function (target_context) {//Message Dispatch 进行分发，实现绘制
        try{
            if(this.display==1){
                switch (this.drawingType){
                    case 0://pen
                        this.canvas_pencil(target_context);
                        break;
                    case 2://rectangle
                        this.canvas_square(target_context);
                        break;
                    case 10://Highlighter pen
                        this.canvas_sign(target_context);
                        break;
                    case 4://text
                        this.canvas_write(target_context);
                        break;
                    case 3://old rubber
                        this.canvas_rubber(target_context);
                        break;
                    default :
                        break;
                }
            }
        }catch(e){
            console.error('[%s] -----------> error happened when paint.prototype.handle : %s',window.getTimeNow(),e);
        }
        
    }
//    下面所有的绘制策略都是
//    先计算缩放比例，用于之后对点信息或者文字大小信息的缩放
//    根据对象设置当前的绘制属性
//画笔
    paint.prototype.canvas_pencil= function (target_context) {
        var s=WEBTools.conf.canvas.width/this.canvasWidth;
        var s2=WEBTools.conf.canvas.width/800;
        var lineWid=Math.round(WEBTools.conf.pencil.size*s2);
        target_context.lineCap='round';
        target_context.lineJoin="round";
        target_context.strokeStyle= target_context.color || this.color;
        //-----------------------修改为本地写死--------------------------
        //target_context.lineWidth = this.size*s2;
        target_context.lineWidth = lineWid;
        //-----------------------修改为本地写死--------------------------
        target_context.moveTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
        target_context.beginPath();
        for(var i=1;i<this.point_Arr_text.length;i++){
            target_context.lineTo((this.point_Arr_text[i].x+this.drag_left)*s,(this.point_Arr_text[i].y+this.drag_top)*s);
        }
        target_context.stroke();
    }

//长方形
    paint.prototype.canvas_square= function (target_context) {
        var s=WEBTools.conf.canvas.width/this.canvasWidth;
        var s2=WEBTools.conf.canvas.width/800;
        var lineWid=Math.round(WEBTools.conf.pencil.size*s2);
        target_context.strokeStyle= this.color;
        target_context.lineJoin="round";
        //-----------------------修改为本地写死--------------------------
        //target_context.lineWidth = this.size*s2;
        target_context.lineWidth = lineWid;
        //-----------------------修改为本地写死--------------------------
        target_context.moveTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
        target_context.beginPath();
        target_context.lineTo((this.point_Arr_text[1].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
        target_context.lineTo((this.point_Arr_text[1].x+this.drag_left)*s,(this.point_Arr_text[1].y+this.drag_top)*s);
        target_context.lineTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[1].y+this.drag_top)*s);
        target_context.lineTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
        target_context.closePath();
        target_context.stroke();
    }

//荧光笔
    paint.prototype.canvas_sign= function (target_context) {
        target_context.save();
        var s=WEBTools.conf.canvas.width/this.canvasWidth;
        
        target_context.lineCap='round';
        target_context.lineJoin="round";
        target_context.strokeStyle=this.color;
        target_context.globalAlpha=0.4;
        target_context.globalCompositeOperation='destination-over';
        target_context.lineWidth=this.size*WEBTools.conf.canvas.width/800;
        target_context.moveTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
        target_context.beginPath();
        for(var i=2;i<this.point_Arr_text.length;i++){
            target_context.lineTo((this.point_Arr_text[i].x+this.drag_left)*s,(this.point_Arr_text[i].y+this.drag_top)*s);
        }
        target_context.stroke();
        target_context.restore();
    }

//文字
    paint.prototype.canvas_write= function (target_context){
        var theString=this.point_Arr_text;
        var s=WEBTools.conf.canvas.width/this.canvasWidth;
        var hei_point=(this.margin_top+this.drag_top)*s;
        var wid_point=(this.margin_left+this.drag_left)*s+WEBTools.textData.inputBorder;
        var words=[];
        var i,j;
        
        target_context.font='bold '+Math.round(this.font_size*s)+"px "+WEBTools.conf.font.fontStyle;//修改为写死数值songti
        target_context.fillStyle=this.font_color;
        
        theString.replace(/\r\n/g,'\n');
        words=theString.split(/\n/);
        
        for(i=0,j=words.length;i<j;i++){
            hei_point+=(this.font_size)*s;
            target_context.fillText(words.shift(),wid_point,hei_point);
        }
    }

//旧版橡皮擦
    paint.prototype.canvas_rubber= function (target_context) {
        target_context.save();
        var s=WEBTools.conf.canvas.width/this.canvasWidth;
        var sizerub=WEBTools.conf.rub.size*s;
        target_context.lineCap='round';
        target_context.lineJoin="round";
        /*for(var i=0;i<this.point_Arr_text.length;i++){
            //橡皮擦数据
            target_context.clearRect((this.point_Arr_text[i].x)*s-sizerub/2,(this.point_Arr_text[i].y)*s-sizerub/2,sizerub,sizerub);
        }*/
        target_context.lineWidth = sizerub;
        
        target_context.globalCompositeOperation = "destination-out";
        //-----------------------修改为本地写死--------------------------
        target_context.moveTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
        target_context.beginPath();
        for(var i=1;i<this.point_Arr_text.length;i++){
            target_context.lineTo((this.point_Arr_text[i].x+this.drag_left)*s,(this.point_Arr_text[i].y+this.drag_top)*s);
        }
        target_context.stroke();
        
        target_context.restore();
    }
    
    exports.resizePaint=function (wid,hei,left,top) {//用于第一次初始化和之后的每一次容器变化来设置画布的大小的
        WEBTools.review(wid,hei,left,top);
    };
    exports.draw=function (type) {//画笔激活，更换画笔，回退，清空
        WEBTools.draw(type);
    };
    exports.showCefPaint=function (obj) {//显示服务端的数据
        //   console.log('显示服务端的数据')
        //   console.log(obj)
        // console.log('显示服务端的数据')
        WEBTools.showPaint(obj);
    };
    exports.setBoardConf=function (obj) {//更新白板当前配置
        //update conf for WEBTools
        WEBTools.conf.type=(obj.type!=undefined)?obj.type:WEBTools.conf.type;
        WEBTools.conf.version=(obj.version!=undefined)?obj.version:WEBTools.conf.version;
        if(obj.pauseDraw!=undefined){
            if(obj.pauseDraw){//pauseDraw become true when drawing
                if(WEBTools.conf.paintBoard.input&&WEBTools.conf.paintBoard.input.style.display!='none'){//writing
                    WEBTools.write_end();
                }else{//other
                    WEBTools.mouseup();
                }
            }
            WEBTools.conf.pauseDraw=obj.pauseDraw;
        }
        if(obj.paintModule!=undefined){
            WEBTools.conf.paintModule=(obj.paintModule!=undefined)?obj.paintModule:WEBTools.conf.paintModule;
            if(WEBTools.conf.paintModule==='draw'&&WEBTools.binded===false){
                //切为draw模式，防止未绑定
                WEBTools.initWEBTools();
            }
        }
        if(obj.pencil!=undefined){
            WEBTools.conf.pencil.color=(obj.pencil.color!=undefined)?obj.pencil.color:WEBTools.conf.pencil.color;
            WEBTools.conf.pencil.size=(obj.pencil.size!=undefined)?obj.pencil.size:WEBTools.conf.pencil.size;
        }
        if(obj.sign_pencil!=undefined){
            WEBTools.conf.sign_pencil.color=(obj.sign_pencil.color!=undefined)?obj.sign_pencil.color:WEBTools.conf.sign_pencil.color;
            WEBTools.conf.sign_pencil.size=(obj.sign_pencil.size!=undefined)?obj.sign_pencil.size:WEBTools.conf.sign_pencil.size;
        }
        if(obj.rub!=undefined){
            WEBTools.conf.rub.size=(obj.rub.size!=undefined)?obj.rub.size:WEBTools.conf.rub.size;
        }
        if(obj.font!=undefined){
            WEBTools.conf.font.fontStyle=(obj.font.fontStyle!=undefined)?obj.font.fontStyle:WEBTools.conf.font.fontStyle;
            WEBTools.conf.font.fontSize=(obj.font.fontSize!=undefined)?obj.font.fontSize:WEBTools.conf.font.fontSize;
            WEBTools.conf.font.fontColor=(obj.font.fontColor!=undefined)?obj.font.fontColor:WEBTools.conf.font.fontColor;
        }
        if(obj.target){
            WEBTools.conf.font.fontStyle=(obj.font.fontStyle!=undefined)?obj.font.fontStyle:WEBTools.conf.font.fontStyle;
        }
    };
    exports.rePaint= function () {//重绘
        WEBTools.repaint();
    };
    exports.clearPaint= function () {//清空所有笔记，但是不清楚数据
        WEBTools.clearConText(1);
    }
    exports.handle_clear= function () {//清空所有笔记，但是不清楚数据
        WEBTools.handle_clear();
    }
});
