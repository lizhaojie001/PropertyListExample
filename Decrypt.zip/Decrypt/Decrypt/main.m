//
//  main.m
//  Decrypt
//
//  Created by xdf_yanqing on 2019/3/29.
//  Copyright © 2019 xdf_yanqing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TsDecrypt.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
         long encryptKey = 612400680;
        TsDecrypt * ts =  [TsDecrypt new];
        NSLog(@"%s",[ts getDecryptByte:encryptKey]);
        [ts decryptData:encryptKey];

    }
    return 0;
}
